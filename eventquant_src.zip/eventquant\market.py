"""市场环境过滤器：判断「现在适不适合开新仓」。

三个输入都是免费公开数据：
1. 恐惧贪婪指数（alternative.me）—— 0 极度恐慌 / 100 极度贪婪
2. 资金费率（币安 BTC 永续）—— 正得离谱说明多头拥挤、拥挤交易容易被反向收割
3. 24h 涨跌幅 —— 单日波动过大说明消息面在主导行情，技术指标基本失效

输出三档：
    ok       正常，可开仓
    caution  有一个风险信号，可以开但别重仓
    block    两个及以上风险信号，暂停开新仓

注意：这是「避险开关」，不是「盈利信号」。它的作用是让你在危险时段少亏，
代价是会错过一些行情。它不会提高单笔胜率。
"""

import threading
import time

import requests

from . import config

CN_LABEL = {
    "Extreme Fear": "极度恐慌",
    "Fear": "恐慌",
    "Neutral": "中性",
    "Greed": "贪婪",
    "Extreme Greed": "极度贪婪",
}


def _fetch_fng():
    """恐惧贪婪指数。国内直连可能不通，失败后退回代理再试一次。"""
    for proxies, to in ((None, 5), (config.PROXIES, 10)):
        try:
            r = requests.get(config.FNG_URL, timeout=to, proxies=proxies)
            r.raise_for_status()
            item = r.json()["data"][0]
            return {
                "value": int(item["value"]),
                "label": CN_LABEL.get(item.get("value_classification", ""), ""),
            }
        except Exception:
            continue
    return None


class MarketRegime:
    def __init__(self, api=None):
        self.api = api
        self._state = {
            "level": "unknown",
            "label": "未知",
            "reasons": ["尚未取到市场数据"],
            "items": {},
            "time": "",
        }
        self._ts = 0.0
        self._lock = threading.Lock()

    # ---------- 数据 ----------
    def _binance_bits(self):
        """资金费率、多空比、24h 涨跌，任一失败都不影响其他项。"""
        out = {}
        if self.api is None:
            return out
        try:
            p = self.api.premium("BTCUSDT")
            out["funding"] = float(p["lastFundingRate"])
        except Exception:
            pass
        try:
            rows = self.api.global_ls_ratio("BTCUSDT", period="5m", limit=1)
            if rows:
                out["ls"] = float(rows[-1]["longShortRatio"])
        except Exception:
            pass
        try:
            t = self.api.ticker24("BTCUSDT")
            out["chg24"] = float(t["priceChangePercent"])
        except Exception:
            pass
        return out

    # ---------- 规则 ----------
    def _judge(self, fng, bits):
        reasons = []
        hard = False
        score = 0

        v = (fng or {}).get("value")
        if v is not None:
            if v <= config.FNG_BLOCK_LOW:
                hard = True
                reasons.append(f"恐慌贪婪 {v}，处于极度恐慌区，恐慌盘容易继续踩踏")
            elif v >= config.FNG_BLOCK_HIGH:
                hard = True
                reasons.append(f"恐慌贪婪 {v}，处于极度贪婪区，追高容易被反向收割")
            elif v <= config.FNG_BLOCK_LOW + 10:
                score += 1
                reasons.append(f"恐慌贪婪 {v}，接近极度恐慌")
            elif v >= config.FNG_BLOCK_HIGH - 10:
                score += 1
                reasons.append(f"恐慌贪婪 {v}，接近极度贪婪")

        f = bits.get("funding")
        if f is not None:
            if abs(f) >= config.MARKET_FUNDING_BLOCK:
                hard = True
                reasons.append(f"资金费率 {f * 100:.3f}%/8h，多空极度拥挤")
            elif abs(f) >= config.MARKET_FUNDING_BLOCK * 0.6:
                score += 1
                reasons.append(f"资金费率 {f * 100:.3f}%/8h，偏拥挤")

        c = bits.get("chg24")
        if c is not None:
            if abs(c) >= config.MARKET_CHG24_BLOCK:
                hard = True
                reasons.append(f"24h 涨跌 {c:+.2f}%，单日波动过大，消息面主导")
            elif abs(c) >= config.MARKET_CHG24_BLOCK * 0.6:
                score += 1
                reasons.append(f"24h 涨跌 {c:+.2f}%，波动偏大")

        ls = bits.get("ls")
        if ls is not None:
            if ls >= config.MARKET_LS_EXTREME or ls <= 1 / config.MARKET_LS_EXTREME:
                hard = True
                reasons.append(f"账户多空比 {ls:.2f}，散户一边倒，容易被反向")
            elif ls >= 1.8 or ls <= 0.55:
                score += 1
                reasons.append(f"账户多空比 {ls:.2f}，情绪偏激进")

        if hard or score >= config.MARKET_CAUTION_SCORE:
            level, label = "block", "暂停开仓"
        elif score == 1:
            level, label = "caution", "谨慎"
        elif not reasons:
            level, label = "ok", "可开仓"
            reasons.append("各项情绪指标都在正常区间")
        else:
            level, label = "ok", "可开仓"

        return level, label, reasons

    def refresh(self):
        fng = _fetch_fng()
        bits = self._binance_bits()
        level, label, reasons = self._judge(fng, bits)
        st = {
            "level": level,
            "label": label,
            "reasons": reasons,
            "time": time.strftime("%H:%M:%S"),
            "ts": int(time.time() * 1000),
            "items": {
                "fng": fng,
                "funding": bits.get("funding"),
                "ls": bits.get("ls"),
                "chg24": bits.get("chg24"),
            },
            "thresholds": {
                "fng_block": [config.FNG_BLOCK_LOW, config.FNG_BLOCK_HIGH],
                "funding_block": config.MARKET_FUNDING_BLOCK,
                "chg24_block": config.MARKET_CHG24_BLOCK,
            },
        }
        with self._lock:
            self._state = st
        return st

    # ---------- 对外 ----------
    def state(self, force=False):
        if force or time.time() - self._ts > config.MARKET_REFRESH:
            try:
                self.refresh()
                self._ts = time.time()
            except Exception as e:
                with self._lock:
                    self._state["reasons"] = [f"刷新失败：{e}"]
        with self._lock:
            return dict(self._state)

    def allow_open(self):
        """开新仓的总开关。拿不到数据时放行（宁可漏拦，不要因为接口挂了就不干活）。"""
        return self.state().get("level") != "block"

    def run(self, stop_event):
        while not stop_event.is_set():
            try:
                self.refresh()
                self._ts = time.time()
            except Exception as e:
                print(f"[市场环境] 刷新失败：{e}")
            stop_event.wait(config.MARKET_REFRESH)
