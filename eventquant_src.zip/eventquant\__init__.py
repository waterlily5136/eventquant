"""eventquant：币安 U 本位永续合约的多窗口走势概率分析工具。

模块：
    api        公共行情客户端（限流 + 断线换节点）
    store      SQLite 落盘
    collector  实时采集
    features   10/30/60 分钟特征
    model      三分类概率模型
    backtest   历史回测与训练
    signals    信号 / 告警 / 推送
"""

__version__ = "0.1.0"
