"""网页看板：后台采集 + 定时预测 + 浏览器展示。

启动后：
- 采集线程每 10s 拉一次盘口/成交/资金费/持仓量
- 预测线程每 30s 重算一次各币 10/30/60 分钟方向概率
- HTTP 服务把最新结果以 JSON 暴露，网页每 30s 自动刷新
"""

import json
import threading
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

from . import bridge, config, contract, providers  # noqa: F401  bridge 导入即注册扩展
from .api import BinancePublic
from .archive import KlineArchiver
from .collector import Collector
from .features import book_features, live_core
from .market import MarketRegime
from .perp import PerpPaper
from . import grade
from . import altradar
from .model import load, predict_row
from .netguard import NetGuard
from .picks import Picks, format_pick_card
from .scheduler import start_in_background
from .signals import check_alerts, disclaimer, format_order_card, push
from .sim import EventSimulator
from .store import Store
from .watchdog import Watchdog

UI_FILE = Path(__file__).with_name("web_ui.html")
STATE_INTERVAL = 30


class WebApp:
    def __init__(self):
        self.api = BinancePublic()
        self.store = Store()
        self.collector = Collector(self.api, self.store)
        self.archiver = KlineArchiver(self.api, self.store, self.collector.symbols)
        self.bundles = {h: load(h) for h in config.HORIZONS}
        self.bundles = {h: b for h, b in self.bundles.items() if b}
        self.sim = EventSimulator()
        self.picks = Picks()
        self.perp = PerpPaper()
        self.watchdog = Watchdog(self.api)
        self.netguard = NetGuard()
        self.market = MarketRegime(self.api)
        self._kline_cache = {}
        self._pushed = {}   # (symbol, horizon, direction) -> 这条事件的验证时间
        self.state = {}
        self._state_ts = 0.0
        self._compute_lock = threading.Lock()
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.last_error = ""

    # ---------- 后台任务 ----------
    def _collect_loop(self):
        while not self.stop_event.is_set():
            t0 = time.time()
            for sym in self.collector.symbols:
                if self.stop_event.is_set():
                    break
                try:
                    self.collector.poll(sym)
                except Exception as e:
                    self.last_error = f"采集 {sym}: {e}"
            self.stop_event.wait(max(0, config.POLL_SECONDS - (time.time() - t0)))

    def get_state(self, force=False):
        """按需计算并缓存 30 秒，避免多个页面重复打接口。

        force=True 时忽略缓存（网页上的「立即刷新」按钮）。
        """
        if not force and self.state and time.time() - self._state_ts < STATE_INTERVAL:
            return self.state
        with self._compute_lock:
            if not force and self.state and time.time() - self._state_ts < STATE_INTERVAL:
                return self.state
            self.state = self.build_state()
            self._state_ts = time.time()
            return self.state

    def _build_symbol(self, sym):
        """单个标的的特征 + 各周期事件（可并行调用）。"""
        item = {"symbol": sym}
        try:
            core = live_core(self.api, sym)
        except Exception as e:
            item["error"] = f"行情获取失败：{e}"
            return item, []
        # 事件触发时间：本轮拿到特征的时刻；数据截止时间：最后一根收盘 K 线
        trigger_ms = contract.now_ms()
        as_of_ms = int(core.get("_as_of_ms") or 0)
        book = book_features(self.store, sym)
        tick = self.store.latest("ticker", sym) or {}
        item["price"] = round(float(tick.get("last", 0)), 6) or None
        item["chg24"] = float(tick.get("pct24", 0)) if tick else 0.0
        item_events = []
        missing = []
        for h in config.HORIZONS:
            b = self.bundles.get(h)
            if not b:
                missing.append(h)
                continue
            p = predict_row(b, core)
            item_events.append(
                contract.build_event(
                    sym, h, p,
                    trigger_ms=trigger_ms,
                    as_of_ms=as_of_ms,
                    book=book.get(h, {}),
                )
            )
        item["events"] = item_events
        if missing:
            item["missing_models"] = missing
        return item, item_events

    def klines(self, symbol, limit=120, interval="1m", end=None):
        """K 线（页面画图用），5 秒内复用缓存，避免多标签页重复请求。

        end 用于「盲评」：只返回到某个时刻为止的 K 线，
        这样待表态的预测就不会把触发之后的走势提前暴露。
        """
        key = (symbol, limit, interval, end)
        now = time.time()
        hit = self._kline_cache.get(key)
        if hit and now - hit[0] < 30:
            return hit[1]
        raw = self.api.klines(symbol, interval=interval, limit=limit, end=end)
        bars = [
            [int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])]
            for k in raw
        ]
        payload = {"symbol": symbol, "interval": interval, "bars": bars,
                   "ts": int(now * 1000)}
        self._kline_cache[key] = (now, payload)
        return payload

    def kline_snapshot(self, symbol):
        """给推送用的一行 5 分钟盘面摘要。失败返回空串，不影响推送。"""
        try:
            raw = self.api.klines(symbol, interval="5m", limit=12)   # 最近 1 小时
            if len(raw) < 2:
                return ""
            hi = max(float(k[2]) for k in raw)
            lo = min(float(k[3]) for k in raw)
            cur = float(raw[-1][4])
            amp = (hi / lo - 1) * 100 if lo else 0
            pos = (cur - lo) / (hi - lo) * 100 if hi > lo else 50
            return (f"5分钟K｜近1小时 {lo:.6g}~{hi:.6g}"
                    f"（振幅 {amp:.2f}%），现价处于区间 {pos:.0f}% 位置")
        except Exception:
            return ""

    def build_state(self):
        # 4 个标的并行拉取，否则串行一轮要 40~60 秒，页面会像卡住
        workers = max(1, min(4, len(self.collector.symbols)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            built = list(ex.map(self._build_symbol, self.collector.symbols))
        symbols = [item for item, _ in built]
        events = [ev for _, evs in built for ev in evs]

        alerts = []
        now_ms = int(time.time() * 1000)
        for sym in self.collector.symbols:
            try:
                alerts.extend(check_alerts(self.store, sym, now_ms))
            except Exception:
                pass

        backtest = {}
        for h, b in self.bundles.items():
            info = b.get("info", {}) or {}
            if info.get("backtest"):
                m = dict(info["backtest"])
                m["label_bps"] = info.get("label_bps")
                m.pop("sweep", None)
                backtest[h] = m

        return {
            "generated_at": contract.fmt_ms(contract.now_ms()),
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "symbols": symbols,
            "events": events,
            "providers": providers.collect(),
            "alerts": alerts,
            "backtest": backtest,
            "disclaimer": disclaimer(),
            "error": self.last_error,
        }

    # ---------- 生命周期 ----------
    def start(self):
        threading.Thread(target=self._collect_loop, daemon=True).start()
        threading.Thread(target=self._settle_loop, daemon=True).start()
        threading.Thread(target=self.archiver.run, args=(self.stop_event,), daemon=True).start()
        if config.SIM_AI_ENABLED:
            threading.Thread(target=self._ai_loop, daemon=True).start()
        threading.Thread(target=self._picks_loop, daemon=True).start()
        if config.PERP_ENABLED:
            threading.Thread(target=self._perp_loop, daemon=True).start()
        threading.Thread(target=self.watchdog.run, args=(self.stop_event,), daemon=True).start()
        threading.Thread(target=self.market.run, args=(self.stop_event,), daemon=True).start()
        # 启动预热：立即检查网络，Clash 默认节点不行就立刻切，不等 60s 巡检
        try:
            self.netguard.preflight()
        except Exception as e:
            print(f"[网络守护] preflight 异常：{e}")
        threading.Thread(target=self.netguard.run, args=(self.stop_event,), daemon=True).start()

    def last_price(self, symbol):
        return float(self.api.ticker24(symbol)["lastPrice"])

    def _ai_loop(self):
        """按置信度门槛自动模拟下单，留下可核对的AI记录。"""
        while not self.stop_event.is_set():
            try:
                self.ai_step()
            except Exception as e:
                self.last_error = f"AI 模拟下单：{e}"
            self.stop_event.wait(config.SIM_AI_INTERVAL)

    def ai_stake(self, confidence):
        """AI 下注金额：下限 5U，置信度每高出下限 2 个百分点加 1U，取整数。

        例（下限 52%，步长 2%）：52% → 5U，56% → 7U，60% → 9U，66% → 12U。
        上限 20U，避免极端置信度下把模拟盘记成巨额头寸。
        """
        extra = int(round((confidence - config.SIM_AI_MIN_CONF) / config.SIM_AI_STAKE_STEP_CONF))
        stake = config.SIM_AI_MIN_STAKE + max(0, extra)
        return float(min(int(stake), int(config.SIM_AI_MAX_STAKE_AI)))

    def ai_step(self):
        # 市场环境过滤器：情绪极端 / 拥挤 / 单日剧烈波动时不开新仓
        if not self.market.allow_open():
            return
        state = self.get_state()
        open_n = len(self.sim.state()["ai"]["open"])
        for s in state.get("symbols", []):
            if s.get("error"):
                continue
            # 每个标的每轮最多新增 1 单：从最确信的档位往下找，跳过已有持仓的档位
            cands = sorted(
                (
                    e for e in s.get("events", [])
                    if e["horizon"] in config.SIM_AI_HORIZONS
                    and e["direction"] in (contract.DIR_UP, contract.DIR_DOWN)
                    and e["confidence"] >= config.SIM_AI_MIN_CONF
                ),
                key=lambda e: e["confidence"],
                reverse=True,
            )
            for ev in cands:
                if self.sim.has_open(ev["symbol"], ev["horizon"], "ai"):
                    continue
                if open_n >= config.SIM_AI_MAX_OPEN:
                    return
                px = self.last_price(ev["symbol"])
                stake = self.ai_stake(ev["confidence"])
                order = self.sim.place(
                    ev["symbol"], ev["horizon"], ev["direction"],
                    stake, px, owner="ai",
                    pred={"confidence": ev["confidence"], "tier": ev["tier"]},
                )
                open_n += 1
                print(
                    f"[AI 下单] #{order['id']} {order['symbol']} {order['horizon_label']} "
                    f"{order['direction']} {order['stake']}U @ {order['entry']} "
                    f"（置信 {ev['confidence'] * 100:.1f}% {ev['tier']} 级）"
                )
                break

    def _picks_loop(self):
        """独立线程：编号推送不依赖 AI 模拟盘的开关。"""
        while not self.stop_event.is_set():
            try:
                self._record_picks(self.get_state())
            except Exception as e:
                self.last_error = f"编号推送：{e}"
            self.stop_event.wait(config.SIM_AI_INTERVAL)

    def _perp_loop(self):
        """永续模拟盘：每 30 秒看一次价，处理止盈/止损/到期。"""
        while not self.stop_event.is_set():
            try:
                for msg in self.perp.step(self.api):
                    print(f"[永续] {msg}")
            except Exception as e:
                self.last_error = f"永续模拟盘：{e}"
            self.stop_event.wait(30)

    def _backtest_win_rate(self, horizon):
        """该档位回测胜率，用于判断 AI 是否认可这条预测。"""
        b = self.bundles.get(horizon) or {}
        info = b.get("info") or {}
        bt = info.get("backtest") or {}
        wr = bt.get("win_rate")
        return float(wr) if isinstance(wr, (int, float)) else 0.0

    def _record_picks(self, state):
        """≥ 门槛的预测一律编号、落库、推手机。

        与原来的「可下注信号」推送合并成一个入口，避免同一条预测推两遍：
        - 置信度 ≥ PICK_MIN_CONF（默认 60%）、档位在 PICK_HORIZONS、方向明确
        - 同一 标的+档位+方向 在验证时间到达前只记一次（否则每 45 秒刷一条）
        - AI 认可 = 该档位回测胜率 ≥ PICK_AI_WIN_RATE，人为再点一次即为「双认可」
        """
        for s in state.get("symbols", []):
            if s.get("error"):
                continue
            for ev in s.get("events", []):
                if ev["horizon"] not in config.PICK_HORIZONS:
                    continue
                if ev["direction"] not in (contract.DIR_UP, contract.DIR_DOWN):
                    continue
                if ev["confidence"] < config.PICK_MIN_CONF:
                    continue
                ai_ack = self._backtest_win_rate(ev["horizon"]) >= config.PICK_AI_WIN_RATE
                pk = self.picks.record_if_new(ev, s.get("price"), ai_ack=ai_ack)
                if not pk:
                    continue
                # 永续模拟盘：市场环境没被拦，就同步开一张纸面单
                if config.PERP_ENABLED and self.market.state().get("level") != "block":
                    try:
                        self.perp.open_from_pick(pk, self.market.state(), price=s.get("price"))
                    except Exception as e:
                        print(f"[永续] 开仓失败：{e}")
                text = format_pick_card(pk, actionable=bool(ev.get("actionable")),
                                        calib=self.picks.calibration())
                snap = self.kline_snapshot(pk["symbol"])
                if snap:
                    text += f"\n{snap}"
                push(
                    text,
                    title=f"{pk['label']} {pk['symbol']} {pk['horizon_label']} {pk['direction']}",
                )
                print(
                    f"[编号] {pk['label']} {pk['symbol']} {pk['horizon']} {pk['direction']} "
                    f"{pk['confidence'] * 100:.1f}% ai_ack={pk['ai_ack']}"
                )

    def _settle_loop(self):
        """到期自动结算模拟事件合约 + 核对已编号预测的对错。"""
        while not self.stop_event.is_set():
            try:
                done = self.sim.settle_due(self._settle_price)
                for o in done:
                    print(
                        f"[模拟结算] {o['symbol']} {o['horizon']} {o['direction']} "
                        f"{o['entry']}→{o['settle_px']} {o['result']} {o['pnl']:+.2f}U"
                    )
            except Exception as e:
                self.last_error = f"模拟结算：{e}"
            try:
                for pk in self.picks.settle_due(self._settle_price):
                    print(
                        f"[核对] {pk['label']} {pk['symbol']} {pk['horizon']} "
                        f"{pk['direction']} {pk['entry_px']}→{pk['settle_px']} {pk['result']}"
                    )
            except Exception as e:
                self.last_error = f"预测核对：{e}"
            self.stop_event.wait(config.SIM_SETTLE_SECONDS)

    def _settle_price(self, symbol, target_ms):
        """结算价取「到期那一刻」的价格，而不是补结算时的现价。

        刚到期（90 秒内）直接用实时价；如果服务中断过、补结算延迟很久，
        就回头取到期那一分钟的收盘价，避免用重启后的价格错判输赢。
        """
        if contract.now_ms() - target_ms <= 90_000:
            try:
                return self.last_price(symbol)
            except Exception:
                pass
        try:
            raw = self.api.klines(
                symbol, interval="1m", limit=5,
                start=target_ms - 180_000, end=target_ms + 60_000,
            )
            px = None
            for k in raw:
                if int(k[0]) <= target_ms:
                    px = float(k[4])
            if px:
                return px
        except Exception:
            pass
        return self.last_price(symbol)

    def stop(self):
        self.stop_event.set()


LOGIN_HTML = """<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>需要口令</title>
<style>body{margin:0;background:#0b0f14;color:#e6edf3;font-family:system-ui,sans-serif;
display:flex;min-height:100vh;align-items:center;justify-content:center}
.box{background:#121821;border:1px solid #223044;border-radius:14px;padding:24px;width:88%;max-width:360px}
h2{margin:0 0 6px;font-size:16px}p{color:#8b98a8;font-size:12.5px;margin:0 0 14px}
input{width:100%;box-sizing:border-box;background:#0d131b;color:#e6edf3;border:1px solid #223044;
border-radius:8px;padding:9px 10px;font-size:14px}
button{margin-top:12px;width:100%;background:#16324f;color:#cfe3ff;border:1px solid #2c5a8a;
border-radius:8px;padding:9px;font-size:14px}</style></head><body><div class="box">
<h2>需要访问口令</h2><p>口令保存在服务器 data/panel_token.txt</p>
<input id="t" placeholder="输入口令" autocomplete="off">
<button onclick="location.href='/?token='+encodeURIComponent(document.getElementById('t').value)">
进入</button></div></body></html>"""


def make_handler(app):
    token = config.panel_token()

    class Handler(BaseHTTPRequestHandler):
        # ---------- 访问控制 ----------
        def _is_local(self):
            return self.client_address[0] in ("127.0.0.1", "::1")

        def _cookie_token(self):
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == "panel_token":
                    return v
            return ""

        def _auth(self, parsed):
            """返回 True/False/'set'。本机访问免口令，外部访问需要 token。"""
            if self._is_local():
                return True
            given = (parse_qs(parsed.query).get("token") or [""])[0]
            if given and given == token:
                return "set"
            if self._cookie_token() == token or self.headers.get("X-Panel-Token") == token:
                return True
            return False

        def _check_auth(self, parsed):
            ok = self._auth(parsed)
            if ok == "set":
                q = [(k, v) for k, vs in parse_qs(parsed.query).items()
                     if k != "token" for v in vs]
                loc = parsed.path + (("?" + urlencode(q)) if q else "")
                self.send_response(302)
                self.send_header("Location", loc)
                self.send_header(
                    "Set-Cookie",
                    f"panel_token={token}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax",
                )
                self.send_header("Content-Length", "0")
                self.end_headers()
                return False
            if not ok:
                body = LOGIN_HTML.encode("utf-8")
                self.send_response(401)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return False
            return True

        def do_GET(self):
            parsed = urlparse(self.path)
            if not self._check_auth(parsed):
                return
            path = parsed.path
            if path in ("/", "/index.html"):
                self._send(200, "text/html; charset=utf-8", UI_FILE.read_bytes())
            elif path == "/api/state":
                fresh = parse_qs(parsed.query).get("fresh", ["0"])[0] in ("1", "true")
                try:
                    st = app.get_state(force=fresh)
                except Exception as e:
                    st = {"time": "", "symbols": [], "alerts": [],
                          "backtest": {}, "disclaimer": disclaimer(),
                          "error": f"计算失败：{e}"}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(st, ensure_ascii=False, default=str).encode("utf-8"),
                )
            elif path == "/api/price":
                sym = (parse_qs(parsed.query).get("symbol") or ["BTCUSDT"])[0].upper()
                try:
                    body = {"symbol": sym, "price": app.last_price(sym),
                            "ts": int(time.time() * 1000)}
                except Exception as e:
                    body = {"symbol": sym, "error": str(e)}
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(body, ensure_ascii=False).encode("utf-8"))
            elif path == "/api/liqmap":
                q = parse_qs(parsed.query)
                sym = (q.get("symbol") or ["BTCUSDT"])[0].upper()
                try:
                    hours = max(24, min(240, int((q.get("hours") or ["168"])[0])))
                except ValueError:
                    hours = 168
                try:
                    from .liqmap import build as build_liqmap
                    body = build_liqmap(sym, hours)
                except Exception as e:
                    body = {"symbol": sym, "error": str(e), "rows": []}
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(body, ensure_ascii=False).encode("utf-8"))
            elif path == "/api/klines":
                q = parse_qs(parsed.query)
                sym = (q.get("symbol") or ["BTCUSDT"])[0].upper()
                interval = (q.get("interval") or ["1m"])[0]
                if interval not in ("1m", "5m", "15m", "1h", "4h", "1d"):
                    interval = "1m"
                try:
                    limit = max(30, min(300, int((q.get("limit") or ["120"])[0])))
                except ValueError:
                    limit = 120
                raw_end = (q.get("end") or [""])[0]
                end = int(raw_end) if raw_end.isdigit() else None
                try:
                    body = app.klines(sym, limit, interval, end)
                except Exception as e:
                    body = {"symbol": sym, "error": str(e), "bars": []}
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(body, ensure_ascii=False).encode("utf-8"))
            elif path == "/api/sim":
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(app.sim.state(), ensure_ascii=False, default=str).encode("utf-8"),
                )
            elif path == "/api/watch":
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(app.watchdog.state(), ensure_ascii=False, default=str).encode("utf-8"),
                )
            elif path == "/api/picks":
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(app.picks.state(), ensure_ascii=False, default=str).encode("utf-8"),
                )
            elif path == "/api/net":
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(app.netguard.state(), ensure_ascii=False, default=str).encode("utf-8"),
                )
            elif path == "/api/market":
                fresh = parse_qs(parsed.query).get("fresh", ["0"])[0] in ("1", "true")
                try:
                    st = app.market.state(force=fresh)
                except Exception as e:
                    st = {"level": "unknown", "label": "未知", "reasons": [f"获取失败：{e}"],
                          "items": {}}
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(st, ensure_ascii=False, default=str).encode("utf-8"))
            elif path == "/api/alt":
                fresh = parse_qs(parsed.query).get("fresh", ["0"])[0] in ("1", "true")
                try:
                    res = altradar.scan(app.api, force=fresh)
                except Exception as e:
                    res = {"error": str(e), "rows": []}
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(res, ensure_ascii=False, default=str).encode("utf-8"))
            elif path == "/api/perp":
                prices = {}
                try:
                    for p in app.perp.state()["positions"]:
                        try:
                            prices[p["symbol"]] = float(
                                app.api.premium(p["symbol"])["markPrice"])
                        except Exception:
                            pass
                except Exception:
                    pass
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(app.perp.state(prices), ensure_ascii=False,
                                      default=str).encode("utf-8"))
            elif path == "/api/grade":
                q = parse_qs(parsed.query)
                try:
                    stake = float(q.get("stake", ["10"])[0])
                except Exception:
                    stake = 10.0
                hz = q.get("horizon", ["all"])[0]
                try:
                    rows = app.picks.all_items()
                    if hz in ("30m", "60m", "1d"):
                        rows = [i for i in rows if i.get("horizon") == hz]
                    g = grade.report(rows, stake=stake)
                    g["horizon"] = hz
                except Exception as e:
                    g = {"error": str(e), "n": 0}
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(g, ensure_ascii=False, default=str).encode("utf-8"))
            else:
                self._send(404, "text/plain; charset=utf-8", b"not found")

        def do_POST(self):
            parsed = urlparse(self.path)
            if not self._check_auth(parsed):
                return
            path = parsed.path
            try:
                length = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                body = {}
            if path == "/api/watch/add":
                try:
                    sym = app.watchdog.add(
                        body.get("symbol"), body.get("note", ""), body.get("side", "none")
                    )
                    payload = {"ok": True, "symbol": sym, "state": app.watchdog.state()}
                except Exception as e:
                    payload = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path == "/api/watch/side":
                try:
                    app.watchdog.set_side(body.get("symbol"), body.get("side", "none"))
                    payload = {"ok": True, "state": app.watchdog.state()}
                except Exception as e:
                    payload = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path == "/api/watch/remove":
                try:
                    sym = app.watchdog.remove(body.get("symbol"))
                    payload = {"ok": True, "symbol": sym, "state": app.watchdog.state()}
                except Exception as e:
                    payload = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path == "/api/picks/ack":
                try:
                    pid = body.get("id")
                    val = int(body.get("ack", 0))
                    it = app.picks.ack(pid, val)
                    payload = {"ok": True, "pick": it, "state": app.picks.state()}
                except Exception as e:
                    payload = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path == "/api/perp/open":
                try:
                    symbol = str(body.get("symbol", "")).upper()
                    price = app.last_price(symbol)
                    pos = app.perp.open_manual(
                        symbol, body.get("side"), price,
                        body.get("margin"), body.get("note", ""),
                        body.get("sl_pct"), body.get("tp_pct"),
                    )
                    payload = {"ok": True, "position": pos}
                except Exception as e:
                    payload = {"ok": False, "error": str(e)}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path == "/api/perp/close":
                try:
                    pid = str(body.get("id", ""))
                    pct = float(body.get("pct", 1.0))
                    pos = app.perp.find(pid)
                    if not pos:
                        raise ValueError("找不到这张持仓")
                    price = app.last_price(pos["symbol"])
                    rec = app.perp.close_partial(
                        pid, price, pct,
                        reason=f"手动平仓 {int(pct * 100)}%",
                    )
                    payload = {"ok": True, "closed": rec, "price": price}
                except Exception as e:
                    payload = {"ok": False, "error": str(e)}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path == "/api/perp/sltp":
                try:
                    pid = str(body.get("id", ""))
                    pos = app.perp.set_sl_tp(pid, body.get("sl_pct"), body.get("tp_pct"))
                    payload = {"ok": True, "position": pos}
                except Exception as e:
                    payload = {"ok": False, "error": str(e)}
                self._send(
                    200, "application/json; charset=utf-8",
                    json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
                )
                return
            if path != "/api/sim/order":
                self._send(404, "text/plain; charset=utf-8", b"not found")
                return
            try:
                symbol = str(body.get("symbol", "")).upper()
                # 事件合约只做 BTC/ETH：山寨流动性差、插针多，不适合二元下注
                if symbol not in config.BINARY_SYMBOLS:
                    raise ValueError("事件合约只支持 BTC / ETH，山寨请用下面的永续模拟盘")
                price = app.last_price(symbol)
                order = app.sim.place(
                    symbol, body.get("horizon"), body.get("direction"),
                    body.get("stake"), price, owner="me",
                )
                payload = {"ok": True, "order": order, "state": app.sim.state()}
            except Exception as e:
                payload = {"ok": False, "error": f"{type(e).__name__}: {e}"}
            self._send(
                200, "application/json; charset=utf-8",
                json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8"),
            )

        def _send(self, code, ctype, body):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt, *args):
            pass

    return Handler


def _daily_report_loop(stop_event):
    """每天 08:00 后的第一次检查发日报；当天已发过就跳过。

    电脑 8 点没开也没关系——开机后 10 分钟内会自动补交。
    """
    import pathlib
    import subprocess
    import sys as _sys

    root = pathlib.Path(__file__).resolve().parent.parent
    script = root / "daily_report.py"
    if not script.exists():
        return
    while not stop_event.wait(600):
        try:
            if time.localtime().tm_hour < 8:
                continue
            subprocess.run(
                [_sys.executable, str(script), "--once-a-day"],
                cwd=str(root), timeout=300,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass


def serve(port=8777, open_browser=True, schedule=True, push_times=None, host=None):
    app = WebApp()
    app.start()
    if schedule:
        start_in_background(app.get_state, app.stop_event, times=push_times)
        import threading
        threading.Thread(
            target=_daily_report_loop, args=(app.stop_event,), daemon=True
        ).start()
    host = host or config.HOST
    httpd = ThreadingHTTPServer((host, port), make_handler(app))
    httpd.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    print(f"网页看板已启动：{url}  （Ctrl+C 停止）")
    if host == "0.0.0.0":
        import socket

        try:
            lan = socket.gethostbyname(socket.gethostname())
        except Exception:
            lan = "<本机IP>"
        print(f"局域网/公网访问：http://{lan}:{port}/?token={config.panel_token()}")
    if open_browser:
        threading.Timer(2.0, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")
    finally:
        app.stop()
        httpd.server_close()
