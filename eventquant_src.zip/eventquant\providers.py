"""功能扩展接口（Provider 注册表）。

新增一个功能模块（山寨雷达、资金费率排行、链上数据、自动执行器等）时：
    1. 新建模块，继承 Provider，实现 key / title / available() / payload()
    2. 调用 register(实例)
    3. 结果会自动出现在 /api/state 的 providers 字段和网页对应区块

web.py 不需要改动，这是后续功能迭代的统一入口。
"""

_REGISTRY = {}


class Provider:
    """标准化扩展点：一个数据区块的提供者。"""

    key = ""          # 唯一标识，用于前端路由与缓存
    title = ""        # 展示名称
    order = 100       # 排序，越小越靠前

    def available(self):
        """当前环境是否可用（依赖服务是否在线、数据是否存在）。"""
        return True

    def payload(self):
        """返回可直接 JSON 序列化的数据。不可用时返回 None。"""
        raise NotImplementedError

    def describe(self):
        return {"key": self.key, "title": self.title, "available": bool(self.available())}


def register(provider):
    _REGISTRY[provider.key] = provider
    return provider


def get(key):
    return _REGISTRY.get(key)


def catalog():
    return [p.describe() for p in sorted(_REGISTRY.values(), key=lambda p: p.order)]


def collect():
    """逐个收集，单个模块异常不影响其他模块与主页面。"""
    out = {}
    for p in sorted(_REGISTRY.values(), key=lambda p: p.order):
        try:
            if not p.available():
                out[p.key] = {"title": p.title, "ok": False, "error": "未连接"}
                continue
            out[p.key] = {"title": p.title, "ok": True, "data": p.payload()}
        except Exception as e:
            out[p.key] = {"title": p.title, "ok": False, "error": f"{type(e).__name__}: {e}"}
    return out
