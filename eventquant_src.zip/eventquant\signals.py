"""信号格式化、推送与异常告警。

推送默认只打印到终端；设置环境变量 EVENTQUANT_WEBHOOK 后可 POST 到机器人。
所有输出都附带免责声明。
"""

import json
from datetime import datetime

import requests

from . import config
from .contract import ARROW, format_event_text, format_order_card, horizon_label
from .features import CLASS_NAMES

# 每日推送次数上限：pushplus 免费额度为 200 次/天，超过会被限流甚至封号，
# 这里留出余量，达到 150 次就停止发送并记日志。
PUSH_DAILY_LIMIT = 150


def _count_path():
    return config.DATA_DIR / "push_count.json"


def _today():
    return datetime.now().strftime("%Y-%m-%d")


def _count_get():
    try:
        d = json.loads(_count_path().read_text(encoding="utf-8"))
        if d.get("date") == _today():
            return int(d.get("n", 0))
    except Exception:
        pass
    return 0


def _count_inc():
    n = _count_get() + 1
    try:
        _count_path().write_text(
            json.dumps({"date": _today(), "n": n}, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        pass
    return n


def push(text, title=None):
    """打印并推送到 WEBHOOK_URL。返回是否推送成功（未配置 webhook 也视为成功）。

    WEBHOOK_URL 支持三种简化写法（填在环境变量 EVENTQUANT_WEBHOOK 里）：
        pushplus:<token>     微信推送（pushplus.plus）
        serverchan:<key>     Server 酱（微信）
        bark:<key>           Bark（iOS 手机，可响铃）
    也可以直接填飞书/企业微信的机器人 webhook 地址。
    """
    full = (title + "\n" if title else "") + text
    print(("\n【%s】\n" % title if title else "\n") + text)
    if not config.WEBHOOK_URL:
        return True
    n = _count_get()
    if n >= PUSH_DAILY_LIMIT:
        print(f"[推送熔断] 今日已推 {n} 条，达到上限 {PUSH_DAILY_LIMIT}，停止发送")
        return False
    try:
        url = config.WEBHOOK_URL.strip()
        scheme, _, key = url.partition(":")
        if scheme in ("pushplus", "serverchan", "bark"):
            ok = _push_keyed(scheme, key.strip("/"), full, title)
        else:
            ok = _push_webhook(url, full)
        if ok:
            _count_inc()
        return ok
    except Exception as e:
        print(f"[推送失败] {e}")
        return False


def _push_webhook(url, full):
    if "feishu" in url or "larksuite" in url:
        payload = {"msg_type": "text", "content": {"text": full}}
    elif "qyapi.weixin.qq.com" in url:
        payload = {"msgtype": "text", "text": {"content": full}}
    else:
        payload = {"text": full}
    r = requests.post(url, json=payload, timeout=10)
    r.raise_for_status()
    try:
        j = r.json()
    except Exception:
        return True
    if j.get("errcode") not in (None, 0) or j.get("code") not in (None, 0):
        print(f"[推送失败] 机器人返回：{j}")
        return False
    return True


def _push_keyed(scheme, key, full, title):
    """无需服务器的手机推送通道。"""
    title = title or "量化提醒"
    try:
        if scheme == "pushplus":
            r = requests.post(
                "https://www.pushplus.plus/send",
                json={"token": key, "title": title, "content": full, "template": "txt"},
                timeout=10,
            )
            ok = r.status_code == 200 and r.json().get("code") == 200
        elif scheme == "serverchan":
            r = requests.post(
                f"https://sctapi.ftqq.com/{key}.send",
                data={"title": title, "desp": full},
                timeout=10,
            )
            ok = r.status_code == 200 and r.json().get("code") == 0
        else:  # bark：iOS，可设置响铃，适合"醒目"提醒
            r = requests.post(
                f"https://api.day.app/{key}",
                json={"title": title, "body": full, "group": "eventquant", "sound": "alarm"},
                timeout=10,
            )
            ok = r.status_code == 200
        if not ok:
            print(f"[推送失败] {scheme} 返回 {r.status_code} {r.text[:120]}")
        return ok
    except Exception as e:
        print(f"[推送失败] {scheme}: {e}")
        return False


def format_digest(state):
    """把 /api/state 压缩成一条适合手机阅读的播报：一行一个标的，信号单独列出。"""
    stamp = (state.get("generated_at") or state.get("time") or "")[5:16]
    lines = [f"盘面播报 · {stamp}"]
    signals = []
    for s in state.get("symbols", []):
        name = str(s.get("symbol", "")).replace("USDT", "")
        if s.get("error"):
            lines.append(f"{name}  行情获取失败")
            continue
        px, chg = s.get("price"), s.get("chg24") or 0.0
        lines.append(f"{name}  {_fmt_px(px)}  {chg:+.2f}%")
        parts = []
        for ev in s.get("events", []):
            h = horizon_label(config.HORIZONS[ev["horizon"]])
            mark = f" ★{ev['tier']}" if ev.get("actionable") else ""
            parts.append(
                f"{h} {ARROW.get(ev['direction'], '')}{ev['direction']} "
                f"{ev['confidence'] * 100:.0f}%{mark}"
            )
            if ev.get("actionable"):
                signals.append(
                    f"{name} {h} {ev['direction']} {ev['confidence'] * 100:.1f}%"
                    f"（{ev['tier']}级）\n   {ev['trigger_time'][11:16]} → {ev['target_time'][11:16]}"
                )
        if parts:
            lines.append("  " + " ｜ ".join(parts))

    lines.append("")
    if signals:
        lines.append("★ 可下注（★ 标记为达标档位）")
        lines.extend(signals)
    else:
        lines.append("★ 可下注：暂无（全部未达阈值）")

    alerts = state.get("alerts") or []
    if alerts:
        lines.append("")
        lines.append("⚠ 异常")
        lines.extend("  " + a for a in alerts[:4])
    lines.append("")
    lines.append(disclaimer())
    return "\n".join(lines)


def _fmt_px(px):
    """价格显示：大数带千分位，小币保留有效位。"""
    if not px:
        return "—"
    px = float(px)
    if px >= 100:
        return f"{px:,.2f}"
    if px >= 1:
        return f"{px:.3f}"
    return f"{px:.5f}".rstrip("0").rstrip(".")


def format_prediction(event, book=None):
    """命令行 / 推送用的多行文本；event 由 contract.build_event 生成。"""
    return format_event_text(event)


def check_alerts(store, symbol, now_ms):
    """返回异常描述列表。基于最近 1/5 分钟窗口。"""
    out = []
    t = store.ticker(symbol, now_ms - 90_000)
    if len(t) >= 2 and (t["ts"].iloc[-1] - t["ts"].iloc[0]) >= 45_000:
        first, last = t.iloc[0], t.iloc[-1]
        ret = last["last"] / first["last"] - 1
        if abs(ret) >= config.ALERT_RET_1M:
            out.append(f"{symbol} 1分钟异动 {ret * 100:+.2f}%")

    o = store.oi(symbol, now_ms - 6 * 60_000)
    if len(o) >= 2 and (o["ts"].iloc[-1] - o["ts"].iloc[0]) >= 4 * 60_000:
        chg = o["oi"].iloc[-1] / o["oi"].iloc[0] - 1
        if abs(chg) >= config.ALERT_OI_5M:
            out.append(f"{symbol} 5分钟持仓量变化 {chg * 100:+.2f}%")

    f = store.funding(symbol, now_ms - 10 * 60_000)
    if len(f) and abs(f["rate"].iloc[-1]) >= config.ALERT_FUNDING:
        out.append(f"{symbol} 资金费率异常 {f['rate'].iloc[-1] * 100:.3f}%/期")

    d = store.depth(symbol, now_ms - 60_000)
    if len(d):
        spread = d["spread_bps"].iloc[-1]
        imb = d["imbalance"].iloc[-1]
        if spread >= config.ALERT_SPREAD_BPS:
            out.append(f"{symbol} 点差走阔 {spread:.1f}bps")
        if abs(imb) >= config.ALERT_IMBALANCE:
            out.append(f"{symbol} 盘口失衡 {imb:+.2f}")

    fl = store.flow(symbol, now_ms - 11 * 60_000)
    if len(fl) and fl["ts"].min() <= now_ms - 5 * 60_000:
        recent = fl[fl["ts"] >= now_ms - 60_000]["buy_notional"].sum() + fl[
            fl["ts"] >= now_ms - 60_000
        ]["sell_notional"].sum()
        base = (fl["buy_notional"].sum() + fl["sell_notional"].sum() - recent) / 10
        if recent > 0 and base > 0 and recent / base >= config.ALERT_VOL_Z:
            out.append(f"{symbol} 成交额异动 {recent / base:.1f} 倍")
    return out


def disclaimer():
    return config.DISCLAIMER
