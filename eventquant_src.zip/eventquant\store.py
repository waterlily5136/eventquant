"""SQLite 存储：把每次采集的盘口/成交流/资金费/持仓量落盘。

表结构按"一 symbol 一行一时刻"设计，方便按时间窗口聚合特征。
"""

import json
import sqlite3
import time
from pathlib import Path

import pandas as pd

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS depth (
    ts INTEGER, symbol TEXT, mid REAL, spread_bps REAL,
    bid_notional REAL, ask_notional REAL, imbalance REAL,
    big_bid REAL, big_ask REAL, levels TEXT
);
CREATE INDEX IF NOT EXISTS ix_depth ON depth(symbol, ts);

CREATE TABLE IF NOT EXISTS flow (
    ts INTEGER, symbol TEXT, buy_notional REAL, sell_notional REAL,
    big_buy REAL, big_sell REAL, trades INTEGER, buy_ratio REAL
);
CREATE INDEX IF NOT EXISTS ix_flow ON flow(symbol, ts);

CREATE TABLE IF NOT EXISTS ticker (
    ts INTEGER, symbol TEXT, last REAL, pct24 REAL, quote_vol REAL
);
CREATE INDEX IF NOT EXISTS ix_ticker ON ticker(symbol, ts);

CREATE TABLE IF NOT EXISTS oi (
    ts INTEGER, symbol TEXT, oi REAL
);
CREATE INDEX IF NOT EXISTS ix_oi ON oi(symbol, ts);

CREATE TABLE IF NOT EXISTS funding (
    ts INTEGER, symbol TEXT, rate REAL, next_time INTEGER
);
CREATE INDEX IF NOT EXISTS ix_funding ON funding(symbol, ts);

CREATE TABLE IF NOT EXISTS klines (
    ts INTEGER, symbol TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL,
    PRIMARY KEY (symbol, ts)
);
"""


class Store:
    def __init__(self, path: Path = None):
        self.path = Path(path or config.DB_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False, timeout=10)
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self):
        self.conn.close()

    # ---------- 写入 ----------
    def add_depth(self, symbol, mid, spread_bps, bid_notional, ask_notional,
                  imbalance, big_bid, big_ask, levels, ts=None):
        ts = ts or int(time.time() * 1000)
        self.conn.execute(
            "INSERT INTO depth VALUES (?,?,?,?,?,?,?,?,?,?)",
            (ts, symbol, mid, spread_bps, bid_notional, ask_notional,
             imbalance, big_bid, big_ask, json.dumps(levels, separators=(",", ":"))),
        )
        self.conn.commit()

    def add_flow(self, symbol, buy_notional, sell_notional, big_buy, big_sell,
                 trades, buy_ratio, ts=None):
        ts = ts or int(time.time() * 1000)
        self.conn.execute(
            "INSERT INTO flow VALUES (?,?,?,?,?,?,?,?)",
            (ts, symbol, buy_notional, sell_notional, big_buy, big_sell, trades, buy_ratio),
        )
        self.conn.commit()

    def add_ticker(self, symbol, last, pct24, quote_vol, ts=None):
        ts = ts or int(time.time() * 1000)
        self.conn.execute(
            "INSERT INTO ticker VALUES (?,?,?,?,?)", (ts, symbol, last, pct24, quote_vol)
        )
        self.conn.commit()

    def add_oi(self, symbol, oi, ts=None):
        ts = ts or int(time.time() * 1000)
        self.conn.execute("INSERT INTO oi VALUES (?,?,?)", (ts, symbol, oi))
        self.conn.commit()

    def add_funding(self, symbol, rate, next_time, ts=None):
        ts = ts or int(time.time() * 1000)
        self.conn.execute(
            "INSERT INTO funding VALUES (?,?,?,?)", (ts, symbol, rate, next_time)
        )
        self.conn.commit()

    def add_klines(self, symbol, bars):
        """bars = [[open_time, open, high, low, close, volume, ...], ...]"""
        rows = [
            (int(b[0]), symbol, float(b[1]), float(b[2]), float(b[3]),
             float(b[4]), float(b[5]))
            for b in bars
        ]
        self.conn.executemany(
            "INSERT OR REPLACE INTO klines VALUES (?,?,?,?,?,?,?)", rows
        )
        self.conn.commit()
        return len(rows)

    def kline_count(self, symbol=None):
        if symbol:
            q = "SELECT COUNT(*) FROM klines WHERE symbol=?"
            return int(self.conn.execute(q, (symbol,)).fetchone()[0])
        return int(self.conn.execute("SELECT COUNT(*) FROM klines").fetchone()[0])

    # ---------- 查询 ----------
    def _df(self, table, symbol, since_ms):
        q = f"SELECT * FROM {table} WHERE symbol=? AND ts>=? ORDER BY ts"
        df = pd.read_sql_query(q, self.conn, params=(symbol, int(since_ms)))
        return df

    def depth(self, symbol, since_ms):
        return self._df("depth", symbol, since_ms)

    def flow(self, symbol, since_ms):
        return self._df("flow", symbol, since_ms)

    def ticker(self, symbol, since_ms):
        return self._df("ticker", symbol, since_ms)

    def oi(self, symbol, since_ms):
        return self._df("oi", symbol, since_ms)

    def funding(self, symbol, since_ms):
        return self._df("funding", symbol, since_ms)

    def latest(self, table, symbol):
        q = f"SELECT * FROM {table} WHERE symbol=? ORDER BY ts DESC LIMIT 1"
        df = pd.read_sql_query(q, self.conn, params=(symbol,))
        return df.iloc[0].to_dict() if len(df) else None

    def coverage(self, table, symbol, since_ms):
        q = f"SELECT COUNT(*) c FROM {table} WHERE symbol=? AND ts>=?"
        c = pd.read_sql_query(q, self.conn, params=(symbol, int(since_ms))).iloc[0]["c"]
        return int(c)
