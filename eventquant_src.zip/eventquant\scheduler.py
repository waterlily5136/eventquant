"""定时推送：每天固定时刻把盘面摘要推到机器人。

- 时间点来自 config.PUSH_TIMES（默认 09:30 / 21:30，北京时间）
- 已推送的时段记录在 data/push_state.json，重启不会重复推
- 错过时段超过 PUSH_MAX_DELAY_MIN 分钟就不补推
- 推送失败按 PUSH_RETRY_MIN 分钟重试
"""

import json
import threading
import time
from datetime import datetime, timedelta, timezone

from . import config
from .signals import format_digest, push


def parse_hhmm(s):
    h, m = s.strip().split(":")
    return int(h), int(m)


class PushScheduler:
    def __init__(self, state_fn, times=None, tz_offset=None, state_path=None):
        self.state_fn = state_fn
        self.times = [t.strip() for t in (times or config.PUSH_TIMES) if t.strip()]
        self.tz = timezone(
            timedelta(hours=config.PUSH_TZ_OFFSET if tz_offset is None else tz_offset)
        )
        self.state_path = state_path or config.PUSH_STATE_PATH
        self.last_slot = self._load()
        self.retry_after = 0.0
        self.lock = threading.Lock()

    # ---------- 状态 ----------
    def _load(self):
        try:
            return json.loads(self.state_path.read_text(encoding="utf-8"))["last_slot"]
        except Exception:
            return ""

    def _save(self):
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            self.state_path.write_text(
                json.dumps({"last_slot": self.last_slot}, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as e:
            print(f"[定时推送] 状态写入失败：{e}")

    def due_slots(self, now=None):
        now = now or datetime.now(self.tz)
        out = []
        for t in self.times:
            h, m = parse_hhmm(t)
            slot = now.replace(hour=h, minute=m, second=0, microsecond=0)
            key = slot.strftime("%Y-%m-%d %H:%M")
            if slot <= now and key > self.last_slot:
                out.append((slot, key))
        return out

    # ---------- 单次检查 ----------
    def tick(self, force=False):
        with self.lock:
            now = datetime.now(self.tz)
            slots = self.due_slots(now)
            if not slots and not force:
                return False
            if not force and time.time() < self.retry_after:
                return False

            key = slots[-1][1] if slots else now.strftime("%Y-%m-%d %H:%M")
            slot = slots[-1][0] if slots else now

            # 更早的时段直接记为已处理（不补推陈年老报）
            for s, k in slots[:-1]:
                self.last_slot = k

            # 关机错过太久，不补推
            if not force and now - slot > timedelta(minutes=config.PUSH_MAX_DELAY_MIN):
                self.last_slot = key
                self._save()
                return False

            try:
                state = self.state_fn()
            except Exception as e:
                self.retry_after = time.time() + 60
                print(f"[定时推送] 获取盘面失败：{e}")
                return False

            ok = push(format_digest(state), title="盘面定时播报")
            if ok:
                self.last_slot = key
                self.retry_after = 0.0
                self._save()
                print(f"[定时推送] {key} 已推送")
            else:
                self.retry_after = time.time() + config.PUSH_RETRY_MIN * 60
                print(f"[定时推送] 失败，{config.PUSH_RETRY_MIN} 分钟后重试")
            return ok

    # ---------- 常驻循环 ----------
    def run(self, stop_event=None, interval=20):
        tz_txt = f"UTC{config.PUSH_TZ_OFFSET:+d}"
        webhook = "已配置" if config.WEBHOOK_URL else "未配置（仅打印到终端）"
        print(f"[定时推送] 每日 {', '.join(self.times)}（{tz_txt}），webhook {webhook}")
        while not (stop_event and stop_event.is_set()):
            self.tick()
            if stop_event:
                stop_event.wait(interval)
            else:
                time.sleep(interval)


def start_in_background(state_fn, stop_event, times=None):
    sched = PushScheduler(state_fn, times=times)
    threading.Thread(
        target=sched.run, args=(stop_event,), daemon=True, name="push-scheduler"
    ).start()
    return sched
