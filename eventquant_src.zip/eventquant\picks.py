"""预测编号与「双认可」成绩核对。

设计目的：把每一条 ≥60% 的预测固定下来，给一个编号，
事后用真实价格自动核对对错，从而回答一个具体问题——
"我认可的那些信号，到底准不准？"

记录字段：
    id / label      序号（P-0001）与数字编号
    symbol/horizon  标的与档位（30m / 60m / 1d）
    direction       涨 / 跌
    confidence      触发时置信度
    trigger_ts      触发时刻（预测生成时间）
    target_ts       验证时刻（触发 + 周期），到期用该分钟收盘价核对
    entry_px        触发时价格
    settle_px       到期结算价
    result          win / loss / tie / None（未到期）
    ai_ack          AI 是否认可（该档位回测胜率 ≥ 阈值时自动为 True）
    user_ack        0 未表态 / 1 认可 / -1 不认可 / 2 不操作（拿不准，真实场景不会开仓）
    both            ai_ack and user_ack == 1

统计口径分五组：全部 / 我认可 / 我不操作 / AI认可 / 双认可。
"""

import json
import threading
import time
from pathlib import Path

from . import config, contract


class Picks:
    def __init__(self, path=None):
        self.path = Path(path or config.PICKS_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._data = self._load()

    # ---------- 持久化 ----------
    def _load(self):
        if not self.path.exists():
            return {"next_id": 1, "items": []}
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            d.setdefault("next_id", 1)
            d.setdefault("items", [])
            return d
        except Exception:
            return {"next_id": 1, "items": []}

    def _save(self):
        self.path.write_text(
            json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # ---------- 记录 ----------
    def record(self, ev, price, ai_ack=False):
        """把一条 ≥门槛的预测落库，返回新记录 dict。"""
        with self._lock:
            pid = int(self._data["next_id"])
            self._data["next_id"] = pid + 1
            item = {
                "id": pid,
                "label": f"P-{pid:04d}",
                "symbol": ev["symbol"],
                "horizon": ev["horizon"],
                "horizon_label": ev.get("horizon_label") or ev["horizon"],
                "direction": ev["direction"],
                "confidence": round(float(ev["confidence"]), 4),
                "tier": ev.get("tier"),
                "trigger_ts": int(ev["trigger_ts"]),
                "trigger_time": ev.get("trigger_time"),
                "target_ts": int(ev["target_ts"]),
                "target_time": ev.get("target_time"),
                "entry_px": float(price) if price else None,
                "settle_px": None,
                "result": None,
                "ai_ack": bool(ai_ack),
                "user_ack": 0,
                "both": False,
                "created_ts": contract.now_ms(),
                "settled_ts": None,
            }
            self._data["items"].append(item)
            self._save()
            return item

    def record_if_new(self, ev, price, ai_ack=False):
        """同一标的+档位+方向，在验证时间到达前只记一条。返回 None 表示已存在。"""
        key = (ev["symbol"], ev["horizon"], ev["direction"])
        with self._lock:
            for it in self._data["items"]:
                if (it["symbol"], it["horizon"], it["direction"]) == key and it["result"] is None:
                    return None
        return self.record(ev, price, ai_ack=ai_ack)

    # ---------- 认可 ----------
    def ack(self, pid, user_ack):
        """user_ack: 1 认可 / -1 不认可 / 0 撤销。返回更新后的记录。"""
        with self._lock:
            for it in self._data["items"]:
                if int(it["id"]) == int(pid):
                    it["user_ack"] = int(user_ack)
                    it["both"] = bool(it["ai_ack"]) and int(user_ack) == 1
                    it["ack_ts"] = contract.now_ms()
                    self._save()
                    return it
        raise ValueError(f"编号 {pid} 不存在")

    def ack_by_label(self, label, user_ack):
        label = str(label).upper().strip()
        pid = None
        if label.startswith("P-"):
            pid = label[2:]
        elif label.isdigit():
            pid = label
        if pid is None or not str(pid).isdigit():
            raise ValueError(f"无法识别的编号：{label}")
        return self.ack(int(pid), user_ack)

    # ---------- 结算 ----------
    def settle_due(self, price_fn, now_ms=None):
        """到期未结算的预测，用「到期那一分钟」的价格定输赢。"""
        now = now_ms or contract.now_ms()
        done = []
        with self._lock:
            pending = [it for it in self._data["items"]
                       if it["result"] is None and now >= it["target_ts"]]
        for it in pending:
            try:
                px = float(price_fn(it["symbol"], it["target_ts"]))
            except Exception:
                continue
            entry = it.get("entry_px")
            if not entry:
                continue
            res = it["direction"]
            if abs(px - entry) / entry < config.PICK_TIE_BPS / 10000.0:
                outcome = "tie"
            elif (px > entry) == (res == contract.DIR_UP):
                outcome = "win"
            else:
                outcome = "loss"
            with self._lock:
                it["settle_px"] = round(px, 8)
                it["result"] = outcome
                it["settled_ts"] = contract.now_ms()
                self._save()
            done.append(it)
        return done

    # ---------- 统计 ----------
    @staticmethod
    def _stats(items):
        s = {"total": len(items), "settled": 0, "win": 0, "loss": 0, "tie": 0,
             "win_rate": None, "pending": 0}
        for it in items:
            if it["result"] is None:
                s["pending"] += 1
            else:
                s["settled"] += 1
                s[it["result"]] += 1
        decided = s["win"] + s["loss"]
        if decided:
            s["win_rate"] = round(s["win"] / decided, 4)
        return s

    def state(self, limit=200):
        with self._lock:
            items = list(self._data["items"])
        items.sort(key=lambda x: x["id"], reverse=True)
        groups = {
            "all": items,
            "user": [i for i in items if i["user_ack"] == 1],
            "rejected": [i for i in items if i["user_ack"] == -1],
            "pass": [i for i in items if i["user_ack"] == 2],
            "ai": [i for i in items if i["ai_ack"]],
            "both": [i for i in items if i["both"]],
        }
        return {
            "next_id": self._data["next_id"],
            "stats": {k: self._stats(v) for k, v in groups.items()},
            "items": items[:limit],
            "pending": [i for i in items if i["result"] is None],
            "min_conf": config.PICK_MIN_CONF,
            "tie_bps": config.PICK_TIE_BPS,
            "calib": self.calibration(),
        }

    def calibration(self):
        """按 (标的, 档位) 和 档位 汇总历史实际胜率，用来替代虚高的模型置信度展示。
        只统计已结算记录，平局不计入分母。"""
        with self._lock:
            settled = [i for i in self._data["items"]
                       if i.get("result") in ("win", "loss", "tie")]

        def agg(rows):
            w = sum(1 for r in rows if r["result"] == "win")
            l = sum(1 for r in rows if r["result"] == "loss")
            n = w + l
            return {"win": w, "loss": l, "tie": len(rows) - n, "n": n,
                    "rate": round(w / n, 4) if n else None}

        by_sym, by_h = {}, {}
        for it in settled:
            by_sym.setdefault(f"{it['symbol']}|{it['horizon']}", []).append(it)
            by_h.setdefault(it["horizon"], []).append(it)
        return {
            "by_symbol": {k: agg(v) for k, v in by_sym.items()},
            "by_horizon": {k: agg(v) for k, v in by_h.items()},
            "min_n": 6,   # 少于该样本数只显示「样本不足」，避免小样本误导
        }

    def pending(self):
        with self._lock:
            return [i for i in self._data["items"] if i["result"] is None]

    def all_items(self):
        with self._lock:
            return list(self._data["items"])

    def get(self, pid):
        with self._lock:
            for it in self._data["items"]:
                if int(it["id"]) == int(pid):
                    return it
        return None


def format_pick_card(pk, actionable=False, calib=None):
    """推送给手机的编号卡片。calib 为历史实际胜率，用于替代虚高的模型置信度。"""
    arrow = contract.ARROW.get(pk["direction"], "")
    conf = pk["confidence"] * 100
    mark = "★可执行 " if actionable else ""
    lines = [
        f"[{pk['label']}] {mark}{pk['symbol']} {pk['horizon_label']} {arrow}{pk['direction']} "
        f"模型 {conf:.1f}%（{pk.get('tier') or '-'} 级）",
        f"触发价 {pk['entry_px']}",
        f"触发 {pk['trigger_time']} → 验证 {pk['target_time']}",
        f"AI 态度：{'认可' if pk['ai_ack'] else '观望'}",
    ]
    rate, src, n = pick_win_rate(pk, calib)
    if rate is not None:
        lines.append(f"实测胜率：{rate * 100:.0f}%（{src} 历史 {n} 单，平局不计）")
    elif calib:
        lines.append("实测胜率：样本不足，暂不能参考")
    lines += [
        "",
        f"你认可吗？回复「认可 {pk['id']}」或「不认可 {pk['id']}」",
        "（本消息不支持直接回复，请在这台电脑的聊天窗口发给我，",
        "  或打开看板在「预测编号」里点按钮）",
    ]
    return "\n".join(lines)


def pick_win_rate(pk, calib):
    """取该标的历史实际胜率；样本不足时回退到全体同档位。返回 (rate, 来源描述, 样本数)。"""
    if not calib:
        return None, "", 0
    min_n = calib.get("min_n", 6)
    m = (calib.get("by_symbol") or {}).get(f"{pk['symbol']}|{pk['horizon']}")
    if m and m.get("rate") is not None and m["n"] >= min_n:
        return m["rate"], f"{pk['symbol']} {pk['horizon_label']}", m["n"]
    m = (calib.get("by_horizon") or {}).get(pk["horizon"])
    if m and m.get("rate") is not None and m["n"] >= min_n:
        return m["rate"], f"{pk['horizon_label']} 全标的", m["n"]
    return None, "", 0
