"""全局配置：交易对、周期、阈值、限流与推送。

本程序面向上币安 U 本位永续合约的公共行情（盘口、成交流、资金费率、持仓量），
用这些市场微观结构数据做 10/30/60 分钟级别的方向概率预测。
"""

import os
import secrets
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ---------- 路径 ----------
DATA_DIR = ROOT / "data"
CACHE_DIR = DATA_DIR / "cache"
MODEL_DIR = ROOT / "models"
DB_PATH = DATA_DIR / "eventquant.db"
LOG_PATH = DATA_DIR / "eventquant.log"

# ---------- 网络 ----------
# 主站 fapi.binance.com 目前已可直连（451 已解除），它是真实市场数据，
# 价格与手机 App 一致，且 /futures/data/openInterestHist 有完整持仓量历史。
# 直连被封锁时自动走代理，再不行退回 testnet（价格会略有偏差）。
BASE_URL = "https://fapi.binance.com"
PROXY = "http://127.0.0.1:7897"
PROXIES = {"http": PROXY, "https": PROXY}
# 当前默认直连（主站直连可用），需要走代理时用 FALLBACK_BASES 的条目
DIRECT_PROXIES = {}
FALLBACK_BASES = [
    ("https://fapi.binance.com", PROXIES),
    ("https://testnet.binancefuture.com", {}),
]

# Clash 外部控制：网络断了自动换节点
CLASH_API = "http://127.0.0.1:9097"
CLASH_TOKEN = os.environ.get("CLASH_TOKEN", "2026111")
CLASH_GROUP = "🚀 节点选择"

# 网络守护：加速器断联时自动重启 Clash / 切到最快节点
NET_GUARD_SECONDS = 60          # 巡检间隔
NET_FAILS_BEFORE_FIX = 2        # 连续失败几次才动手（防抖动误判）
NET_FIX_COOLDOWN = 60           # 两次自动修复之间至少间隔 1 分钟（失败后指数退避）
NODE_STATE_PATH = DATA_DIR / "net_last_good.json"   # 记录上次验证可用的节点

# ---------- 交易对 ----------
# 只预测主流币。山寨币流动性差、插针多，模型在山寨上稳定性明显更差。
SYMBOLS = ["BTCUSDT", "ETHUSDT"]

# 强制二分类的标的：只输出「涨 / 跌」，不出现中性表述
BINARY_SYMBOLS = {"BTCUSDT", "ETHUSDT"}

# 对外展示的时区（小时偏移，默认北京时间）
DISPLAY_TZ_OFFSET = int(os.environ.get("EVENTQUANT_TZ", "8"))

# ---------- 采集 ----------
POLL_SECONDS = 10          # 每轮采集间隔
DEPTH_LIMIT = 50           # 盘口档数（20 档量价 + 聚合指标）
TRADE_LIMIT = 500          # 每轮拉取的聚合成交条数
KLINE_LIMIT = 300          # 实时特征用的 1 分钟 K 线根数
BIG_TRADE_USDT = 5000.0    # 单笔成交 ≥ 该名义视为大单
BIG_DEPTH_USDT = 20000.0   # 单档挂单 ≥ 该名义视为大额挂单

# 权重预算（币安 U 本位：X-MBX-USED-WEIGHT-1M 上限 2400）
WEIGHT_LIMIT = 2400
WEIGHT_SOFT_CAP = 0.7       # 用掉 70% 后主动降速

# ---------- 预测周期 ----------
# key: 周期名；value: 向前看多少根 1 分钟 K 线
HORIZONS = {"10m": 10, "30m": 30, "60m": 60, "1d": 1440}

# 标签阈值（单位 bps，1bps=0.01%）：未来涨跌幅超过阈值算"涨/跌"，否则"震荡"
# 实际训练时按训练集 |未来收益| 的 60 分位重新确定，这里只是缺省占位
LABEL_BPS = {"10m": 25, "30m": 45, "60m": 70, "1d": 200}

# ---------- 模型 ----------
MIN_SAMPLES = 3000          # 训练最少样本数
TRAIN_RATIO = 0.7           # 时序外推：前 70% 训练，后 30% 测试
FEE_PER_SIDE = 0.0004       # 回测手续费（单边，taker 约 0.04%）

# ---------- 置信度分级 ----------
TIER_A = 0.70
TIER_B = 0.60
MIN_CONFIDENCE = 0.60       # 全局兜底阈值
# 分周期阈值（依据 30 天主站数据回测的置信度扫描结果）：
#   60m：0.65 时胜率 72%、盈亏比 2.06；0.70 时胜率 75%、盈亏比 4.31
#   30m：0.70 时胜率 40%、盈亏比 0.44（已关闭信号）
MIN_CONF_BY_HORIZON = {"10m": 0.80, "30m": 0.70, "60m": 0.65, "1d": 0.65}

# 是否对该周期输出交易信号（概率仍然展示）
# 10 分钟窗口的典型波动约 10bps，低于一次往返手续费，回测盈亏比 0.38，只展示。
# 30 分钟：主站真实数据重训后样本外胜率 39.6%、盈亏比 0.44（0.70 档），暂时关闭信号。
# 60 分钟：胜率 71.6%、盈亏比 2.06（0.65 档），保留信号。
# 1d：30 天样本里独立样本太少，胜率 49.8%、盈亏比 0.86，只展示。
SIGNAL_ENABLED = {"10m": False, "30m": False, "60m": True, "1d": False}

# ---------- 异常告警 ----------
ALERT_RET_1M = 0.008        # 1 分钟涨跌 ≥0.8%
ALERT_OI_5M = 0.015         # 5 分钟持仓量变化 ≥1.5%
ALERT_FUNDING = 0.001       # 资金费率绝对值 ≥0.1%（单期）
ALERT_SPREAD_BPS = 8.0      # 点差 ≥8bps
ALERT_IMBALANCE = 0.60      # 盘口失衡度绝对值 ≥0.6
ALERT_VOL_Z = 3.0           # 成交量 z-score ≥3

# ---------- 网页看板 ----------
# 默认监听所有网卡，手机连同一个 Wi-Fi 就能打开；本机访问免口令，
# 其他设备必须带 token（data/panel_token.txt）。只想本机用可设 EVENTQUANT_HOST=127.0.0.1。
HOST = os.environ.get("EVENTQUANT_HOST", "0.0.0.0")
PANEL_TOKEN_PATH = DATA_DIR / "panel_token.txt"


def panel_token():
    """读取或生成面板访问口令（用于非本机访问）。"""
    p = PANEL_TOKEN_PATH
    try:
        if p.exists():
            t = p.read_text(encoding="utf-8").strip()
            if t:
                return t
    except Exception:
        pass
    t = secrets.token_hex(8)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(t + "\n", encoding="utf-8")
    except Exception:
        pass
    return t


# ---------- 推送 ----------
def _load_webhook():
    """优先读环境变量 EVENTQUANT_WEBHOOK，其次读 data/push_webhook.txt 第一行。

    文件里可以直接写简化写法，例如：pushplus:<token>
    """
    env = os.environ.get("EVENTQUANT_WEBHOOK", "").strip()
    if env:
        return env
    p = DATA_DIR / "push_webhook.txt"
    if p.exists():
        try:
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    return line
        except Exception:
            pass
    return ""


WEBHOOK_URL = _load_webhook()  # 企业微信/飞书/自建，或 pushplus:/serverchan:/bark: 简化写法
DISCLAIMER = "本程序输出仅为基于公开行情的技术分析参考，不构成任何投资建议。"

# 定时推送：每天在这些时刻（本地时区）各推一次盘面摘要
PUSH_TIMES = os.environ.get("EVENTQUANT_PUSH_TIMES", "09:30,21:30").split(",")
PUSH_TZ_OFFSET = int(os.environ.get("EVENTQUANT_PUSH_TZ", "8"))   # 北京时间 UTC+8
PUSH_MAX_DELAY_MIN = 90     # 错过时段超过这么久就不补推（避免半夜补推早报）
PUSH_RETRY_MIN = 10         # 推送失败后多少分钟重试
PUSH_STATE_PATH = DATA_DIR / "push_state.json"

# 历史下载（回测）窗口
BACKTEST_DAYS = 30

# ---------- 模拟事件合约 ----------
SIM_PATH = DATA_DIR / "event_sim.json"
SIM_PAYOUT = 0.8            # 方向正确时的净收益率：下注 1U 赢 0.8U，猜错亏 1U
SIM_MIN_STAKE = 0.1         # 单笔最小下注（U）
SIM_MAX_STAKE = 50.0        # 单笔最大下注（U）
SIM_SETTLE_SECONDS = 20     # 到期扫描间隔（秒）

# 推送“下单卡片”里的参考仓位：程序不知道你事件合约账户余额，用这个值算建议单注
EV_REF_BANKROLL = float(os.environ.get("EVENTQUANT_BANKROLL", "6.08"))
EV_STAKE_PCT = 0.05         # 单笔不超过参考本金的 5%

# ---------- 行情存档 ----------
ARCHIVE_SECONDS = 600       # 每 10 分钟追加一次
ARCHIVE_BARS = 300          # 每次拉最近 300 根 1 分钟 K 线（窗口重叠没关系，主键去重）

# AI 自动模拟下单：出现"够确信"的信号就下，用来对比准确率
SIM_AI_ENABLED = True
SIM_AI_MIN_STAKE = 5.0      # 单笔下注下限（U），按置信度向上加注，金额取整
SIM_AI_STAKE_STEP_CONF = 0.02   # 置信度每高出下限 2 个百分点，加 1U
SIM_AI_MAX_STAKE_AI = 20.0  # AI 自动下注的硬上限，防止极端置信度下重仓
SIM_AI_MIN_CONF = 0.52      # 置信度门槛：每个标的每轮取最确信且未持仓的档位
SIM_AI_HORIZONS = ("30m", "60m", "1d")   # 10m 波动小于手续费，不下
SIM_AI_MAX_OPEN = 12        # 4 个标的 × 3 个档位，每个组合最多 1 单
SIM_AI_INTERVAL = 45        # 每隔多少秒检查一次信号

# ---------- 预测编号与双认可 ----------
PICKS_PATH = DATA_DIR / "picks.json"
PICK_MIN_CONF = 0.60                  # 置信度 ≥ 该值才编号并推送
PICK_HORIZONS = ("60m",)              # 只编号 60 分钟档：实测 30m 胜率 46.9%（40 单）已证无效，保留展示但不编号
PICK_AI_WIN_RATE = 0.55               # 该档位回测胜率 ≥ 该值时，AI 自动认可
PICK_TIE_BPS = 5                      # 结算价与触发价差在 ±0.05% 内算平局

# ---------- 真实持仓监控 ----------
WATCHLIST_PATH = DATA_DIR / "watchlist.json"
WATCH_SECONDS = 60          # 每 60 秒检查一轮
WATCH_OI_PCT = 10.0         # OI 1 小时变化超过 ±10% 报警
WATCH_PRICE_1H_PCT = 3.0    # 价格 1 小时涨跌超过 ±3% 报警
WATCH_FUNDING_ABS = 0.001   # 资金费绝对值 ≥0.1%/8h 报警
WATCH_LS_EXTREME = 2.5      # 账户多空比 ≥2.5 或 ≤0.4 报警
WATCH_COOLDOWN = 3600       # 同一标的同一规则 1 小时内只推一次

# ---------- 永续合约模拟盘（纸面，不碰真钱） ----------
PERP_ENABLED = True
PERP_LEVERAGE = 3            # 固定杠杆
PERP_MARGIN = 10.0           # 每单保证金（U）≈ 70 元，按"100 块试水"的量级设
PERP_MAX_POSITIONS = 3       # 最多同时持仓数
PERP_SL_PCT = 0.006          # 止损：价格反向 0.6% 平仓
PERP_TP_PCT = 0.012          # 止盈：价格顺向 1.2% 平仓
PERP_FEE = 0.0005            # 单边手续费（taker 约 0.05%）
PERP_START_EQUITY = 100.0    # 纸面起始权益，对齐你实际能拿出的钱
PERP_PATH = DATA_DIR / "perp.json"

# ---------- 市场环境过滤器 ----------
# 作用：情绪极端 / 拥挤 / 单日波动过大时，暂停开新仓。它是避险开关，不是盈利信号。
MARKET_REFRESH = 300             # 每 5 分钟刷新一次
FNG_URL = "https://api.alternative.me/fng/?limit=1"   # 恐惧贪婪指数（免费无 key）
FNG_BLOCK_LOW = 20               # ≤ 20 极度恐慌，直接暂停开仓
FNG_BLOCK_HIGH = 80              # ≥ 80 极度贪婪，直接暂停开仓
MARKET_FUNDING_BLOCK = 0.001     # 资金费率绝对值 ≥0.1%/8h，暂停开仓
MARKET_CHG24_BLOCK = 8.0         # 24h 涨跌幅绝对值 ≥8%，暂停开仓
MARKET_LS_EXTREME = 2.5          # 账户多空比 ≥2.5 或 ≤0.4，暂停开仓
MARKET_CAUTION_SCORE = 2         # 两个及以上软风险信号，同样暂停开仓

# ---------- 外部模块对接 ----------
# 山寨币异动雷达（独立服务，预留对接）：可用时在事件合约页展示联动摘要
ALTRADAR_URL = os.environ.get("EVENTQUANT_ALTRADAR_URL", "http://127.0.0.1:8778")
ALTRADAR_TIMEOUT = 90       # 秒，后台线程拉取雷达结果，冷启动首次扫描较慢
ALTRADAR_TTL = 120          # 秒，联动结果缓存时长
