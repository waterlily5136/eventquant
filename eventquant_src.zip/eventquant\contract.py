"""事件合约标准化输出层。

网页、命令行、推送都不直接使用模型原始的三分类结果，而是统一经过这里，
得到带完整时间戳的 Event 结构；新增输出渠道（如自动执行器）只要消费 Event 即可。

Event 字段：
  symbol / horizon / horizon_min
  trigger_ts / trigger_time    事件触发时间（本轮预测生成时刻）
  target_ts / target_time      预测对应的验证时间节点（trigger + horizon）
  data_as_of_ts / data_as_of   特征所用最后一根已收盘 K 线时间
  direction                    对外方向：BTC、ETH 只有「涨 / 跌」
  probabilities                对外概率（BTC、ETH 为二分类）
  confidence / tier / actionable / enabled / binary / drivers / book / summary
"""

import time
from datetime import datetime, timedelta, timezone

from . import config
from .model import tier_of

DIR_UP = "涨"
DIR_DOWN = "跌"
DIR_FLAT = "震荡"

MODEL_TO_DIR = {"上涨": DIR_UP, "下跌": DIR_DOWN, "震荡": DIR_FLAT}
ARROW = {DIR_UP: "↑", DIR_DOWN: "↓", DIR_FLAT: "→"}

_TZ = timezone(timedelta(hours=config.DISPLAY_TZ_OFFSET))


def now_ms():
    return int(time.time() * 1000)


def fmt_ms(ms):
    """时间戳（毫秒）→ 本地时间字符串。"""
    if not ms:
        return ""
    return datetime.fromtimestamp(int(ms) / 1000, _TZ).strftime("%Y-%m-%d %H:%M:%S")


def is_binary(symbol):
    return str(symbol).upper() in config.BINARY_SYMBOLS


def horizon_label(minutes):
    """把分钟数变成人话：10分钟 / 1小时 / 1天。"""
    minutes = int(minutes)
    if minutes % 1440 == 0:
        return f"{minutes // 1440}天"
    if minutes % 60 == 0:
        return f"{minutes // 60}小时"
    return f"{minutes}分钟"


def build_event(symbol, horizon, prediction, trigger_ms=None, as_of_ms=None, book=None):
    """把一次模型输出包装成对外事件（含触发起止时间）。"""
    trigger_ms = int(trigger_ms or now_ms())
    minutes = int(config.HORIZONS[horizon])
    target_ms = trigger_ms + minutes * 60_000
    binary = is_binary(symbol)
    raw = prediction.get("probabilities", {}) or {}

    if binary:
        # 只用涨/跌两侧的相对强弱，剔除中性项后重新归一
        up = float(raw.get("上涨", 0.0) or 0.0)
        down = float(raw.get("下跌", 0.0) or 0.0)
        total = up + down
        if total <= 0:
            p_up = p_down = 0.5
        else:
            p_up, p_down = up / total, down / total
        direction = DIR_UP if p_up >= p_down else DIR_DOWN
        confidence = max(p_up, p_down)
        probabilities = {DIR_UP: round(p_up, 4), DIR_DOWN: round(p_down, 4)}
    else:
        direction = MODEL_TO_DIR.get(prediction.get("direction", ""), prediction.get("direction", ""))
        confidence = float(prediction.get("confidence", 0.0))
        probabilities = {
            MODEL_TO_DIR.get(k, k): round(float(v), 4) for k, v in raw.items()
        }

    enabled = bool(prediction.get("enabled", True))
    min_conf = config.MIN_CONF_BY_HORIZON.get(horizon, config.MIN_CONFIDENCE)
    actionable = enabled and direction in (DIR_UP, DIR_DOWN) and confidence >= min_conf

    ev = {
        "id": f"{symbol}-{horizon}-{trigger_ms}",
        "symbol": symbol,
        "horizon": horizon,
        "horizon_min": minutes,
        "horizon_label": horizon_label(minutes),
        "trigger_ts": trigger_ms,
        "trigger_time": fmt_ms(trigger_ms),
        "target_ts": target_ms,
        "target_time": fmt_ms(target_ms),
        "data_as_of_ts": int(as_of_ms) if as_of_ms else None,
        "data_as_of": fmt_ms(as_of_ms),
        "direction": direction,
        "binary": binary,
        "probabilities": probabilities,
        "confidence": round(confidence, 4),
        "tier": tier_of(confidence),
        "actionable": actionable,
        "enabled": enabled,
        "drivers": prediction.get("drivers", []),
        "book": book or {},
    }
    ev["summary"] = summary_line(ev)
    return ev


def summary_line(ev):
    """一句话结论：方向 + 置信度 + 触发/验证时间。"""
    conf = ev["confidence"] * 100
    return (
        f"{ev['symbol']} {ev['horizon_label']} "
        f"{ARROW.get(ev['direction'], '')}{ev['direction']} {conf:.1f}%"
        f"｜触发 {ev['trigger_time']} → 验证 {ev['target_time']}"
    )


def format_order_card(ev, price=None):
    """手机推送用的“下单卡片”：币种、方向、时间段、剩余时间、建议仓位。

    事件合约没有公开 API，这条消息的作用是让人 3 秒内看懂并手动下注。
    """
    conf = ev["confidence"] * 100
    arrow = ARROW.get(ev["direction"], "")
    remain = max(0, int((ev["target_ts"] - now_ms()) / 60_000))
    stake = round(config.EV_REF_BANKROLL * config.EV_STAKE_PCT, 2)
    win = round(stake * config.SIM_PAYOUT, 2)
    lines = [
        f"{ev['symbol']}  {ev['horizon_label']}  {arrow}{ev['direction']}  "
        f"置信度 {conf:.1f}%（{ev['tier']} 级）",
    ]
    if price:
        lines.append(f"现价 {price:,.2f}" if price >= 100 else f"现价 {price:.5g}")
    lines.append(
        f"触发 {ev['trigger_time'][11:]}  →  验证 {ev['target_time'][11:]}"
        f"（还剩 {remain} 分钟）"
    )
    prob = ev["probabilities"]
    if ev.get("binary"):
        lines.append(
            f"概率：涨 {prob.get(DIR_UP, 0) * 100:.0f}% / 跌 {prob.get(DIR_DOWN, 0) * 100:.0f}%"
        )
    lines.append(
        f"建议单注 {stake:.2f}U（参考本金 {config.EV_REF_BANKROLL:.2f}U 的 "
        f"{config.EV_STAKE_PCT * 100:.0f}%）"
    )
    lines.append(f"猜对 +{win:.2f}U，猜错 -{stake:.2f}U（赔付 0.8 倍）")
    lines.append("事件合约无 API，请到 App 手动选择「涨 / 跌」并输入金额。")
    return "\n".join(lines)


def format_event_text(ev):
    """命令行 / 推送用的多行文本。"""
    lines = [
        f"{ev['symbol']}  {ev['horizon']}  {ARROW.get(ev['direction'], '')} {ev['direction']}  "
        f"置信度 {ev['confidence'] * 100:.1f}%  等级 {ev['tier']}",
        f"  触发时间 {ev['trigger_time']}  →  验证时间 {ev['target_time']}",
    ]
    if ev.get("data_as_of"):
        lines.append(f"  特征数据截止 {ev['data_as_of']}（最后一根已收盘 1 分钟 K 线）")
    prob = ev["probabilities"]
    if ev.get("binary"):
        lines.append(f"  概率：涨 {prob.get(DIR_UP, 0) * 100:.1f}% / 跌 {prob.get(DIR_DOWN, 0) * 100:.1f}%")
    else:
        lines.append(
            "  概率：上涨 {:.1f}% / 震荡 {:.1f}% / 下跌 {:.1f}%".format(
                prob.get(DIR_UP, 0) * 100,
                prob.get(DIR_FLAT, 0) * 100,
                prob.get(DIR_DOWN, 0) * 100,
            )
        )
    if ev.get("drivers"):
        lines.append("  主要驱动：" + "，".join(ev["drivers"]))
    b = ev.get("book") or {}
    if b:
        lines.append(
            "  盘口：失衡 {:.2f}｜点差 {:.1f}bps｜主动买占比 {:.1f}%｜大单净 {:.0f}U".format(
                b.get("ob_imb_mean", 0),
                b.get("spread_bps_mean", 0),
                b.get("taker_buy_ratio", 0.5) * 100,
                b.get("big_trade_net", 0),
            )
        )
    if ev["actionable"]:
        lines.append(f"  >>> 可参考信号（{ev['tier']} 级）")
    elif not ev.get("enabled", True):
        lines.append("  该周期只展示概率：波动小于往返手续费，不输出交易信号")
    else:
        lines.append("  置信度未达阈值，不出信号")
    return "\n".join(lines)
