"""命令行入口。


常用：
    python -m eventquant collect               # 只采集，不下结论
    python -m eventquant watch                 # 采集 + 预测 + 信号/告警
    python -m eventquant train                 # 下载历史并训练、保存模型
    python -m eventquant backtest              # 回测并打印胜率/盈亏比
    python -m eventquant predict               # 单次预测（用最新行情）
"""

import argparse
import time
from datetime import datetime, timezone

from . import config, contract
from .api import BinancePublic
from .backtest import print_table, run as run_backtest
from .collector import Collector
from .features import book_features, coverage_ok, live_core
from .model import load, predict_row
from .signals import check_alerts, disclaimer, format_prediction, push
from .store import Store


def parse_symbols(s):
    if not s:
        return config.SYMBOLS
    return [x.strip().upper() for x in s.split(",") if x.strip()]


def now_ms():
    return int(time.time() * 1000)


def predict_symbols(api, store, symbols, notify=True):
    lines = []
    for sym in symbols:
        try:
            core = live_core(api, sym)
        except Exception as e:
            lines.append(f"{sym} 特征获取失败：{e}")
            continue
        trigger_ms = contract.now_ms()
        as_of_ms = int(core.get("_as_of_ms") or 0)
        book = book_features(store, sym)
        covered = coverage_ok(store, sym, 10)
        for h in config.HORIZONS:
            bundle = load(h)
            if not bundle:
                lines.append(f"[{h}] 模型未训练，先运行 python -m eventquant train")
                break
            p = predict_row(bundle, core)
            ev = contract.build_event(
                sym, h, p, trigger_ms=trigger_ms, as_of_ms=as_of_ms, book=book.get(h, {})
            )
            text = format_prediction(ev)
            lines.append(text)
            if notify and ev["actionable"]:
                push(text + "\n" + disclaimer(), title=f"{sym} {h}")
        if not covered:
            lines.append(f"（{sym} 盘口样本不足 10 分钟，盘口指标仅作参考）")
    return "\n\n".join(lines)


def cmd_collect(args):
    col = Collector()
    print(f"开始采集 {col.symbols}，每轮 {config.POLL_SECONDS}s。Ctrl+C 停止。")
    try:
        col.run(max_rounds=args.rounds)
    except KeyboardInterrupt:
        print("\n已停止采集")


def cmd_watch(args):
    col = Collector()
    api, store = col.api, col.store
    state = {"last": 0.0, "last_alert": {}}
    interval = args.predict_every

    def on_round(_):
        if time.time() - state["last"] < interval:
            return
        state["last"] = time.time()
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        print(f"\n===== 预测 {ts} UTC =====")
        print(predict_symbols(api, store, col.symbols))
        for sym in col.symbols:
            for a in check_alerts(store, sym, now_ms()):
                key = a.split(" ")[1] if " " in a else a
                if time.time() - state["last_alert"].get((sym, key), 0) > 300:
                    state["last_alert"][(sym, key)] = time.time()
                    push(a, title="异常告警")
        print("\n" + disclaimer())

    print(
        f"持续采集 {col.symbols}，每 {config.POLL_SECONDS}s 一轮，"
        f"每 {interval}s 出一次预测。Ctrl+C 停止。"
    )
    print(disclaimer())
    try:
        col.run(max_rounds=args.rounds, on_round=on_round)
    except KeyboardInterrupt:
        print("\n已停止")


def cmd_train(args):
    api = BinancePublic()
    summary = run_backtest(
        api,
        symbols=parse_symbols(args.symbols),
        days=args.days,
        force=args.force,
        save_models=True,
    )
    print_table(summary)
    print("\n模型已保存到 models/")


def cmd_backtest(args):
    api = BinancePublic()
    summary = run_backtest(
        api,
        symbols=parse_symbols(args.symbols),
        days=args.days,
        force=args.force,
        save_models=False,
    )
    print_table(summary)


def cmd_predict(args):
    api = BinancePublic()
    store = Store()
    print(predict_symbols(api, store, parse_symbols(args.symbols)))
    print("\n" + disclaimer())


def cmd_picks(args):
    """查看编号、表态、核对统计。"""
    from .picks import Picks

    p = Picks()
    act = args.action or "list"

    if act in ("ack", "reject", "undo"):
        val = {"ack": 1, "reject": -1, "undo": 0}[act]
        it = p.ack_by_label(args.id, val)
        word = {1: "认可", -1: "不认可", 0: "撤销表态"}[val]
        print(f"{it['label']} {it['symbol']} {it['horizon_label']} {it['direction']} "
              f"{it['confidence']*100:.1f}% → 已标记为「{word}」")
        if it["both"]:
            print("这条现在是【双认可】，会单独计入双认可正确率。")
        return

    st = p.state()
    if act == "pending":
        rows = st["pending"]
        print(f"待验证 {len(rows)} 条：")
        for it in rows:
            print(f"  {it['label']} {it['symbol']:10s} {it['horizon_label']} {it['direction']} "
                  f"{it['confidence']*100:.1f}% 触发 {it['trigger_time']} → 验证 {it['target_time']}")
        return

    if act == "stats":
        names = {"all": "全部编号", "user": "我认可", "ai": "AI 认可",
                 "both": "双认可", "rejected": "我不认可"}
        print(f"{'分组':<10}{'正确率':>10}{'已结算':>8}{'待验证':>8}{'对':>5}{'错':>5}{'平':>5}")
        for k, name in names.items():
            m = st["stats"][k]
            wr = "--" if m["win_rate"] is None else f"{m['win_rate']*100:.1f}%"
            print(f"{name:<10}{wr:>10}{m['settled']:>8}{m['pending']:>8}"
                  f"{m['win']:>5}{m['loss']:>5}{m['tie']:>5}")
        return

    rows = st["items"][:args.limit]
    if not rows:
        print("还没有编号记录。")
        return
    print(f"{'编号':<8}{'标的':<12}{'档位':<7}{'方向':<5}{'置信':>7}{'结果':>7}{'AI':>6}{'我的':>7}")
    for it in rows:
        res = {"win": "对", "loss": "错", "tie": "平", None: "待验证"}[it["result"]]
        ua = {1: "认可", -1: "不认可", 0: "-"}[it["user_ack"]]
        mark = "★" if it["both"] else " "
        print(f"{it['label']:<8}{it['symbol']:<12}{it['horizon_label']:<7}{it['direction']:<5}"
              f"{it['confidence']*100:>6.1f}%{res:>7}{'认可' if it['ai_ack'] else '观望':>6}{ua:>7}{mark}")


def cmd_net(args):
    """检查加速器状态，必要时自动换节点。"""
    from .netguard import NetGuard

    g = NetGuard()
    ok, how = g.probe()
    print(f"币安连通性：{'正常' if ok else '不通'}（{how}）")
    print(f"Clash 外部控制：{'可用' if g.clash_alive() else '不可用'}")
    if args.check:
        return
    if not ok:
        print("连接不通，开始自动修复……")
        g.repair()
        return
    now, ranked = g.rank_nodes()
    print(f"当前节点：{now}")
    print(f"可访问币安的节点：{len(ranked)} 个")
    for d, n in ranked[:10]:
        print(f"  {d:>5} ms  {n}")
    if args.force and ranked:
        best_d, best = ranked[0]
        if best != now:
            print(f"切换到 {best}（{best_d}ms）：{'成功' if g.switch(best) else '失败'}")
        else:
            print("当前已是最快节点")


def cmd_serve(args):
    from .web import serve

    serve(
        port=args.port,
        open_browser=not args.no_browser,
        schedule=not args.no_push,
        push_times=args.push_times or None,
    )


def cmd_push(args):
    """立即推一条盘面摘要（用于测试 webhook 或手动播报）。"""
    from .signals import format_digest, push
    from .web import WebApp

    app = WebApp()
    state = app.build_state()
    text = format_digest(state)
    if args.dry:
        print(text)
        print("\n[dry-run] 未发送")
        return
    ok = push(text, title="盘面定时播报")
    print("\n[推送] 成功" if ok else "\n[推送] 失败")


def cmd_schedule(args):
    """常驻定时推送（独立进程，不启动网页）。"""
    from .scheduler import PushScheduler
    from .web import WebApp

    app = WebApp()
    app.start()
    sched = PushScheduler(app.get_state, times=args.times or None)
    print("定时推送已启动，Ctrl+C 停止")
    try:
        sched.run(app.stop_event)
    except KeyboardInterrupt:
        print("\n已停止")
    finally:
        app.stop()


def build_parser():
    p = argparse.ArgumentParser(prog="eventquant", description="币安永续合约走势概率分析")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("collect", help="只采集行情数据").add_argument(
        "--rounds", type=int, default=None, help="采集轮数（默认无限）"
    )

    w = sub.add_parser("watch", help="采集 + 实时预测 + 信号与告警")
    w.add_argument("--predict-every", type=int, default=60, help="预测间隔秒数")
    w.add_argument("--rounds", type=int, default=None, help="采集轮数（默认无限）")

    for name, help_text in (("train", "训练并保存模型"), ("backtest", "历史回测")):
        s = sub.add_parser(name, help=help_text)
        s.add_argument("--days", type=int, default=config.BACKTEST_DAYS)
        s.add_argument("--symbols", default="")
        s.add_argument("--force", action="store_true", help="强制重新下载历史")

    pr = sub.add_parser("predict", help="单次预测")
    pr.add_argument("--symbols", default="")

    sv = sub.add_parser("serve", help="启动网页看板")
    sv.add_argument("--port", type=int, default=8777)
    sv.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    sv.add_argument("--no-push", action="store_true", help="关闭定时推送")
    sv.add_argument("--push-times", default="", help="覆盖推送时刻，如 09:30,21:30")

    ps = sub.add_parser("push", help="立即推送一条盘面摘要")
    ps.add_argument("--dry", action="store_true", help="只打印不发送")

    sc = sub.add_parser("schedule", help="常驻定时推送（不带网页）")
    sc.add_argument("--times", default="", help="推送时刻，如 09:30,21:30")

    pk = sub.add_parser("picks", help="预测编号：列表 / 待验证 / 表态 / 正确率")
    pk.add_argument("action", nargs="?", default="list",
                    choices=["list", "pending", "stats", "ack", "reject", "undo"],
                    help="list 列表，pending 待验证，stats 正确率，ack 认可，reject 不认可，undo 撤销")
    pk.add_argument("id", nargs="?", default="", help="编号，如 12 或 P-0012")
    pk.add_argument("--limit", type=int, default=30)

    nt = sub.add_parser("net", help="检查加速器；不通则自动换节点")
    nt.add_argument("--check", action="store_true", help="只看连通性，不测速")
    nt.add_argument("--force", action="store_true", help="连通时也切到最快节点")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.cmd == "collect":
        cmd_collect(args)
    elif args.cmd == "watch":
        cmd_watch(args)
    elif args.cmd == "train":
        cmd_train(args)
    elif args.cmd == "backtest":
        cmd_backtest(args)
    elif args.cmd == "predict":
        cmd_predict(args)
    elif args.cmd == "serve":
        cmd_serve(args)
    elif args.cmd == "push":
        cmd_push(args)
    elif args.cmd == "schedule":
        cmd_schedule(args)
    elif args.cmd == "picks":
        cmd_picks(args)
    elif args.cmd == "net":
        cmd_net(args)


if __name__ == "__main__":
    main()
