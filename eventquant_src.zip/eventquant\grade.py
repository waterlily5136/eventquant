"""预测成绩单：把编号账本换算成「如果真按它下单，会赚还是亏」。

两种口径都会算，因为它们的答案经常相反：

1. 事件合约口径（主口径）
   平台实际玩法是二元赔付：猜对拿 80% 利润，猜错亏掉本金。
   胜率 51.6% 在这套规则下是亏的（盈亏平衡点 55.6%）。

2. 方向性口径（参考）
   把预测当成普通合约的方向信号，按真实涨跌幅结算，
   双边手续费 0.04%。它回答的是「这个信号本身有没有 alpha」。

所有指标都是「事后对账」，不含任何预测。
"""

import math

from . import config


def _max_drawdown(equity):
    peak = equity[0] if equity else 0
    mdd = 0.0
    for e in equity:
        peak = max(peak, e)
        if peak > 0:
            mdd = max(mdd, (peak - e) / peak)
    return mdd


def _bucket(rows, key_fn):
    out = {}
    for r in rows:
        k = key_fn(r)
        b = out.setdefault(k, {"n": 0, "win": 0, "loss": 0, "pnl": 0.0})
        b["n"] += 1
        if r["result"] == "win":
            b["win"] += 1
        elif r["result"] == "loss":
            b["loss"] += 1
        b["pnl"] += r["pnl"]
    for b in out.values():
        decided = b["win"] + b["loss"]
        b["win_rate"] = round(b["win"] / decided, 4) if decided else None
        b["pnl"] = round(b["pnl"], 2)
    return out


def report(items, stake=10.0, start_equity=1000.0, payout=None):
    """items: picks 的全部记录。返回成绩单 dict。"""
    payout = config.SIM_PAYOUT if payout is None else payout
    fee = config.FEE_PER_SIDE

    rows = []
    for it in items:
        if it.get("result") not in ("win", "loss", "tie"):
            continue
        entry, settle = it.get("entry_px"), it.get("settle_px")
        if not entry or not settle:
            continue
        # ---- 事件合约口径：二元赔付 ----
        if it["result"] == "win":
            pnl = stake * payout
        elif it["result"] == "loss":
            pnl = -stake
        else:
            pnl = 0.0
        # ---- 方向性口径：真实涨跌幅减双边手续费 ----
        move = (settle - entry) / entry
        if it["direction"] == "跌":
            move = -move
        linear = (move - fee * 2) * stake

        rows.append({
            "id": it["id"],
            "label": it.get("label"),
            "symbol": it["symbol"],
            "horizon": it["horizon"],
            "direction": it["direction"],
            "confidence": it.get("confidence"),
            "result": it["result"],
            "pnl": round(pnl, 4),
            "linear": round(linear, 4),
            "time": it.get("target_time") or "",
            "ts": it.get("settled_ts") or it.get("target_ts") or 0,
        })

    rows.sort(key=lambda r: r["ts"])

    equity = start_equity
    curve = []
    for r in rows:
        equity += r["pnl"]
        curve.append({"t": r["time"], "e": round(equity, 2)})

    n = len(rows)
    wins = sum(1 for r in rows if r["result"] == "win")
    losses = sum(1 for r in rows if r["result"] == "loss")
    ties = n - wins - losses
    decided = wins + losses
    total_pnl = round(sum(r["pnl"] for r in rows), 2)
    total_linear = round(sum(r["linear"] for r in rows), 2)

    gross_win = sum(r["pnl"] for r in rows if r["pnl"] > 0)
    gross_loss = -sum(r["pnl"] for r in rows if r["pnl"] < 0)
    pf = round(gross_win / gross_loss, 2) if gross_loss > 0 else None

    rets = [r["pnl"] / stake for r in rows]
    mean = sum(rets) / n if n else 0.0
    var = sum((x - mean) ** 2 for x in rets) / n if n else 0.0
    sd = math.sqrt(var)
    sharpe = round(mean / sd, 2) if sd > 0 else None

    # 连续亏损最长记录——比胜率更能反映心态压力
    streak = worst = 0
    for r in rows:
        if r["pnl"] < 0:
            streak += 1
            worst = max(worst, streak)
        elif r["pnl"] > 0:
            streak = 0

    return {
        "mode": "事件合约（赔付 %.0f%%）" % (payout * 100),
        "stake": stake,
        "start_equity": start_equity,
        "equity_final": round(equity, 2),
        "n": n,
        "win": wins,
        "loss": losses,
        "tie": ties,
        "win_rate": round(wins / decided, 4) if decided else None,
        "breakeven": round(1 / (1 + payout), 4),
        "total_pnl": total_pnl,
        "total_pnl_pct": round(total_pnl / start_equity * 100, 2),
        "total_linear": total_linear,
        "profit_factor": pf,
        "sharpe": sharpe,
        "expectancy": round(total_pnl / n, 2) if n else None,
        "max_drawdown": round(_max_drawdown([c["e"] for c in curve]) * 100, 2) if curve else 0.0,
        "max_loss_streak": worst,
        "by_direction": _bucket(rows, lambda r: r["direction"]),
        "by_symbol": _bucket(rows, lambda r: r["symbol"]),
        "by_horizon": _bucket(rows, lambda r: r["horizon"]),
        "curve": curve,
        "recent": rows[-8:][::-1],
    }
