"""永续合约模拟盘（纸面）。

用途：把模型信号当成「真的开了一张 3 倍多/空单」来记账，
每一单都留下开仓原因、当时判断、预期走势，供事后复盘。

不做什么：
    - 不连交易接口，不碰真钱
    - 不模拟穿仓、强平、资金费率（简化）
    - 止损止盈用轮询到的标记价判断，抓不到瞬间插针
"""

import json
import threading
import time

from . import config


def _now_ms():
    return int(time.time() * 1000)


class PerpPaper:
    def __init__(self, path=None):
        self.path = path or config.PERP_PATH
        self._lock = threading.Lock()
        self._data = self._load()

    # ---------- 存储 ----------
    def _load(self):
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"free": config.PERP_START_EQUITY, "seq": 0,
                    "positions": [], "closed": []}

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------- 查询 ----------
    def find(self, pid):
        with self._lock:
            return next((p for p in self._data["positions"] if p["id"] == pid), None)

    def state(self, prices=None):
        """prices: {symbol: mark_price}，用于算浮动盈亏。"""
        prices = prices or {}
        with self._lock:
            d = self._data
            locked = 0.0
            upnl = 0.0
            rows = []
            for p in d["positions"]:
                px = prices.get(p["symbol"]) or p["entry_px"]
                pnl = self._pnl(p, px)
                upnl += pnl
                locked += p["margin"]
                rows.append({
                    "id": p["id"], "symbol": p["symbol"],
                    "side": "多" if p["side"] > 0 else "空",
                    "leverage": p["leverage"],
                    "entry_px": p["entry_px"], "mark_px": round(px, 6),
                    "notional": round(p["notional"], 2),
                    "margin": p["margin"],
                    "pnl": round(pnl, 2),
                    "pnl_pct": round(pnl / p["margin"] * 100, 2) if p["margin"] else 0,
                    "sl_px": round(p["sl_px"], 6), "tp_px": round(p["tp_px"], 6),
                    "sl_pct": round(p.get("sl_pct", config.PERP_SL_PCT * 100), 2),
                    "tp_pct": round(p.get("tp_pct", config.PERP_TP_PCT * 100), 2),
                    "entry_time": p["entry_time"],
                    "target_time": p["target_time"],
                    "minutes_left": max(0, int((p["target_ts"] - _now_ms()) / 60000)),
                    "confidence": p["confidence"],
                    "reason": p["reason"],
                    "expect": p["expect"],
                    "judge": p["judge"],
                })
            rows.sort(key=lambda r: r["entry_time"])
            closed = d["closed"][-30:][::-1]
            wins = sum(1 for c in d["closed"] if c["pnl"] > 0)
            total = sum(c["pnl"] for c in d["closed"])
            return {
                "equity": round(d["free"] + locked + upnl, 2),
                "free": round(d["free"], 2),
                "locked": round(locked, 2),
                "upnl": round(upnl, 2),
                "max_positions": config.PERP_MAX_POSITIONS,
                "leverage": config.PERP_LEVERAGE,
                "positions": rows,
                "closed": closed,
                "closed_n": len(d["closed"]),
                "closed_win": wins,
                "closed_win_rate": round(wins / len(d["closed"]), 4) if d["closed"] else None,
                "realized": round(total, 2),
            }

    @staticmethod
    def _pnl(p, px):
        move = (px - p["entry_px"]) * p["side"] / p["entry_px"]
        gross = move * p["notional"]
        fee = p["notional"] * config.PERP_FEE * 2
        return gross - fee

    # ---------- 开仓 ----------
    def open_from_pick(self, pick, market=None, price=None):
        """一条新编号 → 一张模拟永续单。方向来自模型，仓位固定。"""
        if not config.PERP_ENABLED:
            return None
        entry = price or pick.get("entry_px")
        if not entry:
            return None
        with self._lock:
            d = self._data
            if len(d["positions"]) >= config.PERP_MAX_POSITIONS:
                return None
            if any(p["symbol"] == pick["symbol"] for p in d["positions"]):
                return None
            margin = config.PERP_MARGIN
            if d["free"] < margin:
                return None

            side = 1 if pick["direction"] == "涨" else -1
            notional = margin * config.PERP_LEVERAGE
            d["seq"] += 1
            sl = entry * (1 - config.PERP_SL_PCT * side)
            tp = entry * (1 + config.PERP_TP_PCT * side)

            mkt = (market or {}).get("items") or {}
            fng_item = mkt.get("fng") or {}
            fng = fng_item.get("value") if isinstance(fng_item, dict) else None
            lvl = (market or {}).get("label") or "未知"

            conf = round(pick.get("confidence", 0) * 100, 1)
            reason = (f"{pick['symbol']} {pick['horizon_label'] if 'horizon_label' in pick else pick['horizon']}"
                      f" 模型给出「{pick['direction']}」，置信度 {conf}%")
            if fng is not None:
                reason += f"；当时市场「{lvl}」，恐慌贪婪 {fng}"

            judge = (f"{'看涨' if side > 0 else '看跌'} {pick['horizon']}，"
                     f"目标价 {tp:.2f}（+{config.PERP_TP_PCT * 100:.2f}%），"
                     f"跌破 {sl:.2f}（-{config.PERP_SL_PCT * 100:.2f}%）离场")
            expect = (f"预期在 {pick['horizon']} 内朝{'上' if side > 0 else '下'}运行；"
                      f"若先触及止损则说明信号失效，无论盈亏到点强制平仓")

            pos = {
                "id": f"#{d['seq']}",
                "symbol": pick["symbol"],
                "side": side,
                "entry_px": float(entry),
                "entry_ts": _now_ms(),
                "entry_time": time.strftime("%m-%d %H:%M"),
                "target_ts": pick.get("target_ts") or (_now_ms() + 3600_000),
                "target_time": pick.get("target_time", ""),
                "margin": margin,
                "leverage": config.PERP_LEVERAGE,
                "notional": notional,
                "sl_px": sl,
                "tp_px": tp,
                "confidence": pick.get("confidence"),
                "reason": reason,
                "expect": expect,
                "judge": judge,
                "pick": pick.get("label"),
            }
            d["positions"].append(pos)
            d["free"] -= margin
            self._save()
            return pos

    def open_manual(self, symbol, side, price, margin=None, note="",
                    sl_pct=None, tp_pct=None):
        """手动开一张纸面单（山寨雷达点「观察」过来）。

        side: "多" / "空"。
        sl_pct / tp_pct: 止损止盈的百分比（0.6 表示 0.6%），传 0 表示不设。
        """
        if not config.PERP_ENABLED:
            raise ValueError("永续模拟盘已关闭")
        if side not in ("多", "空"):
            raise ValueError("方向只能是 多 或 空")
        symbol = str(symbol).upper()
        entry = float(price)
        if entry <= 0:
            raise ValueError("价格无效")
        margin = round(float(margin or config.PERP_MARGIN), 2)
        if margin < 1:
            raise ValueError("保证金至少 1 U")

        sl_pct = config.PERP_SL_PCT * 100 if sl_pct is None else float(sl_pct)
        tp_pct = config.PERP_TP_PCT * 100 if tp_pct is None else float(tp_pct)
        if sl_pct < 0 or tp_pct < 0:
            raise ValueError("止损止盈不能是负数")
        if sl_pct > 50 or tp_pct > 200:
            raise ValueError("止损最多 50%，止盈最多 200%")

        with self._lock:
            d = self._data
            if len(d["positions"]) >= config.PERP_MAX_POSITIONS:
                raise ValueError(f"最多同时持有 {config.PERP_MAX_POSITIONS} 张")
            if any(p["symbol"] == symbol for p in d["positions"]):
                raise ValueError(f"{symbol} 已经有持仓了")
            if d["free"] < margin:
                raise ValueError(f"可用保证金不足（剩 {d['free']:.2f} U）")

            s = 1 if side == "多" else -1
            notional = margin * config.PERP_LEVERAGE
            d["seq"] += 1
            sl = entry * (1 - sl_pct / 100 * s) if sl_pct > 0 else 0.0
            tp = entry * (1 + tp_pct / 100 * s) if tp_pct > 0 else 0.0
            ts = _now_ms()
            pos = {
                "id": f"#{d['seq']}",
                "symbol": symbol,
                "side": s,
                "entry_px": entry,
                "entry_ts": ts,
                "entry_time": time.strftime("%m-%d %H:%M"),
                "target_ts": ts + 24 * 3600_000,
                "target_time": time.strftime("%m-%d %H:%M", time.localtime(ts / 1000 + 86400)),
                "margin": margin,
                "leverage": config.PERP_LEVERAGE,
                "notional": notional,
                "sl_px": sl,
                "tp_px": tp,
                "sl_pct": sl_pct,
                "tp_pct": tp_pct,
                "confidence": None,
                "reason": note or f"手动开仓：{symbol} 雷达给出「{side}」",
                "expect": (f"预期 24 小时{'上涨' if s > 0 else '下跌'}；"
                           f"触及止损止盈或满 24 小时自动平仓"),
                "judge": (f"{'看涨' if s > 0 else '看跌'}，"
                          + (f"目标价 {tp:.6g}（+{tp_pct:.2f}%），" if tp > 0 else "未设止盈，")
                          + (f"跌破 {sl:.6g}（-{sl_pct:.2f}%）离场" if sl > 0 else "未设止损")),
                "pick": None,
            }
            d["positions"].append(pos)
            d["free"] -= margin
            self._save()
            return pos

    def set_sl_tp(self, pid, sl_pct=None, tp_pct=None):
        """改一张持仓的止损止盈（按百分比，相对开仓价）。0 = 取消。"""
        with self._lock:
            d = self._data
            pos = next((p for p in d["positions"] if p["id"] == pid), None)
            if not pos:
                raise ValueError("找不到这张持仓")
            s, entry = pos["side"], pos["entry_px"]
            if sl_pct is not None:
                sl_pct = float(sl_pct)
                if sl_pct < 0 or sl_pct > 50:
                    raise ValueError("止损要在 0~50% 之间")
                pos["sl_pct"] = sl_pct
                pos["sl_px"] = entry * (1 - sl_pct / 100 * s) if sl_pct > 0 else 0.0
            if tp_pct is not None:
                tp_pct = float(tp_pct)
                if tp_pct < 0 or tp_pct > 200:
                    raise ValueError("止盈要在 0~200% 之间")
                pos["tp_pct"] = tp_pct
                pos["tp_px"] = entry * (1 + tp_pct / 100 * s) if tp_pct > 0 else 0.0
            pos["judge"] = (
                f"{'看涨' if s > 0 else '看跌'}，"
                + (f"目标价 {pos['tp_px']:.6g}（+{pos['tp_pct']:.2f}%），"
                   if pos["tp_px"] > 0 else "未设止盈，")
                + (f"跌破 {pos['sl_px']:.6g}（-{pos['sl_pct']:.2f}%）离场"
                   if pos["sl_px"] > 0 else "未设止损"))
            self._save()
            return pos

    def close_partial(self, pid, px, pct=1.0, reason="手动平仓"):
        """按比例平仓。pct=0.5 表示平掉一半，剩余仓位继续持有。"""
        pct = float(pct)
        if not (0 < pct <= 1):
            raise ValueError("平仓比例要在 0~100% 之间")
        with self._lock:
            d = self._data
            pos = next((p for p in d["positions"] if p["id"] == pid), None)
            if not pos:
                raise ValueError("找不到这张持仓")

            pnl_all = self._pnl(pos, px)
            close_margin = pos["margin"] * pct
            pnl = pnl_all * pct
            remain = 1 - pct
            # 剩下不足 5% 或不足 0.5U 保证金，直接全平，免得留一堆碎仓
            if remain < 0.05 or pos["margin"] * remain < 0.5:
                close_margin, pnl, pct, remain = pos["margin"], pnl_all, 1.0, 0.0

            d["free"] += close_margin + pnl
            rec = {
                "id": pos["id"] if remain == 0 else f"{pos['id']}·{int(pct*100)}%",
                "symbol": pos["symbol"],
                "side": "多" if pos["side"] > 0 else "空",
                "leverage": pos["leverage"],
                "entry_px": pos["entry_px"], "exit_px": round(px, 6),
                "entry_time": pos["entry_time"],
                "exit_time": time.strftime("%m-%d %H:%M"),
                "pnl": round(pnl, 2),
                "pnl_pct": round(pnl / close_margin * 100, 2) if close_margin else 0,
                "part": int(round(pct * 100)),
                "reason": reason,
                "judge": pos["judge"],
                "pick": pos.get("pick"),
            }
            d["closed"].append(rec)
            if remain <= 0:
                d["positions"] = [p for p in d["positions"] if p["id"] != pid]
            else:
                pos["margin"] = round(pos["margin"] - close_margin, 4)
                pos["notional"] = round(pos["notional"] * remain, 4)
            self._save()
            return rec

    # ---------- 每轮检查 ----------
    def step(self, api):
        """拉标记价，处理止盈/止损/到期。返回本轮动作描述列表。"""
        with self._lock:
            positions = list(self._data["positions"])
        if not positions:
            return []

        prices = {}
        for p in positions:
            try:
                prices[p["symbol"]] = float(api.premium(p["symbol"])["markPrice"])
            except Exception:
                continue

        actions = []
        for p in positions:
            px = prices.get(p["symbol"])
            if not px:
                continue
            reason = None
            if p["side"] > 0:
                if p.get("sl_px") and px <= p["sl_px"]:
                    reason = "止损"
                elif p.get("tp_px") and px >= p["tp_px"]:
                    reason = "止盈"
            else:
                if p.get("sl_px") and px >= p["sl_px"]:
                    reason = "止损"
                elif p.get("tp_px") and px <= p["tp_px"]:
                    reason = "止盈"
            if not reason and _now_ms() >= p["target_ts"]:
                reason = "到期"
            if reason:
                actions.append(self._close(p["id"], px, reason))
        return [a for a in actions if a]

    def _close(self, pid, px, reason):
        with self._lock:
            d = self._data
            pos = next((p for p in d["positions"] if p["id"] == pid), None)
            if not pos:
                return None
            pnl = self._pnl(pos, px)
            d["positions"] = [p for p in d["positions"] if p["id"] != pid]
            d["free"] += pos["margin"] + pnl
            rec = {
                "id": pos["id"], "symbol": pos["symbol"],
                "side": "多" if pos["side"] > 0 else "空",
                "leverage": pos["leverage"],
                "entry_px": pos["entry_px"], "exit_px": round(px, 6),
                "entry_time": pos["entry_time"],
                "exit_time": time.strftime("%m-%d %H:%M"),
                "pnl": round(pnl, 2),
                "pnl_pct": round(pnl / pos["margin"] * 100, 2),
                "reason": reason,
                "judge": pos["judge"],
                "pick": pos.get("pick"),
            }
            d["closed"].append(rec)
            self._save()
            return f"平仓 {pos['symbol']} {rec['side']} {reason} {pnl:+.2f}U"
