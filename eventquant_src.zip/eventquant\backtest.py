"""历史数据下载、回测验证与生产模型训练。

流程：
1. 拉取最近 N 天 1m K 线 + 5m 持仓量 + 资金费率（带本地缓存）
2. 构造特征与三分类标签（10/30/60 分钟）
3. 时序外推：前 70% 训练、后 30% 测试，输出准确率/胜率/盈亏比
4. 用全量数据重训一次，保存生产模型
"""

import re
import time
from pathlib import Path

import numpy as np
import pandas as pd

from . import config
from .api import BinancePublic
from .features import CORE_FEATURES, CLASS_NAMES, klines_to_df, training_frame
from . import model

# ---- 成本模型（全部为比例，不是 bps）----
FEE_TAKER = 0.0004        # 单边吃单手续费 0.04%
SLIPPAGE = 0.0002         # 单边滑点 0.02%
FUNDING_PER_8H = 0.0001   # 资金费率 0.01%/8h，按持仓时长折算


def _horizon_hours(horizon):
    m = re.match(r"(\d+)\s*(min|h|d)?", str(horizon))
    if not m:
        return 1.0
    n = int(m.group(1))
    unit = m.group(2) or "min"
    return {"min": n / 60.0, "h": float(n), "d": n * 24.0}[unit]


def trade_cost(horizon):
    """一次「开仓+平仓」的完整成本：双边手续费 + 双边滑点 + 持仓期资金费。"""
    hours = _horizon_hours(horizon)
    funding = FUNDING_PER_8H * (hours / 8.0)
    return 2 * FEE_TAKER + 2 * SLIPPAGE + funding


def _cache(name):
    config.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return config.CACHE_DIR / name


def _fresh(path, hours=12):
    return path.exists() and (time.time() - path.stat().st_mtime) < hours * 3600


def download_klines(api, symbol, days, force=False):
    path = _cache(f"{symbol}_1m_{days}d.pkl")
    if not force and _fresh(path, 12):
        return pd.read_pickle(path)
    end = int(time.time() * 1000)
    start = end - days * 86400_000
    rows = []
    cur = start
    while cur < end:
        batch = api.klines(symbol, interval="1m", limit=1500, start=cur)
        if not batch:
            break
        rows.extend(batch)
        last_open = batch[-1][0]
        if last_open <= cur:
            break
        cur = last_open + 60_000
        if len(batch) < 1400:
            break
    df = klines_to_df(rows).drop_duplicates("open_time")
    df.to_pickle(path)
    return df


def download_oi(api, symbol, days, force=False):
    """下载持仓量历史。

    注意：Binance 的 /futures/data/openInterestHist 在只给 startTime 时会返回
    「最近 500 条」，必须同时给 endTime 才会按区间返回，因此这里按 500 条一窗、
    显式指定窗口右边界分页。
    """
    path = _cache(f"{symbol}_oi_5m_{days}d.pkl")
    if not force and _fresh(path, 12):
        return pd.read_pickle(path).to_dict("records")
    end = int(time.time() * 1000)
    start = end - days * 86400_000
    step = 500 * 300_000          # 500 条 × 5 分钟
    rows = []
    cur = start
    prev_last = None
    while cur < end:
        batch = api.oi_hist(
            symbol, period="5m", limit=500, start=cur, end=min(end, cur + step)
        )
        if not batch:
            break
        rows.extend(batch)
        last = int(batch[-1]["timestamp"])
        if prev_last is not None and last <= prev_last:
            break
        prev_last = last
        cur = last + 1
    df = pd.DataFrame(rows).drop_duplicates("timestamp")
    df.to_pickle(path)
    return df.to_dict("records")


def download_funding(api, symbol, days, force=False):
    path = _cache(f"{symbol}_funding_{days}d.pkl")
    if not force and _fresh(path, 12):
        return pd.read_pickle(path).to_dict("records")
    end = int(time.time() * 1000)
    start = end - days * 86400_000
    rows = api.funding_rate(symbol, limit=1000, start=start, end=end)
    df = pd.DataFrame(rows).drop_duplicates("fundingTime")
    df.to_pickle(path)
    return df.to_dict("records")


def prepare_frames(api, symbols=None, days=None, force=False):
    symbols = symbols or config.SYMBOLS
    days = days or config.BACKTEST_DAYS
    frames = []
    for sym in symbols:
        print(f"[下载] {sym} {days} 天数据……")
        kdf = download_klines(api, sym, days, force)
        oi = download_oi(api, sym, days, force)
        fr = download_funding(api, sym, days, force)
        df = training_frame(kdf, oi, fr)
        df["symbol"] = sym
        frames.append(df)
    out = pd.concat(frames, ignore_index=True).sort_values("open_time")
    return out.reset_index(drop=True)


def _metrics(pipe, test, horizon):
    cols = CORE_FEATURES
    X = test[cols]
    y = test[f"label_{horizon}"].astype(int)
    ret = test[f"fut_ret_{horizon}"]
    proba = pipe.predict_proba(X)
    pred = proba.argmax(axis=1)
    conf = proba.max(axis=1)
    acc = float((pred == y.values).mean())

    sig = (pred != 1) & (
        conf >= config.MIN_CONF_BY_HORIZON.get(horizon, config.MIN_CONFIDENCE)
    )
    n = int(sig.sum())
    res = {
        "n_test": len(test),
        "accuracy": acc,
        "signals": n,
        "coverage": n / len(test) if len(test) else 0,
        "win_rate": 0.0,
        "profit_factor": 0.0,
        "avg_win": 0.0,
        "avg_loss": 0.0,
        "expectancy": 0.0,
        "total": 0.0,
        "max_dd": 0.0,
        "cost": trade_cost(horizon),
        "up_precision": None,
        "down_precision": None,
    }
    if n:
        direction = np.where(pred[sig] == 2, 1, -1)
        pnl = direction * ret.values[sig] - trade_cost(horizon)
        wins = pnl[pnl > 0]
        losses = pnl[pnl <= 0]
        cum = np.cumsum(pnl)
        peak = np.maximum.accumulate(cum)
        res.update(
            win_rate=float((pnl > 0).mean()),
            profit_factor=float(wins.sum() / (abs(losses.sum()) + 1e-12)),
            avg_win=float(wins.mean()) if len(wins) else 0.0,
            avg_loss=float(losses.mean()) if len(losses) else 0.0,
            expectancy=float(pnl.mean()),
            total=float(pnl.sum()),
            max_dd=float((cum - peak).min()),
        )
    up = pred[sig] == 2
    dn = pred[sig] == 0
    if up.any():
        res["up_precision"] = float((y.values[sig][up] == 2).mean())
    if dn.any():
        res["down_precision"] = float((y.values[sig][dn] == 0).mean())

    # 置信度阈值扫描：帮助选择"少而准"还是"多而杂"
    sweep = {}
    for th in (0.55, 0.60, 0.65, 0.70):
        m = (pred != 1) & (conf >= th)
        n_th = int(m.sum())
        if not n_th:
            sweep[th] = (0, 0.0, 0.0)
            continue
        d = np.where(pred[m] == 2, 1, -1)
        pnl = d * ret.values[m] - trade_cost(horizon)
        wins = pnl[pnl > 0]
        losses = pnl[pnl <= 0]
        sweep[th] = (
            n_th,
            float((pnl > 0).mean()),
            float(wins.sum() / (abs(losses.sum()) + 1e-12)),
        )
    res["sweep"] = sweep
    return res


def _make_label(ret_series, th):
    lab = pd.Series(1, index=ret_series.index)
    lab[ret_series >= th] = 2
    lab[ret_series <= -th] = 0
    return lab


def walk_forward(data, horizon, folds=4, train_frac=0.6):
    """滚动样本外验证：逐折「用过去训练、紧接的一段测试」，指标跨折汇总。

    这比单次 70/30 切分更接近实盘：模型每次只看得到测试段之前的数据。
    """
    n = len(data)
    if folds < 2 or n < config.MIN_SAMPLES * 2:
        return None
    span = (1.0 - train_frac) / folds
    rows = []
    for i in range(folds):
        tr_end = int(n * (train_frac + i * span))
        te_end = int(n * (train_frac + (i + 1) * span))
        train, test = data.iloc[:tr_end], data.iloc[tr_end:te_end]
        if len(train) < config.MIN_SAMPLES or len(test) < 50:
            continue
        ret_tr = train[f"fut_ret_{horizon}"]
        th = float(np.quantile(np.abs(ret_tr), 0.60))
        train = train.assign(**{f"label_{horizon}": _make_label(ret_tr, th)})
        test = test.assign(**{f"label_{horizon}": _make_label(test[f"fut_ret_{horizon}"], th)})
        pipe = model.make_pipeline()
        pipe.fit(train[CORE_FEATURES], train[f"label_{horizon}"].astype(int))
        m = _metrics(pipe, test, horizon)
        m["th"] = th
        rows.append(m)

    valid = [m for m in rows if m["signals"] > 0]
    if not valid:
        return {"folds": rows, "valid_folds": 0}
    sig = sum(m["signals"] for m in valid)
    return {
        "folds": rows,
        "valid_folds": len(valid),
        "signals": sig,
        "win_rate": sum(m["win_rate"] * m["signals"] for m in valid) / sig,
        "expectancy": sum(m["expectancy"] * m["signals"] for m in valid) / sig,
        "total": sum(m["total"] for m in valid),
        "worst_dd": min(m["max_dd"] for m in valid),
        "positive_folds": sum(1 for m in valid if m["total"] > 0),
        "cost": trade_cost(horizon),
    }


def run(api=None, symbols=None, days=None, force=False, save_models=True, folds=4):
    api = api or BinancePublic()
    df = prepare_frames(api, symbols, days, force)
    print(f"总样本 {len(df)}，特征 {len(CORE_FEATURES)} 个\n")

    summary = {}
    for horizon in config.HORIZONS:
        # 只按标签剔除（未来收益缺失的尾部），特征缺失交给管道里的 SimpleImputer。
        # demo 环境的持仓量接口有时只返回 1 条记录，若按特征 dropna 会把样本清空。
        data = df[CORE_FEATURES + [f"fut_ret_{horizon}"]].dropna(
            subset=[f"fut_ret_{horizon}"]
        )
        cut = int(len(data) * config.TRAIN_RATIO)
        # 阈值按训练集 |未来收益| 的 60 分位确定：约 20% 涨、20% 跌、60% 震荡。
        # 这样不同品种/不同周期的波动差异不会把某一类压成 0 或 99%。
        th = float(np.quantile(np.abs(data[f"fut_ret_{horizon}"].iloc[:cut]), 0.60))
        lab = pd.Series(1, index=data.index)
        lab[data[f"fut_ret_{horizon}"] >= th] = 2
        lab[data[f"fut_ret_{horizon}"] <= -th] = 0
        data[f"label_{horizon}"] = lab
        if len(data) < config.MIN_SAMPLES:
            print(f"[{horizon}] 样本不足，跳过")
            continue
        train, test = data.iloc[:cut], data.iloc[cut:]
        pipe = model.make_pipeline()
        pipe.fit(train[CORE_FEATURES], train[f"label_{horizon}"].astype(int))
        m = _metrics(pipe, test, horizon)
        base = float(test[f"label_{horizon}"].value_counts(normalize=True).max())
        summary[horizon] = m

        print(f"=== {horizon} ===")
        print(f"标签阈值 ±{th * 1e4:.1f}bps（训练集 60 分位）")
        print(f"训练 {len(train)} / 测试 {len(test)} | 准确率 {m['accuracy'] * 100:.1f}%"
              f"（多数类基准 {base * 100:.1f}%）")
        print(f"信号 {m['signals']} 条（覆盖 {m['coverage'] * 100:.1f}%） | "
              f"胜率 {m['win_rate'] * 100:.1f}% | 盈亏比 {m['profit_factor']:.2f}")
        print(f"平均盈利 {m['avg_win'] * 100:.3f}% / 平均亏损 {m['avg_loss'] * 100:.3f}% | "
              f"上涨精度 {m['up_precision']} / 下跌精度 {m['down_precision']}")
        print(f"测试集类别分布 {test[f'label_{horizon}'].value_counts().sort_index().to_dict()}")
        print("置信度扫描： " + " | ".join(
            f"{th:.2f}→{n}条/{wr * 100:.0f}%胜/{pf:.2f}"
            for th, (n, wr, pf) in m.get("sweep", {}).items()
        ))
        print(f"单次成本（手续费+滑点+资金费）{trade_cost(horizon) * 1e4:.1f}bps | "
              f"每单期望 {m['expectancy'] * 1e4:+.1f}bps | 累计 {m['total'] * 100:+.2f}% | "
              f"最大回撤 {m['max_dd'] * 100:+.2f}%")

        if folds:
            wf = walk_forward(data, horizon, folds)
            if wf and wf.get("valid_folds"):
                print(f"[滚动验证 {wf['valid_folds']} 折] 信号 {wf['signals']} 条 | "
                      f"胜率 {wf['win_rate'] * 100:.1f}% | 每单期望 {wf['expectancy'] * 1e4:+.1f}bps | "
                      f"累计 {wf['total'] * 100:+.2f}% | 最差回撤 {wf['worst_dd'] * 100:+.2f}% | "
                      f"盈利折数 {wf['positive_folds']}/{wf['valid_folds']}")
            else:
                print("[滚动验证] 样本不足，跳过")
        print()

        if save_models:
            # 回测完成后用全量数据重训，作为线上模型
            lab_full = pd.Series(1, index=data.index)
            lab_full[data[f"fut_ret_{horizon}"] >= th] = 2
            lab_full[data[f"fut_ret_{horizon}"] <= -th] = 0
            full = model.make_pipeline()
            full.fit(data[CORE_FEATURES], lab_full.astype(int))
            model.save(full, horizon, {"trained_rows": len(data), "label_bps": th * 1e4, "backtest": m})
    return summary


def print_table(summary):
    if not summary:
        print("没有可用的回测结果")
        return
    print("\n周期   准确率   信号数  覆盖   胜率    盈亏比   每单期望   最大回撤")
    for h, m in summary.items():
        print(
            f"{h:5s} {m['accuracy'] * 100:7.1f}% {m['signals']:6d} "
            f"{m['coverage'] * 100:6.1f}% {m['win_rate'] * 100:7.1f}% "
            f"{m['profit_factor']:7.2f}  {m.get('expectancy', 0) * 1e4:+8.1f}bps "
            f"{m.get('max_dd', 0) * 100:+7.2f}%"
        )
    print(f"\n{config.DISCLAIMER}")
