"""全网山寨双向雷达。

扫币安 U 本位永续**全部**交易对（300+ 个），不是自选池。

给每个币同时打「做多分」和「做空分」，不强行选边。
打分依据来自 radar_backtest.py（100 个山寨、91,600 条 1h 样本、
看未来 24h 收益）的实测分档：

    布林位置     未来24h均收益   上涨比例   做多胜率   做空胜率
    破下轨          +0.68%       49.9%     49.9%     50.1%
    贴下轨          -0.23%       44.8%     44.8%     55.2%
    中轨区          -0.26%       42.9%     42.9%     57.1%
    贴上轨          -0.48%       39.7%     39.7%     60.3%
    破上轨          -0.03%       38.2%     38.2%     61.8%
    pearson r = -0.0303（原「多头分」越高，后面跌得越多）

也就是：位置越低越偏多、越高越偏空，但**两边的胜率都低于事件合约
55.6% 的盈亏平衡线**，所以分数只能当相对排序，不能当胜率。
真正决定方向的是 BTC 方向——回测里 BTC 24h 涨时所有档位 +1.5% 上下，
跌时全是 -1.5% 上下。因此加一道 BTC 闸门来标记哪边「顺风」。

只用于观察名单，不自动下单。
"""

import json
import time
from concurrent.futures import ThreadPoolExecutor

import pandas as pd

from . import config

CACHE = config.DATA_DIR / "alt_radar.json"
CACHE_VER = 4      # 打分口径变了就 +1，旧缓存自动作废
TTL = 600          # 10 分钟内复用缓存
TOP_N = 120        # 只对成交额前 120 的币拉 K 线，兼顾覆盖面和权重
MIN_QV = 5_000_000  # 24h 成交额低于 500 万 U 的不看（流动性太差，容易被插针）
BAD_SUFFIX = ()    # 杠杆代币只在现货，U 本位永续里没有，不用再过滤
STABLE = ("USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "DAIUSDT",
          "USDPUSDT", "EURUSDT", "AEURUSDT")
# 代币化黄金跟的是金价，不是加密市场情绪，放进山寨雷达会误导
GOLD = ("PAXGUSDT", "XAUTUSDT")


def _eligible(sym):
    return sym.upper() not in STABLE and sym.upper() not in GOLD


def _ema(series, n):
    return series.ewm(span=n, adjust=False).mean()


def _rsi(close, n=14):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, 1e-9)
    return 100 - 100 / (1 + rs)


def _score(kl):
    """kl: [[open_time, o,h,l,c,v,...], ...] 1 小时线，至少 60 根。

    返回做多分、做空分各 0~100，以及偏向哪一边。
    布林位置是分档主因子（回测里唯一单调的），RSI 只做小幅修正。
    """
    if len(kl) < 60:
        return None
    df = pd.DataFrame(kl, columns=[
        "t", "o", "h", "l", "c", "v", "ct", "qv", "n", "tb", "tq", "ig"])
    for c in ("o", "h", "l", "c", "v", "qv"):
        df[c] = df[c].astype(float)

    close = df["c"]
    ema20 = _ema(close, 20).iloc[-1]
    ema50 = _ema(close, 50).iloc[-1]
    rsi = _rsi(close).iloc[-1]

    mid = close.rolling(20).mean().iloc[-1]
    sd = close.rolling(20).std().iloc[-1]
    upper, lower = mid + 2 * sd, mid - 2 * sd
    bb_pos = (close.iloc[-1] - lower) / (upper - lower) if upper > lower else 0.5

    # 量比：最近 6 小时均量 / 前 24 小时均量
    v_recent = df["qv"].tail(6).mean()
    v_base = df["qv"].tail(30).head(24).mean() or 1e-9
    vol_ratio = v_recent / v_base

    tag = []

    # 布林位置：越靠下越偏多，越靠上越偏空
    if bb_pos < 0.0:
        long_s, short_s = 70, 0
        tag.append("破下轨")
    elif bb_pos < 0.35:
        long_s, short_s = 45, 20
        tag.append("贴下轨")
    elif bb_pos < 0.6:
        long_s, short_s = 30, 35
        tag.append("中轨区")
    elif bb_pos < 0.85:
        long_s, short_s = 15, 55
        tag.append("上半区")
    elif bb_pos < 1.0:
        long_s, short_s = 5, 65
        tag.append("贴上轨")
    else:
        long_s, short_s = 0, 70
        tag.append("破上轨")

    # RSI 只做修正：超卖利多、超买利空
    if rsi < 25:
        long_s += 25
        short_s -= 15
        tag.append(f"RSI{rsi:.0f} 超卖")
    elif rsi < 40:
        long_s += 10
    elif rsi <= 60:
        pass
    elif rsi <= 72:
        short_s += 8
    elif rsi <= 80:
        short_s += 20
        tag.append(f"RSI{rsi:.0f} 超买")
    else:
        short_s += 28
        long_s -= 15
        tag.append(f"RSI{rsi:.0f} 极度超买")

    long_s = max(0, min(100, long_s))
    short_s = max(0, min(100, short_s))

    # 只有一侧明显占优（差 20 分且本身够格）才给方向，否则算观望
    if long_s - short_s >= 20 and long_s >= 55:
        side = "多"
    elif short_s - long_s >= 20 and short_s >= 55:
        side = "空"
    else:
        side = ""

    return {
        "ema20": round(ema20, 6), "ema50": round(ema50, 6),
        "rsi": round(rsi, 1), "bb_pos": round(bb_pos, 3),
        "vol_ratio": round(vol_ratio, 2),
        "long_score": long_s, "short_score": short_s,
        "score": max(long_s, short_s), "side": side,
        "tags": tag,
    }


def scan(api, force=False):
    try:
        cache = json.loads(CACHE.read_text(encoding="utf-8"))
        if (not force and cache.get("ver") == CACHE_VER
                and time.time() - cache.get("ts", 0) < TTL):
            cache["cached"] = True
            return cache
    except Exception:
        pass

    t0 = time.time()
    info = api.exchange_info()
    tickers = {t["symbol"]: t for t in api._get("/fapi/v1/ticker/24hr")}

    # BTC 闸门：回测里山寨未来 24h 涨跌几乎完全由 BTC 决定。
    # 大盘在涨时做空逆风，分数再高也只标「只观察」。
    try:
        btc_chg = float(api.ticker24("BTCUSDT")["priceChangePercent"])
    except Exception:
        btc_chg = None

    if btc_chg is None:
        gate, gate_txt = "unknown", "BTC 行情没拿到，今天只当观察清单"
    elif btc_chg >= 1.0:
        gate = "long"
        gate_txt = f"BTC 24h {btc_chg:+.2f}%，大盘在涨，做多顺风、做空逆风"
    elif btc_chg <= -1.0:
        gate = "short"
        gate_txt = f"BTC 24h {btc_chg:+.2f}%，大盘在跌，做空顺风、做多逆风"
    else:
        gate = "wait"
        gate_txt = f"BTC 24h {btc_chg:+.2f}%，横盘没有顺风，两边都只观察"

    pool = []
    for s in info["symbols"]:
        if s.get("contractType") != "PERPETUAL":
            continue
        if s.get("status") != "TRADING":
            continue
        sym = s["symbol"]
        if not sym.endswith("USDT") or not _eligible(sym):
            continue
        t = tickers.get(sym)
        if not t:
            continue
        qv = float(t["quoteVolume"])
        if qv < MIN_QV:              # 成交额太小的不要，盘口薄，一根针就没了
            continue
        pool.append((qv, sym, float(t["lastPrice"]),
                     float(t["priceChangePercent"])))

    pool.sort(reverse=True)
    picked = pool[:TOP_N]

    def work(item):
        qv, sym, last, chg = item
        if chg <= -12:               # 当天已经砸了 12% 的，不追空（反弹风险大）
            return None
        try:
            kl = api.klines(sym, "1h", limit=80)
        except Exception:
            return None
        sc = _score(kl)
        if not sc:
            return None
        return {
            "symbol": sym, "price": last, "chg24": round(chg, 2),
            "vol24": round(qv / 1e6, 1),
            **sc,
        }

    rows = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for r in ex.map(work, picked):
            if r:
                rows.append(r)

    # 闸门指向哪边，就把哪边的标的排前面（另一边仍然展示，只是靠后）
    if gate == "long":
        rows.sort(key=lambda r: (r["long_score"], r["score"]), reverse=True)
    elif gate == "short":
        rows.sort(key=lambda r: (r["short_score"], r["score"]), reverse=True)
    else:
        rows.sort(key=lambda r: r["score"], reverse=True)
    out = {
        "ver": CACHE_VER,
        "ts": time.time(),
        "time": time.strftime("%m-%d %H:%M"),
        "total_pairs": len(pool),
        "scanned": len(rows),
        "elapsed": round(time.time() - t0, 1),
        "btc_chg": round(btc_chg, 2) if btc_chg is not None else None,
        "gate": gate,
        "gate_txt": gate_txt,
        "rows": rows[:25],
        "cached": False,
    }
    try:
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return out
