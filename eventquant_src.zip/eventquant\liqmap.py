"""清算热力图（估算模型）。

公开接口拿不到"全市场强平挂单分布"，这里用可验证的公开数据做近似：
  1) 1h 持仓量增量（OI 增加 = 有新仓开在这个价位）
  2) 1h 主动买卖比（判断这批新仓偏多还是偏空）
  3) 常见杠杆档位假设（5/10/20/25/50 倍）
推算每个价位的多头/空头强平金额，聚合成热力条。

注意：这是模型估算，不是交易所真实挂单，只用于判断"哪里容易被插针"。
"""

from collections import defaultdict

import requests

FAPI = "https://fapi.binance.com"
# 杠杆档位 -> 假设占比（散户集中在 10~20 倍，50 倍占比不小）
LEVERAGES = {5: 0.15, 10: 0.25, 20: 0.25, 25: 0.15, 50: 0.20}
BUCKET = 500.0


def _get(path, **params):
    r = requests.get(FAPI + path, params=params, timeout=15)
    r.raise_for_status()
    return r.json()


def build(symbol="BTCUSDT", hours=168):
    symbol = symbol.upper()
    kl = _get("/fapi/v1/klines", symbol=symbol, interval="1h", limit=hours)
    oi = _get("/futures/data/openInterestHist", symbol=symbol, period="1h", limit=hours)
    tk = _get("/futures/data/takerlongshortRatio", symbol=symbol, period="1h", limit=hours)

    close = {int(k[0]): float(k[4]) for k in kl}
    oi_map = {int(o["timestamp"]): float(o["sumOpenInterest"]) for o in oi}
    tk_map = {int(t["timestamp"]): float(t["buySellRatio"]) for t in tk}

    ts = sorted(set(close) & set(oi_map))
    long_b = defaultdict(float)
    short_b = defaultdict(float)
    total_new = 0.0

    for i in range(1, len(ts)):
        t, p = ts[i], ts[i - 1]
        d_oi = oi_map[t] - oi_map[p]
        if d_oi <= 0:
            continue
        entry = close[t]
        notional = d_oi * entry
        ratio = tk_map.get(t, 1.0)
        long_share = ratio / (1.0 + ratio)
        total_new += notional
        for lev, w in LEVERAGES.items():
            lq = entry * (1 - 1 / lev)
            sq = entry * (1 + 1 / lev)
            long_b[int(lq // BUCKET) * int(BUCKET)] += notional * long_share * w
            short_b[int(sq // BUCKET) * int(BUCKET)] += notional * (1 - long_share) * w

    price = float(_get("/fapi/v1/ticker/price", symbol=symbol)["price"])
    lo, hi = price * 0.82, price * 1.18
    rows = []
    for b in set(long_b) | set(short_b):
        if lo <= b <= hi:
            rows.append({
                "price": b,
                "long": round(long_b[b] / 1e6, 1),
                "short": round(short_b[b] / 1e6, 1),
            })
    rows.sort(key=lambda r: r["price"])

    peak = max((max(r["long"], r["short"]) for r in rows), default=1) or 1
    return {
        "symbol": symbol,
        "price": price,
        "hours": hours,
        "new_notional_m": round(total_new / 1e6, 1),
        "peak_m": peak,
        "rows": rows,
        "note": "估算：OI增量×杠杆分布，非交易所真实挂单",
    }
