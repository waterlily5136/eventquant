"""多时间窗口特征工程。

两个层次：
- 核心特征（core）：只用 K 线 + 持仓量 + 资金费率，能从历史数据完全重建，
  因此训练与回测都用它，实时预测也用它 —— 保证线上线下同一套输入。
- 盘口特征（book）：买卖盘失衡、大单流向、点差等，交易所不提供历史盘口，
  只能实时计算，用于展示、告警与人工判断，不进入模型。

窗口：10 / 30 / 60 分钟（对应 HORIZONS）。
"""

import numpy as np
import pandas as pd

from . import config

CORE_FEATURES = [
    "ret_5", "ret_15", "ret_60",
    "vol_z_10",
    "taker_imb_5", "taker_imb_15", "taker_imb_30",
    "vwap_gap_30",
    "ma_gap_10", "ma_gap_30",
    "rsi_14",
    "range_pos_30",
    "atr_pct",
    "oi_chg_15", "oi_chg_60",
    "funding_bps", "funding_chg_bps",
]

CLASS_NAMES = ["下跌", "震荡", "上涨"]


def klines_to_df(raw):
    df = pd.DataFrame(
        raw,
        columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_vol", "trades", "taker_buy_base",
            "taker_buy_quote", "ignore",
        ],
    )
    for c in ["open", "high", "low", "close", "volume", "quote_vol",
              "taker_buy_base", "taker_buy_quote"]:
        df[c] = df[c].astype(float)
    df["open_time"] = df["open_time"].astype("int64")
    df["close_time"] = df["close_time"].astype("int64")
    return df


def oi_to_df(raw):
    if not raw:
        return pd.DataFrame(columns=["ts", "oi"])
    return pd.DataFrame(
        {"ts": [int(x["timestamp"]) for x in raw],
         "oi": [float(x["sumOpenInterest"]) for x in raw]}
    )


def funding_to_df(raw):
    if not raw:
        return pd.DataFrame(columns=["ts", "rate"])
    return pd.DataFrame(
        {"ts": [int(x["fundingTime"]) for x in raw],
         "rate": [float(x["fundingRate"]) for x in raw]}
    ).sort_values("ts")


def _rsi(close, n=14):
    delta = close.diff()
    up = delta.clip(lower=0)
    dn = -delta.clip(upper=0)
    ru = up.ewm(alpha=1 / n, adjust=False).mean()
    rd = dn.ewm(alpha=1 / n, adjust=False).mean()
    rs = ru / (rd + 1e-12)
    return 100 - 100 / (1 + rs)


def build_features(kdf, oi_raw=None, funding_raw=None):
    """输入 1m K 线与 OI/资金费历史，输出逐根 K 线的特征表。"""
    df = kdf.copy().reset_index(drop=True)
    close = df["close"]
    vol = df["volume"]
    buy = df["taker_buy_base"]
    sell = vol - buy

    df["ret_5"] = np.log(close / close.shift(5))
    df["ret_15"] = np.log(close / close.shift(15))
    df["ret_60"] = np.log(close / close.shift(60))

    vmean = vol.rolling(60).mean()
    vstd = vol.rolling(60).std()
    df["vol_z_10"] = (vol.rolling(10).mean() - vmean) / (vstd + 1e-9)

    for w in (5, 15, 30):
        b = buy.rolling(w).sum()
        s = sell.rolling(w).sum()
        df[f"taker_imb_{w}"] = (b - s) / (b + s + 1e-9)

    vw = df["quote_vol"].rolling(30).sum() / (vol.rolling(30).sum() + 1e-9)
    df["vwap_gap_30"] = close / (vw + 1e-9) - 1

    df["ma_gap_10"] = close / close.ewm(span=10, adjust=False).mean() - 1
    df["ma_gap_30"] = close / close.ewm(span=30, adjust=False).mean() - 1
    df["rsi_14"] = _rsi(close)

    lo = df["low"].rolling(30).min()
    hi = df["high"].rolling(30).max()
    df["range_pos_30"] = (close - lo) / (hi - lo + 1e-9)

    tr = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - close.shift(1)).abs(),
            (df["low"] - close.shift(1)).abs(),
        ],
        axis=1,
    ).max(axis=1)
    df["atr_pct"] = tr.rolling(14).mean() / close

    # 持仓量：5m 采样，按时间向后对齐到 1m K 线
    if oi_raw:
        oi = oi_to_df(oi_raw).drop_duplicates("ts")
        df = pd.merge_asof(
            df.sort_values("open_time"),
            oi.sort_values("ts"),
            left_on="open_time",
            right_on="ts",
            direction="backward",
        )
        df["oi"] = df["oi"].ffill()
        df["oi_chg_15"] = df["oi"] / df["oi"].shift(15) - 1
        df["oi_chg_60"] = df["oi"] / df["oi"].shift(60) - 1
    else:
        df["oi_chg_15"] = np.nan
        df["oi_chg_60"] = np.nan

    # 资金费率：8 小时一期，向后对齐
    if funding_raw:
        fr = funding_to_df(funding_raw).drop_duplicates("ts")
        df = pd.merge_asof(
            df.sort_values("open_time"),
            fr.sort_values("ts"),
            left_on="open_time",
            right_on="ts",
            direction="backward",
        )
        df["funding_bps"] = df["rate"].ffill() * 1e4
        df["funding_chg_bps"] = df["funding_bps"].diff()
    else:
        df["funding_bps"] = np.nan
        df["funding_chg_bps"] = np.nan

    return df


def add_labels(df):
    for name, h in config.HORIZONS.items():
        th = config.LABEL_BPS[name] / 1e4
        fut = np.log(df["close"].shift(-h) / df["close"])
        lab = pd.Series(1, index=df.index)          # 默认震荡
        lab[fut >= th] = 2                          # 上涨
        lab[fut <= -th] = 0                         # 下跌
        lab[fut.isna()] = np.nan
        df[f"label_{name}"] = lab
        df[f"fut_ret_{name}"] = fut
    return df


def training_frame(kdf, oi_raw, funding_raw):
    df = build_features(kdf, oi_raw, funding_raw)
    df = add_labels(df)
    return df


def live_core(api, symbol, kline_limit=None):
    """实时核心特征：取最后一根已收盘 K 线。

    返回值除 CORE_FEATURES 外，额外带 _as_of_ms（该 K 线的收盘时间），
    用于对外标注「预测所用数据的截止时间」。
    """
    raw = api.klines(symbol, interval="1m", limit=kline_limit or config.KLINE_LIMIT)
    oi = api.oi_hist(symbol, period="5m", limit=100)
    fr = api.funding_rate(symbol, limit=3)
    df = build_features(klines_to_df(raw), oi, fr)
    now = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    if int(df["close_time"].iloc[-1]) > now and len(df) > 2:
        row = df.iloc[-2]
    else:
        row = df.iloc[-1]
    out = {k: float(row[k]) for k in CORE_FEATURES}
    out["_as_of_ms"] = int(row["close_time"]) + 1
    return out


def book_features(store, symbol, now_ms=None):
    """盘口/成交流的实时窗口统计（仅展示与告警，不进模型）。"""
    now_ms = now_ms or int(pd.Timestamp.now(tz="UTC").timestamp() * 1000)
    out = {}
    for name, minutes in config.HORIZONS.items():
        since = now_ms - minutes * 60_000
        d = store.depth(symbol, since)
        f = store.flow(symbol, since)
        w = {"minutes": minutes}
        if len(d):
            w["ob_imb_now"] = float(d["imbalance"].iloc[-1])
            w["ob_imb_mean"] = float(d["imbalance"].mean())
            w["spread_bps_mean"] = float(d["spread_bps"].mean())
            w["big_wall_net"] = float((d["big_bid"] - d["big_ask"]).iloc[-1])
            w["snapshots"] = int(len(d))
        if len(f):
            buy = float(f["buy_notional"].sum())
            sell = float(f["sell_notional"].sum())
            w["taker_buy_ratio"] = buy / (buy + sell + 1e-9)
            w["big_trade_net"] = float((f["big_buy"] - f["big_sell"]).sum())
            w["trade_notional"] = buy + sell
        out[name] = w
    return out


def coverage_ok(store, symbol, minutes):
    need = minutes * 60 / config.POLL_SECONDS * 0.6
    since = int(pd.Timestamp.now(tz="UTC").timestamp() * 1000) - minutes * 60_000
    return store.coverage("depth", symbol, since) >= need
