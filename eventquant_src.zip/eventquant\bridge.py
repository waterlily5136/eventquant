"""山寨币异动雷达（altradar）对接适配层。

两个系统各自独立运行，通过 HTTP 松耦合对接：
- 雷达在 8778 上跑，本模块只读它的 /api/scan 结果，不启动、不修改它
- 雷达没启动或首次扫描较慢时返回 connecting 状态，不阻塞事件合约页
- 后续要把两个页面合并时，直接消费这里归一化后的字段即可
"""

import threading
import time

import requests

from . import config
from .providers import Provider


class AltRadarProvider(Provider):
    key = "altradar"
    title = "山寨币异动雷达"
    order = 10

    def __init__(self):
        self._data = None
        self._ts = 0.0
        self._error = ""
        self._busy = False

    def available(self):
        return True  # 模块已装载，连接状态在 payload 的 status 字段里体现

    def payload(self):
        """立即返回最近一次结果，过期则在后台刷新，绝不阻塞页面。"""
        self._maybe_refresh()
        if self._data is None:
            if self._error:
                return {"status": "offline", "message": self._error}
            return {"status": "connecting", "message": "首次扫描中，约需 1 分钟"}
        data = dict(self._data)
        data["status"] = "ok"
        if self._error:
            data["message"] = self._error
        return data

    # ---------- 后台拉取 ----------
    def _maybe_refresh(self):
        if self._busy:
            return
        if self._data is not None and time.time() - self._ts < config.ALTRADAR_TTL:
            return
        self._busy = True
        threading.Thread(target=self._refresh, daemon=True).start()

    def _refresh(self):
        try:
            url = config.ALTRADAR_URL.rstrip("/") + "/api/scan"
            r = requests.get(url, timeout=config.ALTRADAR_TIMEOUT)
            r.raise_for_status()
            self._data = self._normalize(r.json())
            self._ts = time.time()
            self._error = ""
        except Exception as e:
            self._error = f"未连接：{type(e).__name__}: {e}"
        finally:
            self._busy = False

    @staticmethod
    def _normalize(raw):
        """把雷达输出压成统一字段，便于和事件合约合并展示。"""
        watch = [
            {
                "symbol": x.get("symbol"),
                "score": round(float(x.get("score", 0)), 1),
                "ret_24h": x.get("ret_24h"),
                "reasons": (x.get("reasons") or [])[:2],
            }
            for x in (raw.get("watchlist") or [])[:6]
        ]
        movers = [
            {
                "symbol": x.get("symbol"),
                "direction": x.get("direction"),
                "ret_24h": x.get("ret_24h"),
                "trend": x.get("trend"),
            }
            for x in (raw.get("movers") or [])[:6]
        ]
        return {
            "generated_at": raw.get("generated_at", ""),
            "symbol_count": raw.get("symbol_count"),
            "watchlist": watch,
            "movers": movers,
        }


# 导入即注册（providers.py 不反向依赖本模块，避免循环导入）
from .providers import register  # noqa: E402

register(AltRadarProvider())
