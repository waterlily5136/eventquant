"""网络守护 v2：启动即预热 + 快速节点池 + 并行测速，10 秒内完成切节点。

v1 问题：
    1. 启动后节点可能已经不行，要等 60s×2=120s 才触发修复
    2. 每次全量测速订阅里 30+ 节点，并行也要等最慢那个
    3. 修复流程串行：每个候选切过去等 2s、probe 两次（各 8s），单节点最坏 20s

v2 优化：
    - 启动 preflight：初始化后立即 probe，失败立刻 repair，不等巡检
    - 快速节点池：只在历史验证过的节点里选（最多 8 个），不碰全量
    - 并行测速 top5：6 workers 只测候选池，每个 6s 超时
    - 快速 probe：direct 2s + proxy 5s，成功即返回不二次尝试
    - 修复冷却 60s 起步（v1 是 180s），失败后指数退避
"""

import concurrent.futures
import json
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import quote

import requests

from . import config
from .signals import push

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

CLASH_EXE_CANDIDATES = [
    r"C:\Program Files\Clash Verge\clash-verge.exe",
    r"C:\Program Files (x86)\Clash Verge\clash-verge.exe",
]
SKIP_NODES = {"♻️ 自动选择", "DIRECT", "REJECT", "REJECT-DROP", "PASS"}

# 快速节点池的最大容量（历史上成功过的节点数上限）
FAST_POOL_MAX = 12
# 每次修复最多尝试的节点数
MAX_CANDIDATES = 5
# 测速并行 workers
BENCH_WORKERS = 6


class NetGuard:
    def __init__(self, notify=None):
        self.notify = notify or push
        self.headers = {"Authorization": f"Bearer {config.CLASH_TOKEN}"}
        self.s = requests.Session()
        self.s.trust_env = False
        self.fails = 0
        self.status = "unknown"
        self.last_fix = 0.0
        self.backoff = 0.0              # 指数退避秒数（失败修复后累加）
        self.last_ok = time.time()
        self.history = []
        self.current_node = None
        self.state_path = Path(config.NODE_STATE_PATH)
        pool = self._load_state()
        self.last_good = pool.get("last_good")
        self.fast_pool = pool.get("fast_pool", [])  # list of node names, most recent first

    # ---------- 持久化 ----------
    def _load_state(self):
        try:
            return json.loads(self.state_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_state(self, **kw):
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            data = dict(self._load_state())
            data.update(kw)
            data["ts"] = int(time.time() * 1000)
            self.state_path.write_text(
                json.dumps(data, ensure_ascii=False), encoding="utf-8"
            )
        except Exception:
            pass

    def _add_to_pool(self, node):
        if not node or node in SKIP_NODES:
            return
        pool = [n for n in self.fast_pool if n != node]
        pool.insert(0, node)
        self.fast_pool = pool[:FAST_POOL_MAX]
        self._save_state(last_good=node, fast_pool=self.fast_pool)

    # ---------- 连通性 ----------
    def probe(self, timeout=5, direct_timeout=2):
        """轻量探测：直连 2s + 代理 5s，任一成功即通。"""
        def once(proxies, to):
            with requests.Session() as sess:
                sess.trust_env = False
                r = sess.get(config.BASE_URL + "/fapi/v1/time",
                             proxies=proxies, timeout=to)
                return r.status_code

        try:
            if once({}, direct_timeout) == 200:
                return True, "直连"
        except Exception:
            pass
        try:
            code = once(config.PROXIES, timeout)
            if code == 200:
                return True, "代理"
            return False, f"HTTP {code}"
        except Exception as e:
            return False, f"{type(e).__name__}"

    def clash_alive(self):
        try:
            r = self.s.get(config.CLASH_API + "/version",
                           headers=self.headers, timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    def get_current_node(self):
        """从 Clash API 读取当前选中的节点名。"""
        try:
            r = self.s.get(f"{config.CLASH_API}/proxies/{quote(config.CLASH_GROUP, safe='')}",
                           headers=self.headers, timeout=4)
            return r.json().get("now")
        except Exception:
            return None

    # ---------- 测速 ----------
    def _delay(self, node):
        try:
            enc = quote(node, safe="")
            r = self.s.get(
                f"{config.CLASH_API}/proxies/{enc}/delay",
                headers=self.headers,
                params={"timeout": 4000, "url": config.BASE_URL + "/fapi/v1/time"},
                timeout=7,
            )
            if r.status_code == 200:
                d = r.json().get("delay")
                if isinstance(d, (int, float)) and 0 < d < 15000:
                    return node, int(d)
        except Exception:
            pass
        return node, None

    def _collect_candidates(self):
        """候选节点 = 快速池 + 当前节点 + last_good + 全部节点（去重）。
        全部节点只在快速池不足时兜底用。"""
        try:
            r = self.s.get(f"{config.CLASH_API}/proxies",
                           headers=self.headers, timeout=5)
            all_nodes = [n for n in r.json()["proxies"][config.CLASH_GROUP].get("all", [])
                         if n not in SKIP_NODES]
        except Exception:
            all_nodes = []

        current = self.get_current_node()
        seen = set()
        ordered = []

        # 1. last_good 最优先（上次真实验证过）
        if self.last_good and self.last_good in all_nodes:
            ordered.append(self.last_good); seen.add(self.last_good)
        # 2. 当前节点（如果不是 last_good）
        if current and current not in seen and current in all_nodes:
            ordered.append(current); seen.add(current)
        # 3. 快速池里的其他节点
        for n in self.fast_pool:
            if n not in seen and n in all_nodes:
                ordered.append(n); seen.add(n)
        # 4. 兜底：全量节点里还没包含的（快速池空时才用到）
        if len(ordered) < 6:
            for n in all_nodes:
                if n not in seen:
                    ordered.append(n); seen.add(n)
                    if len(ordered) >= 8:
                        break
        return ordered[:MAX_CANDIDATES]

    def rank_candidates(self, nodes):
        """并行测速候选节点，返回 [(延迟, node)] 升序。"""
        if not nodes:
            return []
        ranked = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=BENCH_WORKERS) as ex:
            for node, d in ex.map(self._delay, nodes):
                if d:
                    ranked.append((d, node))
        ranked.sort()
        return ranked

    # ---------- 修复 ----------
    def start_clash(self):
        for exe in CLASH_EXE_CANDIDATES:
            if Path(exe).exists():
                try:
                    subprocess.Popen([exe], close_fds=True)
                    return exe
                except Exception:
                    continue
        return None

    def switch(self, node):
        enc = quote(config.CLASH_GROUP, safe="")
        try:
            r = self.s.put(
                f"{config.CLASH_API}/proxies/{enc}",
                headers=self.headers,
                json={"name": node},
                timeout=6,
            )
            return r.status_code in (200, 204)
        except Exception:
            return False

    def repair(self):
        log = []

        # 指数退避冷却
        cooldown = max(config.NET_FIX_COOLDOWN, self.backoff)
        if time.time() - self.last_fix < cooldown:
            return False

        self.last_fix = time.time()

        # 1) Clash 挂了就重启
        if not self.clash_alive():
            log.append("Clash 控制口无响应，尝试重启")
            exe = self.start_clash()
            if not exe:
                log.append("找不到 clash-verge.exe")
                self._alert(log)
                return False
            ready = False
            for _ in range(20):
                time.sleep(1.5)
                if self.clash_alive():
                    ready = True
                    break
            if not ready:
                log.append("重启后 30s 仍未就绪")
                self._alert(log)
                return False
            log.append("Clash 已重启")
            time.sleep(3)
            ok, how = self.probe()
            if ok:
                self.current_node = self.get_current_node()
                self._add_to_pool(self.current_node)
                self.backoff = 0
                log.append(f"恢复成功（{how}）")
                self._record(True, "；".join(log))
                self._notify("网络已恢复：" + "；".join(log), title="网络已恢复")
                return True

        # 2) 收集候选 → 并行测速
        candidates = self._collect_candidates()
        self.current_node = self.get_current_node()
        if self.current_node and self.current_node in candidates:
            candidates.remove(self.current_node)
            candidates.insert(0, self.current_node)

        log.append(f"候选 {len(candidates)} 个节点，并行测速中...")
        ranked = self.rank_candidates(candidates)
        if not ranked:
            log.append("全部测速失败")
            self.backoff = min(self.backoff + 60, 300)
            self._alert(log)
            return False
        log.append(f"最快 {ranked[0][1]}（{ranked[0][0]}ms）")

        original = self.current_node
        tried = set()
        for delay_ms, node in ranked:
            if node in tried:
                continue
            tried.add(node)
            if not self.switch(node):
                continue
            self.current_node = node
            time.sleep(1)   # 切换后等 1s（v1 是 2s）
            ok, how = self.probe()
            if ok:
                self._add_to_pool(node)
                self.backoff = 0
                log.append(f"切到 {node}（{delay_ms}ms）→ {how}")
                self._record(True, "；".join(log))
                self._notify("网络已恢复：" + "；".join(log), title="网络已恢复")
                return True
            log.append(f"{node}（{delay_ms}ms）不通（{how}）")

        # 全部失败，切回原节点
        if original and original != self.current_node:
            self.switch(original)
            self.current_node = original
            log.append(f"已回退到 {original}")
        self.backoff = min(self.backoff + 60, 300)
        self._alert(log)
        return False

    # ---------- 主循环 ----------
    def preflight(self):
        """启动时立即检查，失败立刻修复，不等巡检。"""
        ok, how = self.probe()
        if ok:
            self.status = "ok"
            self.last_ok = time.time()
            self.current_node = self.get_current_node()
            if self.current_node:
                self._add_to_pool(self.current_node)
            self._record(True, f"启动预热通过（{how}）")
            return
        self.status = "down"
        self.fails = max(self.fails, config.NET_FAILS_BEFORE_FIX)
        self._record(False, f"启动预热失败（{how}），立即修复")
        if self.repair():
            self.status = "ok"
            self.fails = 0
            self.last_ok = time.time()

    def step(self):
        ok, how = self.probe()
        if ok:
            if self.status == "down":
                self._notify(f"网络已恢复（{how}），采集与推送继续。", title="网络已恢复")
            self.status = "ok"
            self.fails = 0
            self.backoff = 0
            self.last_ok = time.time()
            return
        self.fails += 1
        self.status = "down"
        if self.fails < config.NET_FAILS_BEFORE_FIX:
            return
        if time.time() - self.last_fix < max(config.NET_FIX_COOLDOWN, self.backoff):
            return
        self.repair()

    def run(self, stop_event):
        while not stop_event.is_set():
            try:
                self.step()
            except Exception as e:
                self._record(False, f"守护线程异常：{e}")
            stop_event.wait(config.NET_GUARD_SECONDS)

    # ---------- 日志/推送 ----------
    def _record(self, ok, msg):
        entry = {"ts": int(time.time() * 1000), "ok": ok, "msg": msg}
        self.history.append(entry)
        self.history = self.history[-30:]
        try:
            print(f"[网络守护] {msg}")
        except Exception:
            pass

    def _notify(self, text, title):
        try:
            self.notify(text, title=title)
        except Exception:
            pass

    def _alert(self, log):
        self._record(False, "；".join(log))
        self._notify(
            "加速器异常，自动修复未成功：\n" + "\n".join(f"· {x}" for x in log)
            + "\n\n采集与推送可能中断，请检查电脑上的 Clash Verge。",
            title="⚠ 网络中断",
        )

    def state(self):
        return {
            "status": self.status,
            "fails": self.fails,
            "last_ok": int(self.last_ok * 1000),
            "current_node": self.current_node,
            "fast_pool_size": len(self.fast_pool),
            "backoff": self.backoff,
            "history": list(reversed(self.history[-12:])),
            "interval_s": config.NET_GUARD_SECONDS,
        }


_guard = None
_lock = threading.Lock()


def get_guard():
    global _guard
    with _lock:
        if _guard is None:
            _guard = NetGuard()
        return _guard
