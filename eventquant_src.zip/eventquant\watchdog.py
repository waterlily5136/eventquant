"""真实持仓监控：盯用户手动添加的币种，异常时推送到手机。

监控对象不是模型标的（BTC/ETH 那些），而是用户自己的真实持仓，
比如 ESPORTSUSDT 空单。规则针对"突然启动/逼空"这类风险设计：

1. OI 骤变：1 小时持仓量变化超过阈值 → 新资金进场
2. 资金费异常：费率翻正/翻负 或 绝对值过大 → 多空拥挤方向变了
3. 价格急动：1 小时涨跌幅超过阈值
4. 多空比极端：散户拥挤到极端值，容易反向被收割

列表存在 data/watchlist.json，网页上可自由增删。
"""

import json
import threading
import time
from pathlib import Path

from . import config
from .signals import push


class Watchdog:
    def __init__(self, api, path=None):
        self.api = api
        self.path = Path(path or config.WATCHLIST_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._last = {}       # symbol -> 最近一次指标快照
        self._fired = {}      # (symbol, rule) -> 上次推送时间（冷却去重）
        self._alerts = []     # 最近触发过的告警（页面展示）

    # ---------- 列表管理 ----------
    def _load(self):
        if not self.path.exists():
            return []
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _save(self, items):
        self.path.write_text(
            json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def list(self):
        with self._lock:
            return list(self._load())

    def add(self, symbol, note="", side="none"):
        symbol = str(symbol).upper().strip()
        if not symbol:
            raise ValueError("symbol 不能为空")
        if side not in ("long", "short", "none"):
            raise ValueError("side 只能是 long / short / none")
        # 先验证这个合约真实存在，防止输错名字后监控线程一直报错
        self.api.ticker24(symbol)
        with self._lock:
            items = self._load()
            if any(i["symbol"] == symbol for i in items):
                raise ValueError(f"{symbol} 已在监控列表里")
            items.append({
                "symbol": symbol, "note": note, "side": side,
                "added_ts": int(time.time() * 1000),
            })
            self._save(items)
        return symbol

    def set_side(self, symbol, side):
        if side not in ("long", "short", "none"):
            raise ValueError("side 只能是 long / short / none")
        with self._lock:
            items = self._load()
            hit = None
            for i in items:
                if i["symbol"] == symbol.upper():
                    i["side"] = side
                    hit = i
            if not hit:
                raise ValueError(f"{symbol} 不在监控列表里")
            self._save(items)
        return hit

    def remove(self, symbol):
        symbol = str(symbol).upper().strip()
        with self._lock:
            items = self._load()
            kept = [i for i in items if i["symbol"] != symbol]
            if len(kept) == len(items):
                raise ValueError(f"{symbol} 不在监控列表里")
            self._save(kept)
            self._last.pop(symbol, None)
        return symbol

    # ---------- 指标采集 ----------
    def metrics(self, symbol):
        """拉一次监控指标。所有字段失败时给 None，不让单个接口拖死整轮。"""
        m = {"symbol": symbol, "ts": int(time.time() * 1000)}
        try:
            t = self.api.ticker24(symbol)
            m["price"] = float(t["lastPrice"])
            m["chg24"] = float(t["priceChangePercent"])
            m["high24"] = float(t["highPrice"])
            m["low24"] = float(t["lowPrice"])
        except Exception as e:
            m["error"] = f"行情: {e}"
            return m
        # 1 小时价格变化（用 1m K 线，避免 24h 变化掩盖短期急动）
        try:
            k = self.api.klines(symbol, interval="1m", limit=61)
            if len(k) >= 2:
                o, c = float(k[0][1]), float(k[-1][4])
                m["chg1h"] = (c / o - 1) * 100 if o else None
        except Exception:
            m["chg1h"] = None
        # OI 1 小时变化
        try:
            now = int(time.time() * 1000)
            oi = self.api.oi_hist(symbol, period="5m",
                                  start=now - 3_900_000, end=now)
            if len(oi) >= 2:
                first, last = float(oi[0]["sumOpenInterest"]), float(oi[-1]["sumOpenInterest"])
                m["oi"] = last
                m["oi_chg1h"] = (last / first - 1) * 100 if first else None
        except Exception:
            m["oi"] = m["oi_chg1h"] = None
        # 资金费：最近两条，看绝对值和符号翻转
        try:
            fr = self.api.funding_rate(symbol, limit=2)
            if fr:
                m["funding"] = float(fr[-1]["fundingRate"])
                m["funding_prev"] = float(fr[-2]["fundingRate"]) if len(fr) > 1 else None
        except Exception:
            m["funding"] = m["funding_prev"] = None
        # 多空比
        try:
            ls = self.api.global_ls_ratio(symbol, period="5m", limit=1)
            if ls:
                m["ls_ratio"] = float(ls[-1]["longShortRatio"])
        except Exception:
            m["ls_ratio"] = None
        return m

    # ---------- 规则判定 ----------
    @staticmethod
    def _advice(rule, m, side):
        """按持仓方向给出可执行建议。side: long 多 / short 空 / none 空仓。"""
        up = (m.get("chg1h") or 0) > 0
        if rule == "oi":
            if m.get("oi_chg1h", 0) > 0:
                if side == "short":
                    return "新资金在进场。空单警惕逼空：把止损上移到成本价上方，破近期高点就走"
                if side == "long":
                    return "新资金进场。多单可持有，但把止损上移到最近一个低点下方"
                return "有新资金进场，等价格选择方向后再跟，别在放量前抢跑"
            if side in ("long", "short"):
                return "资金在离场，趋势可能衰竭。建议先平一半落袋，剩下的挂保本损"
            return "持仓量快速下降，说明这波在收尾，不适合新开仓"
        if rule == "price":
            if up:
                if side == "short":
                    return "⚠ 空单正在逆势。优先减仓或止损，别扛单等回调"
                if side == "long":
                    return "多单顺势，把止损上移到成本价，让利润奔跑"
                return "急涨但不要追高，等回踩不破前高再考虑"
            if side == "short":
                return "空单顺势，把止损下移到最近高点上方锁定利润"
            if side == "long":
                return "⚠ 多单逆势，跌破关键支撑就减仓，不要补仓摊平"
            return "急跌不追空，等反抽无量再考虑"
        if rule == "funding_big":
            if (m.get("funding") or 0) > 0:
                if side == "short":
                    return "多头在付费扛单，对空单有利。但极端值往往出现在阶段低点，注意止盈"
                if side == "long":
                    return "多单持仓成本偏高，若价格不涨反跌，优先减仓"
                return "多头拥挤，此时追多性价比低"
            if side == "long":
                return "空头在付费扛单，对多单有利，但极端值常出现在阶段高点，注意止盈"
            if side == "short":
                return "空单成本偏高，警惕空头拥挤后的拉升"
            return "空头拥挤，此时追空性价比低"
        if rule == "funding_flip":
            return "多空力量换位，原有趋势可能结束。建议减仓观察一根 K 线再做决定"
        if rule == "ls":
            r = m.get("ls_ratio") or 1
            if r >= 1:
                if side == "short":
                    return "散户多数在做多，你的空单有对手盘。但人多的地方容易反转，止损别松"
                if side == "long":
                    return "散户和你同向，拥挤交易。注意一旦转向会踩踏，控制仓位"
                return "散户偏多，可等回踩确认后再决定方向"
            if side == "long":
                return "散户多数在做空，你的多单有对手盘。注意空头回补可能引发急涨"
            if side == "short":
                return "散户和你同向做空，拥挤。一旦拉升容易连环平仓，止损必须挂"
            return "散户偏空，注意逼空风险"
        return ""

    def evaluate(self, m, side="none"):
        """返回触发的告警 [(rule, 数据描述, 操作建议)]。"""
        out = []
        if m.get("error"):
            return out

        def add(rule, text):
            out.append((rule, text, self._advice(rule, m, side)))

        if m.get("oi_chg1h") is not None and abs(m["oi_chg1h"]) >= config.WATCH_OI_PCT:
            add("oi", f"持仓量 1 小时 {m['oi_chg1h']:+.1f}%"
                      f"（{m.get('oi', 0):,.0f}），"
                      f"{'新资金涌入' if m['oi_chg1h'] > 0 else '大量平仓离场'}")
        if m.get("chg1h") is not None and abs(m["chg1h"]) >= config.WATCH_PRICE_1H_PCT:
            add("price", f"价格 1 小时 {m['chg1h']:+.2f}%（现价 {m.get('price')}）")
        f, fp = m.get("funding"), m.get("funding_prev")
        if f is not None:
            if abs(f) >= config.WATCH_FUNDING_ABS:
                who = "多头付费（多头拥挤）" if f > 0 else "空头付费（空头拥挤）"
                add("funding_big", f"资金费 {f * 100:+.3f}%/8h，{who}")
            if fp is not None and f * fp < 0:
                add("funding_flip", f"资金费由 {fp * 100:+.3f}% 翻转为 {f * 100:+.3f}%")
        if m.get("ls_ratio") is not None:
            r = m["ls_ratio"]
            if r >= config.WATCH_LS_EXTREME or r <= 1 / config.WATCH_LS_EXTREME:
                add("ls", f"账户多空比 {r:.2f}，{'多头' if r >= 1 else '空头'}极端拥挤")
        return out

    # ---------- 推送与页面状态 ----------
    def _cooldown_ok(self, key):
        return time.time() - self._fired.get(key, 0) > config.WATCH_COOLDOWN

    def step(self):
        for item in self.list():
            sym = item["symbol"]
            side = item.get("side", "none")
            try:
                m = self.metrics(sym)
            except Exception as e:
                m = {"symbol": sym, "ts": int(time.time() * 1000), "error": str(e)}
            self._last[sym] = m
            for rule, text, advice in self.evaluate(m, side):
                key = (sym, rule)
                if not self._cooldown_ok(key):
                    continue
                self._fired[key] = time.time()
                note = f"（{item['note']}）" if item.get("note") else ""
                side_txt = {"long": "持仓：多", "short": "持仓：空", "none": "未持仓"}[side]
                body = (
                    f"{sym}{note}　{side_txt}\n"
                    f"【数据】{text}\n"
                    f"【建议】{advice}\n"
                    f"24h {m.get('chg24', 0):+.2f}%｜现价 {m.get('price')}"
                )
                push(body, title=f"持仓监控 {sym}")
                self._alerts.append({"symbol": sym, "rule": rule, "text": text,
                                     "advice": advice, "side": side,
                                     "ts": int(time.time() * 1000)})
        self._alerts = self._alerts[-50:]

    def run(self, stop_event):
        while not stop_event.is_set():
            try:
                self.step()
            except Exception:
                pass
            stop_event.wait(config.WATCH_SECONDS)

    def state(self):
        items = self.list()
        return {
            "watchlist": items,
            "metrics": [self._last.get(i["symbol"], {"symbol": i["symbol"]}) for i in items],
            "alerts": list(reversed(self._alerts)),
            "rules": {
                "oi_chg1h_pct": config.WATCH_OI_PCT,
                "price_1h_pct": config.WATCH_PRICE_1H_PCT,
                "funding_abs": config.WATCH_FUNDING_ABS,
                "ls_extreme": config.WATCH_LS_EXTREME,
                "interval_s": config.WATCH_SECONDS,
                "cooldown_s": config.WATCH_COOLDOWN,
            },
        }
