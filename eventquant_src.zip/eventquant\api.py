"""币安 U 本位公共行情客户端。

只用公共接口（不需要 API Key），并做两件事：
1. 权重预算：跟踪 X-MBX-USED-WEIGHT-1M，接近上限自动降速
2. 断线自愈：请求失败时通过 Clash 外部控制自动换节点后重试
"""

import time
import urllib.parse

import requests

from . import config


class BinancePublic:
    def __init__(self, base_url=None, proxies=None):
        self.base = base_url or config.BASE_URL
        # 默认直连（testnet 不走代理），显式传入 proxies 时才走代理
        self.proxies = proxies if proxies is not None else config.DIRECT_PROXIES
        self.s = requests.Session()
        if self.proxies:
            self.s.proxies.update(self.proxies)
        self.used_weight = 0
        self._last_failover = 0.0
        # 数据源候选：直连 + 代理兜底。记住上次成功的那个，下次优先用它，
        # 避免每次请求都先在直连上白等超时（国内直连币安必被墙）。
        self._endpoints = [(self.base, self.proxies)] + list(config.FALLBACK_BASES)
        self._ok_idx = 0
        # 直连被墙时 socket 会静默丢包，短超时即可判定；代理给足时间传数据
        self._direct_timeout = 4

    # ---------- 底层 ----------
    def _get(self, path, params=None, retries=3, timeout=15):
        params = params or {}
        last_err = None
        for attempt in range(retries + 1):
            # 上次成功的源排最前，其余按原顺序兜底
            chain = [self._endpoints[self._ok_idx]] + [
                e for i, e in enumerate(self._endpoints) if i != self._ok_idx
            ]
            for fb_base, fb_proxies in chain:
                try:
                    s = requests.Session()
                    if fb_proxies:
                        s.proxies.update(fb_proxies)
                    # 直连给短超时，避免每次白等 15s
                    to = timeout if fb_proxies else min(timeout, self._direct_timeout)
                    r = s.get(fb_base + path, params=params, timeout=to)
                    # 451 是地区合规封锁，直接跳下一个 fallback，不做重试
                    if r.status_code == 451:
                        continue
                    self.used_weight = int(
                        r.headers.get("X-MBX-USED-WEIGHT-1M", self.used_weight) or 0
                    )
                    if r.status_code == 429 or r.status_code == 418:
                        wait = int(r.headers.get("Retry-After", 30))
                        print(f"[限流] {path} HTTP {r.status_code}，等待 {wait}s")
                        time.sleep(wait)
                        continue
                    if r.status_code >= 500:
                        raise requests.HTTPError(f"HTTP {r.status_code}")
                    r.raise_for_status()
                    self._respect_budget()
                    # 记住当前能用的数据源，下次直接从它开始试
                    idx = self._endpoints.index((fb_base, fb_proxies))
                    if idx != self._ok_idx:
                        self._ok_idx = idx
                        self.base, self.proxies = fb_base, fb_proxies or {}
                        print(f"[网络] 数据源固定为 {fb_base}（代理={'是' if fb_proxies else '否'}）")
                    return r.json()
                except requests.exceptions.ConnectionError as e:
                    last_err = e
                    continue
                except requests.exceptions.ProxyError as e:
                    last_err = e
                    continue
                except Exception as e:
                    last_err = e
                    break  # 非网络类异常不再尝试其他 fallback
            # 所有 fallback 都试过了，尝试切节点后整体重试
            if attempt < retries:
                self._failover()
                time.sleep(1 + attempt)
        raise RuntimeError(f"{path} 请求失败: {last_err}")

    def _respect_budget(self):
        if self.used_weight >= int(config.WEIGHT_LIMIT * config.WEIGHT_SOFT_CAP):
            # 权重快用完，主动休息到下一分钟
            now = time.time()
            sleep = 60 - now % 60 + 1
            print(f"[权重] 已用 {self.used_weight}/{config.WEIGHT_LIMIT}，休息 {sleep:.0f}s")
            time.sleep(sleep)
            self.used_weight = 0

    def _failover(self):
        # 当前直连 testnet 时跳过——代理节点全 451，failover 只会做无用功
        if not self.proxies or "testnet" in self.base:
            return
        if time.time() - self._last_failover < 15:
            return
        self._last_failover = time.time()
        try:
            head = {"Authorization": f"Bearer {config.CLASH_TOKEN}"}
            g = config.CLASH_GROUP
            proxies = requests.get(
                config.CLASH_API + "/proxies", headers=head, timeout=5
            ).json()["proxies"][g]
            candidates = [n for n in proxies["all"] if n != "♻️ 自动选择"]
            best = None
            for name in candidates[:12]:
                try:
                    enc = urllib.parse.quote(name, safe="")
                    r = requests.get(
                        config.CLASH_API + f"/proxies/{enc}/delay",
                        headers=head,
                        params={
                            "timeout": 4000,
                            "url": self.base + "/fapi/v1/time",
                        },
                        timeout=8,
                    ).json()
                    d = r.get("delay")
                    # 币安返回 451（地区合规封锁）的节点也不能用
                    if d and r.get("meanDelay", d) < 4000:
                        best = (d, name)
                except Exception:
                    continue
            if best:
                requests.put(
                    config.CLASH_API + "/proxies/" + urllib.parse.quote(g, safe=""),
                    headers=head,
                    json={"name": best[1]},
                    timeout=5,
                )
                print(f"[网络] 已切换到 {best[1]}（{best[0]}ms）")
        except Exception:
            pass

    # ---------- 行情 ----------
    def server_time(self):
        return self._get("/fapi/v1/time")["serverTime"]

    def depth(self, symbol, limit=None):
        return self._get(
            "/fapi/v1/depth", {"symbol": symbol, "limit": limit or config.DEPTH_LIMIT}
        )

    def agg_trades(self, symbol, limit=None, from_id=None):
        p = {"symbol": symbol, "limit": limit or config.TRADE_LIMIT}
        if from_id is not None:
            p["fromId"] = from_id
        return self._get("/fapi/v1/aggTrades", p)

    def ticker24(self, symbol):
        return self._get("/fapi/v1/ticker/24hr", {"symbol": symbol})

    def premium(self, symbol):
        return self._get("/fapi/v1/premiumIndex", {"symbol": symbol})

    def open_interest(self, symbol):
        return self._get("/fapi/v1/openInterest", {"symbol": symbol})

    def klines(self, symbol, interval="1m", limit=None, start=None, end=None):
        p = {"symbol": symbol, "interval": interval, "limit": limit or config.KLINE_LIMIT}
        if start:
            p["startTime"] = int(start)
        if end:
            p["endTime"] = int(end)
        return self._get("/fapi/v1/klines", p)

    # ---------- 历史（派生数据） ----------
    def oi_hist(self, symbol, period="5m", limit=500, start=None, end=None):
        p = {"symbol": symbol, "period": period, "limit": limit}
        if start:
            p["startTime"] = int(start)
        if end:
            p["endTime"] = int(end)
        try:
            return self._get("/futures/data/openInterestHist", p)
        except Exception:
            # testnet 无此接口，用当前 OI 模拟单条历史记录（格式对齐 oi_to_df）
            try:
                oi = self.open_interest(symbol)
                return [{
                    "timestamp": oi["time"],
                    "sumOpenInterest": oi["openInterest"],
                    "symbol": symbol,
                }]
            except Exception:
                return []

    def funding_rate(self, symbol, limit=100, start=None, end=None):
        p = {"symbol": symbol, "limit": limit}
        if start:
            p["startTime"] = int(start)
        if end:
            p["endTime"] = int(end)
        try:
            return self._get("/fapi/v1/fundingRate", p)
        except Exception:
            return []

    def global_ls_ratio(self, symbol, period="5m", limit=5):
        """账户多空比（散户情绪）。testnet 无此接口，失败返回空。"""
        try:
            return self._get("/futures/data/globalLongShortAccountRatio",
                             {"symbol": symbol, "period": period, "limit": limit})
        except Exception:
            return []

    def top_ls_ratio(self, symbol, period="5m", limit=5):
        """大户持仓多空比。testnet 无此接口，失败返回空。"""
        try:
            return self._get("/futures/data/topLongShortPositionRatio",
                             {"symbol": symbol, "period": period, "limit": limit})
        except Exception:
            return []

    def exchange_info(self):
        return self._get("/fapi/v1/exchangeInfo")
