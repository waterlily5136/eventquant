"""模拟事件合约：下单、到期自动结算、保留实验记录。

完全在本地记账，不连接币安账户、不真实下单：
- 触发价取按下单时刻的实时成交价
- 到期后用当时的价格判定 涨/跌 是否命中
- 命中按 SIM_PAYOUT 赔付，未命中损失本金，价格不变按平局返还
- 记录持久化到 data/event_sim.json，重启不丢
"""

import json
import os
import threading
from pathlib import Path

from . import config, contract


class EventSimulator:
    def __init__(self, path=None):
        self.path = Path(path or config.SIM_PATH)
        self.lock = threading.Lock()
        self.data = {"seq": 0, "orders": []}
        self._load()

    # ---------- 存储 ----------
    def _load(self):
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(raw, dict) and isinstance(raw.get("orders"), list):
                self.data = raw
                self.data.setdefault("seq", len(self.data["orders"]))
                self._renumber()
        except Exception as e:
            print(f"[模拟] 读取记录失败：{e}")

    def _renumber(self):
        """按 owner 分别编号：我的 我-1/我-2…，AI 的 AI-1/AI-2…"""
        counters = {"me": 0, "ai": 0}
        for o in self.data["orders"]:
            owner = o.setdefault("owner", "me")
            counters[owner] = counters.get(owner, 0) + 1
            o["no"] = counters[owner]
            o["label"] = ("我-" if owner == "me" else "AI-") + str(counters[owner])
        self.data["counters"] = counters

    def _save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
        except Exception as e:
            print(f"[模拟] 写入记录失败：{e}")

    # ---------- 下单 ----------
    def place(self, symbol, horizon, direction, stake, price, trigger_ms=None,
              owner="me", pred=None):
        symbol = str(symbol).upper()
        if horizon not in config.HORIZONS:
            raise ValueError(f"不支持的周期：{horizon}")
        if direction not in (contract.DIR_UP, contract.DIR_DOWN):
            raise ValueError("方向只能是 涨 或 跌")
        stake = round(float(stake), 2)
        if not (config.SIM_MIN_STAKE <= stake <= config.SIM_MAX_STAKE):
            raise ValueError(f"下注金额需在 {config.SIM_MIN_STAKE}~{config.SIM_MAX_STAKE} U 之间")
        price = float(price)
        if price <= 0:
            raise ValueError("价格无效")

        trigger_ms = int(trigger_ms or contract.now_ms())
        minutes = int(config.HORIZONS[horizon])
        target_ms = trigger_ms + minutes * 60_000
        with self.lock:
            self.data["seq"] = int(self.data.get("seq", 0)) + 1
            counters = self.data.setdefault("counters", {"me": 0, "ai": 0})
            counters[owner] = int(counters.get(owner, 0)) + 1
            no = counters[owner]
            order = {
                "id": self.data["seq"],
                "owner": owner,
                "no": no,
                "label": ("我-" if owner == "me" else "AI-") + str(no),
                "symbol": symbol,
                "horizon": horizon,
                "horizon_label": contract.horizon_label(minutes),
                "direction": direction,
                "stake": stake,
                "entry": price,
                "trigger_ts": trigger_ms,
                "trigger_time": contract.fmt_ms(trigger_ms),
                "target_ts": target_ms,
                "target_time": contract.fmt_ms(target_ms),
                "status": "open",
            }
            if pred:
                order["pred_conf"] = round(float(pred.get("confidence", 0)), 4)
                order["pred_tier"] = pred.get("tier")
            self.data["orders"].append(order)
            self._save()
        return order

    def has_open(self, symbol, horizon, owner="me"):
        with self.lock:
            return any(
                o.get("status") == "open"
                and o.get("symbol") == symbol
                and o.get("horizon") == horizon
                and o.get("owner", "me") == owner
                for o in self.data["orders"]
            )

    # ---------- 结算 ----------
    def settle_due(self, price_fn, now_ms=None):
        now_ms = int(now_ms or contract.now_ms())
        settled = []
        with self.lock:
            for o in self.data["orders"]:
                if o.get("status") != "open" or int(o["target_ts"]) > now_ms:
                    continue
                try:
                    px = price_fn(o["symbol"], int(o["target_ts"]))
                except Exception:
                    continue
                if not px:
                    continue
                pnl, result = self._judge(o, float(px))
                o.update(
                    status="settled",
                    settle_px=float(px),
                    settle_ts=now_ms,
                    settle_time=contract.fmt_ms(now_ms),
                    result=result,
                    pnl=round(pnl, 4),
                )
                settled.append(o)
            if settled:
                self._save()
        return settled

    @staticmethod
    def _judge(order, settle_px):
        entry = float(order["entry"])
        stake = float(order["stake"])
        if settle_px == entry:
            return 0.0, "tie"
        up = settle_px > entry
        hit = (order["direction"] == contract.DIR_UP) == up
        if hit:
            return stake * config.SIM_PAYOUT, "win"
        return -stake, "lose"

    # ---------- 查询 ----------
    def state(self):
        """按 owner 分成两份：me = 手动下单，ai = 自动下单。"""
        with self.lock:
            orders = list(self.data["orders"])
        return {"me": self._view(orders, "me"), "ai": self._view(orders, "ai")}

    def _view(self, orders, owner):
        mine = [o for o in orders if o.get("owner", "me") == owner]
        open_orders = [o for o in mine if o.get("status") == "open"]
        history = [o for o in mine if o.get("status") == "settled"]
        history.sort(key=lambda o: o.get("settle_ts", 0), reverse=True)
        wins = sum(1 for o in history if o.get("result") == "win")
        losses = sum(1 for o in history if o.get("result") == "lose")
        ties = sum(1 for o in history if o.get("result") == "tie")
        total_stake = sum(float(o["stake"]) for o in history)
        total_pnl = sum(float(o.get("pnl", 0)) for o in history)
        decided = wins + losses
        return {
            "open": open_orders,
            "history": history[:200],
            "stats": {
                "total": len(history),
                "wins": wins,
                "losses": losses,
                "ties": ties,
                "win_rate": round(wins / decided, 4) if decided else None,
                "total_stake": round(total_stake, 2),
                "total_pnl": round(total_pnl, 4),
                "roi": round(total_pnl / total_stake, 4) if total_stake else None,
                "payout": config.SIM_PAYOUT,
            },
        }
