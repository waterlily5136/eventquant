"""三分类走势模型：上涨 / 震荡 / 下跌。

模型选择逻辑：轻量、可解释、概率天然输出。
用逻辑回归 + 中位数填补 + 标准化，按周期分别训练。
"""

import json

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from . import config
from .features import CLASS_NAMES, CORE_FEATURES


def make_pipeline():
    return Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "clf",
                LogisticRegression(
                    max_iter=2000,
                    C=0.5,
                    class_weight="balanced",
                ),
            ),
        ]
    )


def model_path(horizon):
    return config.MODEL_DIR / f"clf_{horizon}.joblib"


def save(pipe, horizon, info=None):
    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipe": pipe, "features": CORE_FEATURES, "horizon": horizon,
                 "info": info or {}}, model_path(horizon))


def load(horizon):
    p = model_path(horizon)
    if not p.exists():
        return None
    return joblib.load(p)


def tier_of(p):
    if p >= config.TIER_A:
        return "A"
    if p >= config.TIER_B:
        return "B"
    return "C"


def predict_row(bundle, row):
    """输入一行核心特征，返回方向、概率与置信度等级。"""
    pipe = bundle["pipe"]
    X = pd.DataFrame([{k: row.get(k, np.nan) for k in CORE_FEATURES}])
    proba = pipe.predict_proba(X)[0]
    classes = list(pipe.classes_)
    probs = {CLASS_NAMES[int(c)]: float(proba[i]) for i, c in enumerate(classes)}
    # 缺失类别补 0
    for name in CLASS_NAMES:
        probs.setdefault(name, 0.0)
    pred = classes[int(np.argmax(proba))]
    direction = CLASS_NAMES[int(pred)]
    conf = max(probs.values())
    enabled = config.SIGNAL_ENABLED.get(bundle.get("horizon", ""), True)
    horizon = bundle.get("horizon", "")
    min_conf = config.MIN_CONF_BY_HORIZON.get(horizon, config.MIN_CONFIDENCE)
    sig = direction != "震荡" and conf >= min_conf and enabled

    # 解释性：标准化特征 × 该类系数，取贡献最大的三项
    try:
        imp = pipe.named_steps["imputer"]
        sc = pipe.named_steps["scaler"]
        clf = pipe.named_steps["clf"]
        x = sc.transform(imp.transform(X))[0]
        idx = list(clf.classes_).index(pred)
        coef = clf.coef_[idx]
        contrib = sorted(zip(CORE_FEATURES, x * coef), key=lambda t: -abs(t[1]))
        drivers = [f"{k}({v:+.2f})" for k, v in contrib[:3]]
    except Exception:
        drivers = []
    return {
        "direction": direction,
        "probabilities": probs,
        "confidence": conf,
        "tier": tier_of(conf),
        "actionable": bool(sig),
        "enabled": bool(enabled),
        "drivers": drivers,
    }
