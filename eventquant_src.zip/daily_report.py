"""每日全球市场日报（默认早上 08:00 北京时间推送）。

设计原则：**全部用免 key 的公开数据源**，这样丢到 GitHub Actions 上就能跑，
不需要你的电脑开着，也不需要任何账号。

数据源
    加密货币      CoinGecko（币安在美国机房会被 451 拦，所以不用币安）
    恐慌贪婪指数  alternative.me
    美股/黄金/石油/美元/长债   Yahoo Finance 日线
    新闻          华尔街见闻 RSS + 新浪财经滚动（中文标题 + 摘要）

用法
    python daily_report.py --dry      只打印，不推送（本地调试）
    python daily_report.py            发到 pushplus（需环境变量 PUSHPLUS_TOKEN）
"""

import argparse
import html as html_lib
import json
import os
import pathlib
import re
import sys
import time
from datetime import datetime, timedelta, timezone

import requests

BJ = timezone(timedelta(hours=8))
UA = {"User-Agent": "Mozilla/5.0 (compatible; daily-report/1.0)"}


# ---------------- 数据抓取 ----------------
def get_json(url, timeout=20):
    r = requests.get(url, headers=UA, timeout=timeout)
    r.raise_for_status()
    return r.json()


def crypto():
    """主流币现价与 24h 涨跌。"""
    ids = "bitcoin,ethereum,solana,binancecoin"
    d = get_json(
        f"https://api.coingecko.com/api/v3/simple/price?ids={ids}"
        "&vs_currencies=usd&include_24hr_change=true&include_market_cap=true")
    names = [("bitcoin", "BTC"), ("ethereum", "ETH"),
             ("solana", "SOL"), ("binancecoin", "BNB")]
    out = []
    for k, label in names:
        v = d.get(k) or {}
        out.append({
            "name": label,
            "price": v.get("usd"),
            "chg": v.get("usd_24h_change"),
            "mcap": v.get("usd_market_cap"),
        })
    return out


def fear_greed():
    d = get_json("https://api.alternative.me/fng/?limit=2")
    arr = d.get("data") or []
    if not arr:
        return None
    cur = arr[0]
    prev = arr[1] if len(arr) > 1 else None
    return {
        "value": int(cur["value"]),
        "label": cur["value_classification"],
        "prev": int(prev["value"]) if prev else None,
    }


YAHOO = [
    ("SPY", "标普500", "index"),
    ("QQQ", "纳斯达克100", "index"),
    ("DIA", "道琼斯", "index"),
    ("IWM", "罗素2000", "index"),
    ("^VIX", "VIX恐慌指数", "index"),
    ("GC=F", "黄金", "commodity"),
    ("CL=F", "原油", "commodity"),
    ("DX-Y.NYB", "美元指数", "index"),
    ("^TNX", "美债10年收益率", "yield"),
]


def yahoo_one(sym):
    u = (f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}"
         f"?range=5d&interval=1d")
    r = requests.get(u, headers=UA, timeout=25)
    r.raise_for_status()
    res = r.json()["chart"]["result"][0]
    closes = [c for c in res["indicators"]["quote"][0]["close"] if c]
    if len(closes) < 2:
        return None
    close, prev = closes[-1], closes[-2]
    return {"close": close, "chg": (close - prev) / prev * 100}


def markets():
    from concurrent.futures import ThreadPoolExecutor

    def work(item):
        sym, label, kind = item
        try:
            v = yahoo_one(sym)
        except Exception:
            v = None
        return {"name": label, "code": sym, "kind": kind, **v} if v else None

    with ThreadPoolExecutor(max_workers=6) as ex:
        rows = list(ex.map(work, YAHOO))
    return [r for r in rows if r]


def _clean(markup, n=80):
    """把 RSS 里的 HTML 摘要压成一句纯文本，超长截断。"""
    t = re.sub(r"<[^>]+>", "", markup or "")
    t = html_lib.unescape(t)
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) <= n:
        return t
    return t[:n].rstrip() + "…"


def news(limit=5):
    """中文财经要闻：标题 + 一句摘要。

    两个源各取一部分——华尔街见闻偏宏观和市场，新浪偏快讯和国际财经。
    中文源全挂时才退回英文 RSS，避免整段要闻变成英文。
    """
    out = []

    # 1) 华尔街见闻：中文标题 + 中文摘要
    try:
        r = requests.get("https://dedicated.wallstreetcn.com/rss.xml",
                         headers=UA, timeout=20)
        r.raise_for_status()
        for blk in re.findall(r"<item>(.*?)</item>", r.text, re.S):
            tm = re.search(r"<title><!\[CDATA\[(.*?)\]\]></title>", blk, re.S)
            dm = re.search(r"<description><!\[CDATA\[(.*?)\]\]></description>", blk, re.S)
            if not tm:
                continue
            out.append({
                "title": tm.group(1).strip(),
                "summary": _clean(dm.group(1) if dm else ""),
                "src": "华尔街见闻",
            })
            if len(out) >= 3:
                break
    except Exception:
        pass

    # 2) 新浪财经滚动：中文快讯，补数量
    if len(out) < limit:
        try:
            d = get_json("https://feed.mix.sina.com.cn/api/roll/get"
                         "?pageid=153&lid=2516&k=&num=15&page=1")
            for it in (d.get("result", {}).get("data") or []):
                t = (it.get("title") or "").strip()
                if not t:
                    continue
                out.append({
                    "title": t,
                    "summary": _clean(it.get("intro") or ""),
                    "src": "新浪财经",
                })
                if len(out) >= limit:
                    break
        except Exception:
            pass

    # 3) 中文源全挂才用英文源兜底
    if not out:
        for u in ("https://feeds.a.dj.com/rss/RSSMarketsMain.xml",
                  "https://www.cnbc.com/id/100003114/device/rss/rss.html"):
            try:
                r = requests.get(u, headers=UA, timeout=20)
                r.raise_for_status()
                titles = re.findall(
                    r"<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>", r.text)
                for t in titles[1:]:
                    t = t.strip()
                    if t:
                        out.append({"title": t, "summary": "", "src": "外媒"})
                    if len(out) >= limit:
                        break
            except Exception:
                continue
            if len(out) >= limit:
                break

    seen, uniq = set(), []
    for x in out:
        key = x["title"][:20]
        if key in seen:
            continue
        seen.add(key)
        uniq.append(x)
    return uniq[:limit]


# ---------------- 判断（规则，不是 AI） ----------------
def verdict(cr, fg, mk, nw):
    """把数据翻译成人话，每条都标明是哪个市场。规则写死，不是 AI 生成的。"""
    L = []
    btc = next((c for c in cr if c["name"] == "BTC"), None)
    eth = next((c for c in cr if c["name"] == "ETH"), None)

    def mkt(code):
        return next((m for m in mk if m["code"] == code), None)

    spy, qqq, iwm = mkt("SPY"), mkt("QQQ"), mkt("IWM")
    vix, gld, uso = mkt("^VIX"), mkt("GC=F"), mkt("CL=F")
    dxy, tnx = mkt("DX-Y.NYB"), mkt("^TNX")

    # ---- 1. 情绪 ----
    if fg:
        v = fg["value"]
        delta = ""
        if fg.get("prev") is not None:
            d = v - fg["prev"]
            delta = f"，较昨日 {d:+d}"
        if v <= 20:
            L.append(f"【情绪】恐慌贪婪 {v}（{fg['label']}{delta}）。"
                     f"历史上这是分批买的位置，但不是一次梭哈的位置——恐慌可以更恐慌。")
        elif v <= 40:
            L.append(f"【情绪】恐慌贪婪 {v}（{fg['label']}{delta}）。"
                     f"市场在犹豫，这种时候追涨的成功率通常最差。")
        elif v <= 60:
            L.append(f"【情绪】恐慌贪婪 {v}（{fg['label']}{delta}）。"
                     f"没有极端情绪，行情要靠新消息推动。")
        elif v <= 80:
            L.append(f"【情绪】恐慌贪婪 {v}（{fg['label']}{delta}）。别人贪婪时要开始想退路。")
        else:
            L.append(f"【情绪】恐慌贪婪 {v}（{fg['label']}{delta}）。"
                     f"这种位置买入，历史上大概率要站岗一段时间。")

    # ---- 2. 跨市场（解释力最强，放前面） ----
    if btc and spy:
        bc, sc = btc.get("chg") or 0, spy["chg"]
        if bc < -2 and sc < -0.5:
            L.append("【跨市场】币和美股一起跌，说明是宏观风险偏好收缩，不是币圈自己的事。"
                     "这种时候抄底要先看美股脸色。")
        elif bc > 2 and sc > 0.5:
            L.append("【跨市场】币和美股同步上涨，风险偏好回来了，两个市场方向一致。")
        elif bc * sc < 0 and abs(bc) > 1.5 and abs(sc) > 0.5:
            L.append("【跨市场】币和美股走反了，说明资金在两边轮动，"
                     "别把两个市场当成一回事。")
    if gld and spy and gld["chg"] > 0.8 and spy["chg"] < 0:
        L.append(f"【跨市场】黄金涨 {gld['chg']:+.1f}% 而美股跌，是资金在避险，不是抄底信号。")

    # ---- 3. 币圈 ----
    if btc:
        bc = btc.get("chg") or 0
        if bc >= 3:
            L.append(f"【币圈】BTC 24h {bc:+.1f}%，强势拉升。这种时候追多容易买在日内高点，等回踩更稳。")
        elif bc >= 1:
            L.append(f"【币圈】BTC 24h {bc:+.1f}%，温和上涨，方向偏多但力度一般。")
        elif bc > -1:
            L.append(f"【币圈】BTC 24h {bc:+.1f}%，横盘。横盘期做方向性下注胜率最低，"
                     f"因为手续费和噪音会吃掉一切。")
        elif bc > -3:
            L.append(f"【币圈】BTC 24h {bc:+.1f}%，走弱。山寨通常跌得比 BTC 更狠，别在这个位置逆势接多。")
        else:
            L.append(f"【币圈】BTC 24h {bc:+.1f}%，急跌。此时抄底是在猜底，"
                     f"先等一根止跌的 K 线再说。")
    if btc and eth:
        d = (eth.get("chg") or 0) - (btc.get("chg") or 0)
        if d >= 2:
            L.append(f"【币圈】ETH 跑赢 BTC {d:+.1f} 个百分点，资金在往风险更高的地方走，"
                     f"山寨可能跟涨。")
        elif d <= -2:
            L.append(f"【币圈】ETH 跑输 BTC {d:+.1f} 个百分点，资金收缩回 BTC，山寨通常更惨。")

    # ---- 4. 美股 ----
    if spy:
        sc = spy["chg"]
        if sc >= 1.5:
            L.append(f"【美股】标普 {sc:+.1f}%，大涨。这种日子追进去，第二天经常要吃回吐。")
        elif sc >= 0.3:
            L.append(f"【美股】标普 {sc:+.1f}%，温和收涨，风险偏好正常。")
        elif sc > -0.3:
            L.append(f"【美股】标普 {sc:+.1f}%，基本走平。没有方向的日子，不做方向性下注最划算。")
        elif sc > -1.5:
            L.append(f"【美股】标普 {sc:+.1f}%，小跌。正常回调，关键看有没有跌破前低。")
        else:
            L.append(f"【美股】标普 {sc:+.1f}%，大跌。先保命，别急着抄。")
    if qqq and spy:
        d = qqq["chg"] - spy["chg"]
        if d > 0.5:
            L.append(f"【美股】纳指跑赢标普 {d:+.1f} 个点，科技股在领涨，市场敢承担风险。")
        elif d < -0.5:
            L.append(f"【美股】纳指跑输标普 {d:+.1f} 个点，科技股在拖后腿，资金往防守板块躲。")
    if iwm and spy:
        d = iwm["chg"] - spy["chg"]
        if d > 0.5:
            L.append(f"【美股】小盘股跑赢大盘 {d:+.1f} 个点，风险偏好在扩散，"
                     f"这种环境对山寨币也偏友好。")
        elif d < -0.5:
            L.append(f"【美股】小盘股跑输大盘 {d:+.1f} 个点，资金只敢抱大票，"
                     f"高波动资产（含山寨）压力大。")

    # ---- 5. 商品 ----
    if gld and uso and gld["chg"] > 1 and uso["chg"] > 1:
        L.append(f"【商品】黄金 {gld['chg']:+.1f}%、原油 {uso['chg']:+.1f}% 同涨，"
                 f"是输入型通胀信号，对降息预期不利。")
    elif gld and gld["chg"] > 1.5:
        L.append(f"【商品】黄金 {gld['chg']:+.1f}%，避险需求升温。")
    if uso and uso["chg"] > 2:
        L.append(f"【商品】原油 {uso['chg']:+.1f}%，能源价格抬头，"
                 f"通胀压力对降息预期是坏消息。")

    # ---- 6. 美元与利率 ----
    if dxy:
        if dxy["chg"] >= 0.5:
            L.append(f"【美元】美元指数 {dxy['chg']:+.1f}%，美元走强，全球流动性收紧，"
                     f"对币和成长股都是逆风。")
        elif dxy["chg"] <= -0.5:
            L.append(f"【美元】美元指数 {dxy['chg']:+.1f}%，美元走弱，流动性偏宽松，"
                     f"对风险资产是顺风。")
    if tnx:
        if tnx["chg"] >= 1.5:
            L.append(f"【利率】美债 10 年收益率升至 {tnx['close']:.2f}%（{tnx['chg']:+.1f}%），"
                     f"估值压力上升，高估值的科技股和币最敏感。")
        elif tnx["chg"] <= -1.5:
            L.append(f"【利率】美债 10 年收益率降至 {tnx['close']:.2f}%（{tnx['chg']:+.1f}%），"
                     f"利率下行，对风险资产偏友好。")

    # ---- 7. 波动率 ----
    if vix:
        if vix["close"] >= 25:
            L.append(f"【波动率】VIX {vix['close']:.1f}，市场在恐慌。任何仓位都该减半，杠杆会放大错误。")
        elif vix["close"] <= 14:
            L.append(f"【波动率】VIX 只有 {vix['close']:.1f}，市场太安逸。"
                     f"低波动往往是大行情前的假象，别在这种时候加满仓。")

    if not L:
        L.append("【综合】今天没有特别极端的信号，属于常规波动。")
    return L[:8]


def fmt_time():
    return datetime.now(BJ).strftime("%Y-%m-%d %H:%M")


# ---------------- 补交状态 ----------------
STATE = pathlib.Path(__file__).resolve().parent / "data" / "report_state.json"


def load_state():
    try:
        return json.loads(STATE.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def save_state(d):
    try:
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


# ---------------- 组装 ----------------
def build(mode="full"):
    """mode: full 完整日报（早上推）| 睡前（晚上推，短版）"""
    err = []

    def safe(fn, default):
        try:
            return fn()
        except Exception as e:
            err.append(f"{fn.__name__}: {e}")
            return default

    cr = safe(crypto, [])
    fg = safe(fear_greed, None)
    mk = safe(markets, [])
    nw_ = safe(news, [])

    L = [f"【全球市场日报】{fmt_time()}（北京时间）"]
    if mode == "bedtime":
        L[0] += " · 睡前快照"
    L.append("")

    if mode == "bedtime":
        # 短版：只给已经收盘/确定的东西（A股、港股、加密、恐慌贪婪、雷达 TOP5）
        L.append("— 加密货币 —")
        for c in cr:
            if c["price"] is None:
                continue
            chg = c.get("chg") or 0
            L.append(f"{c['name']:<4} {c['price']:>10,.2f}  {chg:+6.2f}%")
        if fg:
            L.append("")
            L.append(f"— 恐慌贪婪 —\n{fg['value']} {fg['label']}")
        L.append("")
        L.append("（美股 / 黄金 / 原油尚未收盘，数据待完整日报补齐）")
        L.append("")
        L.append("— 判断 —")
        for line in verdict(cr, fg, [], nw_):
            if line.startswith(("【情绪】", "【币圈】", "【跨市场】")):
                L.append("· " + line)
    else:
        if cr:
            L.append("— 加密货币 —")
            for c in cr:
                if c["price"] is None:
                    continue
                chg = c.get("chg") or 0
                L.append(f"{c['name']:<4} {c['price']:>10,.2f}  {chg:+6.2f}%")
            L.append("")

        if fg:
            arrow = ""
            if fg.get("prev") is not None:
                d = fg["value"] - fg["prev"]
                arrow = f"（较昨日 {'+' if d >= 0 else ''}{d}）"
            L.append(f"— 恐慌贪婪 —\n{fg['value']} {fg['label']}{arrow}")
            L.append("")

        if mk:
            L.append("— 美股 / 商品 —")
            for m in mk:
                if m["kind"] == "yield":
                    L.append(f"{m['name']:<12} {m['close']:>8.2f}%  {m['chg']:+6.2f}%")
                else:
                    L.append(f"{m['name']:<12} {m['close']:>10,.2f}  {m['chg']:+6.2f}%")
            L.append("")

        if nw_:
            L.append("— 要闻 —")
            for i, it in enumerate(nw_, 1):
                L.append(f"{i}. {it['title']}")
                if it.get("summary"):
                    L.append(f"   {it['summary']}")
            L.append("")

        L.append("— 判断 —")
        for line in verdict(cr, fg, mk, nw_):
            L.append("· " + line)

    L.append("")
    L.append("（数据来自 CoinGecko / alternative.me / Yahoo Finance / 公开 RSS；"
             "仅技术参考，不构成投资建议。）")
    if err:
        L.append(f"[抓取异常 {len(err)} 项：{'; '.join(err[:3])}]")
    return "\n".join(L)


def _token():
    token = os.environ.get("PUSHPLUS_TOKEN", "").strip()
    if token:
        return token
    # 本地运行时从 data/push_webhook.txt 里读（GitHub 上用 Secret，不读文件）
    try:
        raw = (pathlib.Path(__file__).resolve().parent
               / "data" / "push_webhook.txt").read_text(encoding="utf-8")
        for line in raw.splitlines():
            if line.strip().startswith("pushplus:"):
                return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return ""


def push(text):
    token = _token()
    if not token:
        print("[推送] 没有找到 PUSHPLUS_TOKEN，跳过")
        return False
    r = requests.post("https://www.pushplus.plus/send", json={
        "token": token,
        "title": "全球市场日报",
        "content": text,
        "template": "txt",
    }, timeout=25)
    ok = r.status_code == 200 and (r.json().get("code") == 200)
    print(f"[推送] {'成功' if ok else '失败: ' + r.text[:200]}")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true", help="只打印不推送")
    ap.add_argument("--mode", choices=["full", "bedtime"], default="full")
    ap.add_argument("--once-a-day", action="store_true",
                    help="当天已经发过就跳过（用于开机后补交）")
    ap.add_argument("--force", action="store_true", help="忽略 once-a-day 的记录")
    args = ap.parse_args()

    today = datetime.now(BJ).strftime("%Y-%m-%d")
    if args.once_a_day and not args.force:
        st = load_state()
        if st.get("last_date") == today:
            print(f"[跳过] {today} 的日报已经发过了（{st.get('last_at', '')}）")
            return

    text = build(args.mode)
    print(text)
    if args.dry:
        return
    ok = push(text)
    if ok and args.once_a_day:
        save_state({"last_date": today, "last_at": fmt_time(), "mode": args.mode})
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
