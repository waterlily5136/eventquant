"""实时采集器：盘口深度、成交流、资金费率、持仓量、24h 行情。

每轮（默认 10 秒）对每个交易对拉取一次，写入 SQLite。
aggTrades 用 trade id 去重，避免相邻两轮重复计算。
"""

import time
import traceback

from .api import BinancePublic
from .store import Store
from . import config


def depth_metrics(d):
    bids = [(float(p), float(q)) for p, q in d["bids"]]
    asks = [(float(p), float(q)) for p, q in d["asks"]]
    if not bids or not asks:
        return None
    bid_n = sum(p * q for p, q in bids)
    ask_n = sum(p * q for p, q in asks)
    big_bid = sum(p * q for p, q in bids if p * q >= config.BIG_DEPTH_USDT)
    big_ask = sum(p * q for p, q in asks if p * q >= config.BIG_DEPTH_USDT)
    mid = (bids[0][0] + asks[0][0]) / 2
    spread_bps = (asks[0][0] - bids[0][0]) / mid * 1e4
    imb = (bid_n - ask_n) / (bid_n + ask_n + 1e-12)
    levels = {
        "bids": [[p, q] for p, q in bids[:5]],
        "asks": [[p, q] for p, q in asks[:5]],
    }
    return {
        "mid": mid,
        "spread_bps": spread_bps,
        "bid_notional": bid_n,
        "ask_notional": ask_n,
        "imbalance": imb,
        "big_bid": big_bid,
        "big_ask": big_ask,
        "levels": levels,
        "ts": int(d.get("E") or d.get("T") or time.time() * 1000),
    }


class Collector:
    def __init__(self, api=None, store=None, symbols=None):
        self.api = api or BinancePublic()
        self.store = store or Store()
        self.symbols = symbols or config.SYMBOLS
        self.last_trade_id = {}

    def collect_flow(self, symbol):
        trades = self.api.agg_trades(symbol)
        last = self.last_trade_id.get(symbol)
        fresh = [t for t in trades if last is None or t["a"] > last]
        if trades:
            self.last_trade_id[symbol] = max(t["a"] for t in trades)
        buy_n = sell_n = big_buy = big_sell = 0.0
        for t in fresh:
            n = float(t["p"]) * float(t["q"])
            if t["m"]:  # buyer is maker -> 主动卖
                sell_n += n
                if n >= config.BIG_TRADE_USDT:
                    big_sell += n
            else:
                buy_n += n
                if n >= config.BIG_TRADE_USDT:
                    big_buy += n
        total = buy_n + sell_n
        return {
            "buy_notional": buy_n,
            "sell_notional": sell_n,
            "big_buy": big_buy,
            "big_sell": big_sell,
            "trades": len(fresh),
            "buy_ratio": buy_n / total if total else 0.5,
            "ts": int(fresh[-1]["T"]) if fresh else int(time.time() * 1000),
        }

    def poll(self, symbol):
        snap = {}
        d = depth_metrics(self.api.depth(symbol))
        if d:
            self.store.add_depth(
                symbol, d["mid"], d["spread_bps"], d["bid_notional"],
                d["ask_notional"], d["imbalance"], d["big_bid"], d["big_ask"],
                d["levels"], ts=d["ts"],
            )
            snap["depth"] = d

        f = self.collect_flow(symbol)
        self.store.add_flow(
            symbol, f["buy_notional"], f["sell_notional"], f["big_buy"],
            f["big_sell"], f["trades"], f["buy_ratio"], ts=f["ts"],
        )
        snap["flow"] = f

        t = self.api.ticker24(symbol)
        self.store.add_ticker(
            symbol, float(t["lastPrice"]), float(t["priceChangePercent"]),
            float(t["quoteVolume"]),
        )
        p = self.api.premium(symbol)
        self.store.add_funding(
            symbol, float(p["lastFundingRate"]), int(p["nextFundingTime"])
        )
        snap["funding"] = float(p["lastFundingRate"])

        oi = float(self.api.open_interest(symbol)["openInterest"])
        self.store.add_oi(symbol, oi)
        snap["oi"] = oi
        return snap

    def run(self, max_rounds=None, on_round=None):
        round_no = 0
        while max_rounds is None or round_no < max_rounds:
            round_no += 1
            t0 = time.time()
            for sym in self.symbols:
                try:
                    self.poll(sym)
                except Exception as e:
                    print(f"[{sym}] 采集失败: {e}")
                    traceback.print_exc(limit=1)
            if on_round:
                try:
                    on_round(round_no)
                except Exception as e:
                    print(f"[回调] 出错: {e}")
            dt = time.time() - t0
            time.sleep(max(0, config.POLL_SECONDS - dt))
