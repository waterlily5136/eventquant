"""行情存档：把 1 分钟 K 线持续写入 SQLite。

为什么需要：模型训练目前依赖 30 天的临时 pkl 缓存，重下就会覆盖，样本永远只有 30 天。
这里每 10 分钟把最近 300 根 1m K 线 upsert 进库，日积月累形成自己的样本；
首次启动若库是空的，会把 data/cache 里现成的 30 天数据导入作为起点。
"""

import time

import pandas as pd

from . import config


class KlineArchiver:
    def __init__(self, api, store, symbols=None, interval=None):
        self.api = api
        self.store = store
        self.symbols = list(symbols or config.SYMBOLS)
        self.interval = interval or config.ARCHIVE_SECONDS

    def backfill_from_cache(self):
        if self.store.kline_count():
            return 0
        total = 0
        for sym in self.symbols:
            p = config.CACHE_DIR / f"{sym}_1m_30d.pkl"
            if not p.exists():
                continue
            try:
                df = pd.read_pickle(p)
                rows = [
                    [int(t), o, h, l, c, v]
                    for t, o, h, l, c, v in zip(
                        df["open_time"], df["open"], df["high"],
                        df["low"], df["close"], df["volume"],
                    )
                ]
                total += self.store.add_klines(sym, rows)
            except Exception as e:
                print(f"[存档] 导入 {sym} 失败：{e}")
        return total

    def run_once(self):
        n = 0
        for sym in self.symbols:
            try:
                raw = self.api.klines(sym, interval="1m", limit=config.ARCHIVE_BARS)
                n += self.store.add_klines(sym, raw)
            except Exception as e:
                print(f"[存档] {sym} 拉取失败：{e}")
        return n

    def run(self, stop_event=None):
        imported = self.backfill_from_cache()
        print(
            f"[存档] 初始导入 {imported} 根，之后每 {self.interval}s 追加最近 "
            f"{config.ARCHIVE_BARS} 根"
        )
        while not (stop_event and stop_event.is_set()):
            try:
                self.run_once()
            except Exception as e:
                print(f"[存档] 轮次失败：{e}")
            if stop_event:
                stop_event.wait(self.interval)
            else:
                time.sleep(self.interval)
